package dev.bedrockui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.network.chat.Component;

/**
 * Bedrock-style button look, drawn over the vanilla button: light gray body with a dark outline and a shaded
 * bottom edge, dark text; on hover the button turns green with a white outline (it does not change size).
 */
final class BedrockButtons {
    private BedrockButtons() {}

    private static void rect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int rgb, int a) {
        if (a <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(a, 255) << 24) | rgb);
    }

    static void draw(GuiGraphicsExtractor g, Font font, AbstractWidget w, int mx, int my, float alpha) {
        int a = (int) (255 * Math.max(0f, Math.min(1f, alpha)));
        if (a <= 4) return;
        Component label = w.getMessage();
        int x = w.getX();
        int y = w.getY();
        int bw = w.getWidth();
        int bh = w.getHeight();
        boolean hover = w.active && mx >= x && mx < x + bw && my >= y && my < y + bh;

        if (hover) {
            // no growing on hover: a white outline inside the button bounds and a green body
            rect(g, x - 1, y - 1, x + bw + 1, y + bh + 1, 0x1E1E1F, a);
            rect(g, x, y, x + bw, y + bh, 0xFFFFFF, a);
            rect(g, x + 2, y + 2, x + bw - 2, y + bh - 2, 0x3C8527, a);
            rect(g, x + 2, y + 2, x + bw - 2, y + 4, 0x5BB33E, a);
            rect(g, x + 2, y + bh - 5, x + bw - 2, y + bh - 2, 0x2A641C, a);
        } else {
            int fill = w.active ? 0xD0D1D4 : 0x8E8E90;
            int top = w.active ? 0xEDEDEF : 0xA4A4A6;
            int bottom = w.active ? 0x8B8C90 : 0x6E6E70;
            rect(g, x - 1, y - 1, x + bw + 1, y + bh + 1, 0x1E1E1F, a);
            rect(g, x, y, x + bw, y + bh, fill, a);
            rect(g, x, y, x + bw, y + 2, top, a);
            rect(g, x, y + bh - 3, x + bw, y + bh, bottom, a);
        }
        int text = hover ? 0xFFFFFF : (w.active ? 0x3A3A3C : 0x505050);

        if (label != null) {
            int tw = font.width(label);
            g.text(font, label, x + (bw - tw) / 2, y + (bh - 8) / 2, (a << 24) | text, false);
        }
    }
}
