package dev.bedrockui;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;

/**
 * Bedrock-like HUD behavior: the hotbar and status bars can be raised/lowered (screen safe area) and fade to a
 * configurable opacity after a configurable time without activity (movement, looking, hotbar changes, damage, ...).
 */
public final class HudFade {
    private static final String[] ELEMENTS = {
            "hotbar", "info_bar", "experience_level", "health_bar", "armor_bar", "food_bar",
            "air_bar", "mount_health", "held_item_tooltip"
    };

    /** Smoothed opacity (0..1) of the HUD right now. */
    private static float current = 1f;
    /** Opacity applied to sprites drawn while one of the wrapped HUD elements is rendering (1 = no change). */
    private static float scope = 1f;

    private static int idleTicks;
    private static double lx;
    private static double ly;
    private static double lz;
    private static float lyaw;
    private static float lpitch;
    private static float lhealth;
    private static int lfood;
    private static int lslot = -1;

    private HudFade() {}

    /** Opacity that sprite drawing should use right now. */
    public static float scopeAlpha() {
        return scope;
    }

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
        for (String id : ELEMENTS) {
            try {
                HudElementRegistry.replaceElement(Identifier.fromNamespaceAndPath("minecraft", id),
                        original -> (g, t) -> wrap(original, g, t));
            } catch (Throwable ex) {
                BedrockUiClient.LOG.warn("Could not wrap HUD element {}: {}", id, ex.toString());
            }
        }
    }

    private static void wrap(HudElement original, GuiGraphicsExtractor g, DeltaTracker t) {
        int off = BpConfig.hudOffsetY;
        if (off != 0) {
            g.pose().pushMatrix();
            g.pose().translate(0f, (float) -off);
        }
        scope = BpConfig.hudFade ? current : 1f;
        try {
            original.extractRenderState(g, t);
        } finally {
            scope = 1f;
            if (off != 0) g.pose().popMatrix();
        }
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || !BpConfig.hudFade) {
            current = 1f;
            idleTicks = 0;
            lslot = -1;
            return;
        }
        boolean active = mc.gui.screen() != null;

        double dx = p.getX() - lx;
        double dy = p.getY() - ly;
        double dz = p.getZ() - lz;
        if (dx * dx + dy * dy + dz * dz > 1.0e-4) active = true;
        if (Math.abs(p.getYRot() - lyaw) > 0.5f || Math.abs(p.getXRot() - lpitch) > 0.5f) active = true;
        float health = p.getHealth();
        int food = p.getFoodData().getFoodLevel();
        int slot = p.getInventory().getSelectedSlot();
        if (health != lhealth || food != lfood || slot != lslot) active = true;
        if (mc.options.keyAttack.isDown() || mc.options.keyUse.isDown()) active = true;

        lx = p.getX();
        ly = p.getY();
        lz = p.getZ();
        lyaw = p.getYRot();
        lpitch = p.getXRot();
        lhealth = health;
        lfood = food;
        lslot = slot;

        idleTicks = active ? 0 : idleTicks + 1;
        float target = idleTicks > BpConfig.hudFadeSeconds * 20 ? BpConfig.hudOpacity / 100f : 1f;
        current += (target - current) * (target > current ? 0.45f : 0.07f); // wakes up fast, fades out slowly
        if (Math.abs(target - current) < 0.004f) current = target;
    }
}
