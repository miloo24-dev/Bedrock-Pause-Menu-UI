package dev.bedrockui;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;

/** Enter animation (fade in + slide right) for destination screens, e.g. Options / Mods / Accessibility. */
public final class Transition {
    private static final long ENTER_MS = 300L;
    private static final float SLIDE = 44f;

    private static boolean armed;
    private static Screen active;
    private static long start;
    private static boolean pushed;
    private static Screen registered;

    private Transition() {}

    /** All screen changes from the pause menu go through here. */
    public static void show(Minecraft mc, Screen screen) {
        armed = true;
        try {
            mc.setScreenAndShow(screen); // 26.1: ganti jadi mc.setScreen(screen)
        } finally {
            armed = false;
        }
    }

    static void onScreenInit(Screen screen) {
        if (screen instanceof BedrockPauseScreen || screen instanceof BedrockTitleScreen) return; // the pause menu animates itself
        if (armed) {
            armed = false;
            active = screen;
            start = System.currentTimeMillis();
        }
        if (screen != active || registered == screen) return;
        registered = screen;
        ScreenEvents.beforeExtract(screen).register((s, g, mx, my, td) -> before(s, g));
        ScreenEvents.afterExtract(screen).register((s, g, mx, my, td) -> after(g));
    }

    private static void before(Screen s, GuiGraphicsExtractor g) {
        if (s != active) return;
        float p = BpConfig.animations ? Math.min(1f, (System.currentTimeMillis() - start) / (float) ENTER_MS) : 1f;
        float q = 1f - p;
        float e = 1f - q * q * q * q; // ease-out quart
        for (var child : s.children()) {
            if (child instanceof AbstractWidget w) w.setAlpha(e);
        }
        g.pose().pushMatrix();
        g.pose().translate(-(1f - e) * SLIDE, 0f); // start on the left, slide to the right
        pushed = true;
        if (p >= 1f) active = null;
    }

    private static void after(GuiGraphicsExtractor g) {
        if (pushed) {
            pushed = false;
            g.pose().popMatrix();
        }
    }
}
