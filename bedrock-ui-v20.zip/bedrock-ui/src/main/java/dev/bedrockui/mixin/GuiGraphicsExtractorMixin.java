package dev.bedrockui.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.bedrockui.HudFade;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** HUD fade: sprites drawn while a faded HUD element renders are drawn through the colored overload instead. */
@Mixin(GuiGraphicsExtractor.class)
public abstract class GuiGraphicsExtractorMixin {
    @Inject(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$spriteAlpha(RenderPipeline pipeline, Identifier sprite, int x, int y, int w, int h,
                                       CallbackInfo ci) {
        float a = HudFade.scopeAlpha();
        if (a >= 0.999f) return;
        ((GuiGraphicsExtractor) (Object) this).blitSprite(pipeline, sprite, x, y, w, h, ARGB.color(a, -1));
        ci.cancel();
    }
}
