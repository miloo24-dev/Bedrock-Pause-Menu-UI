package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.multiplayer.LevelLoadTracker;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Bedrock-style loading screen while joining a world. */
@Mixin(LevelLoadingScreen.class)
public abstract class LevelLoadingScreenMixin {
    @Shadow
    @Final
    private LevelLoadTracker loadTracker;

    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$loading(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (!BpConfig.bedrockLoadingScreen) return;
        int progress = Mth.ceil(loadTracker.serverProgress() * 100.0F);
        BedrockLoading.render(g, (Screen) (Object) this, mx, my, a, Component.translatable("multiplayer.downloadingTerrain"), null, progress);
        ci.cancel();
    }
}
