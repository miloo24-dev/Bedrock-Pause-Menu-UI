package dev.bedrockui.mixin;

import dev.bedrockui.BpConfig;
import dev.bedrockui.ContainerAnim;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Close animation hook and the green slot highlight (same targets as BedrockIfy's slot highlight). */
@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Shadow
    protected Slot hoveredSlot;

    @Inject(method = "onClose", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$close(CallbackInfo ci) {
        if (ContainerAnim.interceptClose(this)) {
            ci.cancel();
        }
    }

    @Inject(method = "extractSlotHighlightBack", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$highlightBack(GuiGraphicsExtractor g, CallbackInfo ci) {
        if (!BpConfig.slotHighlight || hoveredSlot == null || !hoveredSlot.isHighlightable()) return;
        ci.cancel();
        int x = hoveredSlot.x - 1;
        int y = hoveredSlot.y - 1;
        int size = 18;
        // soft pulse
        double t = (System.currentTimeMillis() % 1400L) / 1400.0 * Math.PI * 2.0;
        int fill = 0x66 + (int) (0x18 * Math.sin(t));
        g.fill(x, y, x + size, y + size, (fill << 24) | 0x3CD84A);
        int border = 0xFF45D95A;
        int inner = 0xFF9CF5A8;
        // thick 2px green border
        g.fill(x, y, x + size, y + 2, border);
        g.fill(x, y + size - 2, x + size, y + size, border);
        g.fill(x, y + 2, x + 2, y + size - 2, border);
        g.fill(x + size - 2, y + 2, x + size, y + size - 2, border);
        // light inner line
        g.fill(x + 2, y + 2, x + size - 2, y + 3, inner);
        g.fill(x + 2, y + size - 3, x + size - 2, y + size - 2, inner);
        g.fill(x + 2, y + 3, x + 3, y + size - 3, inner);
        g.fill(x + size - 3, y + 3, x + size - 2, y + size - 3, inner);
    }

    @Inject(method = "extractSlotHighlightFront", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$highlightFront(GuiGraphicsExtractor g, CallbackInfo ci) {
        if (BpConfig.slotHighlight) {
            ci.cancel();
        }
    }
}
