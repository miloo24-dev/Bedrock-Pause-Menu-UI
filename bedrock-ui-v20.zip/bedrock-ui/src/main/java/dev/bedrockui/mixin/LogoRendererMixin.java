package dev.bedrockui.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.bedrockui.BpConfig;
import dev.bedrockui.LogoAnim;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** "Hide edition branding" option: skips the "Java Edition" image under the logo (same target as BedrockIfy). */
@Mixin(LogoRenderer.class)
public abstract class LogoRendererMixin {
    @Shadow
    @Final
    private static Identifier MINECRAFT_EDITION;

    @Redirect(
            method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IFI)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIII)V"),
            require = 0)
    private void bedrockui$blit(GuiGraphicsExtractor g, RenderPipeline pipeline, Identifier id,
                                   int a, int b, float c, float d, int e, int f, int h, int i, int j) {
        if (id == MINECRAFT_EDITION && BpConfig.hideEditionBranding) return;
        g.blit(pipeline, id, a, b, c, d, e, f, h, i, j);
    }

    private static final String BP_RENDER = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IFI)V";

    @Inject(method = BP_RENDER, at = @At("HEAD"), require = 0)
    private void bedrockui$logoPre(GuiGraphicsExtractor g, int w, float a, int y, CallbackInfo ci) {
        if (LogoAnim.active) {
            g.pose().pushMatrix();
            g.pose().translate(0f, LogoAnim.offsetY());
            bedrockui$pushed = true;
        }
    }

    @Inject(method = BP_RENDER, at = @At("RETURN"), require = 0)
    private void bedrockui$logoPost(GuiGraphicsExtractor g, int w, float a, int y, CallbackInfo ci) {
        if (bedrockui$pushed) {
            bedrockui$pushed = false;
            g.pose().popMatrix();
        }
    }

    private boolean bedrockui$pushed;
}
