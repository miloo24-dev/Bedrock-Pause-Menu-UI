package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Bedrock-style loading screen while connecting to a server (replaces the centered status text). */
@Mixin(ConnectScreen.class)
public abstract class ConnectScreenMixin {
    @Redirect(method = "extractRenderState",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;centeredText(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V"),
            require = 0)
    private void bedrockui$status(GuiGraphicsExtractor g, Font font, Component status, int x, int y, int color) {
        if (!BpConfig.bedrockLoadingScreen) {
            g.centeredText(font, status, x, y, color);
            return;
        }
        BedrockLoading.render(g, (Screen) (Object) this, 0, 0, 0f, status, null, -1, true);
    }
}
