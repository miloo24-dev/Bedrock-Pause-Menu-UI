package dev.bedrockui.mixin;

import dev.bedrockui.BedrockUiClient;
import dev.bedrockui.BedrockPauseScreen;
import dev.bedrockui.BpConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

    // 26.2: setScreenAndShow, 26.1 and earlier: setScreen
    @ModifyVariable(method = {"setScreenAndShow", "setScreen"}, at = @At("HEAD"), argsOnly = true)
    private Screen bedrockui$swapPauseScreen(Screen screen) {
        if (screen != null && screen.getClass().getName().contains("Pause")) {
            BedrockUiClient.LOG.info("setScreen menerima {}", screen.getClass().getName());
        }
        if (screen instanceof BedrockPauseScreen bedrock) {
            bedrock.replayEnter = true; // coming back from Options etc. -> replay the enter animation
            return screen;
        }
        if (screen != null
                && BpConfig.bedrockPauseMenu
                && screen.getClass() == PauseScreen.class
                && ((PauseScreenAccessor) (Object) screen).bedrockui$showPauseMenu()) {
            return new BedrockPauseScreen((PauseScreen) screen);
        }
        return screen;
    }
}
