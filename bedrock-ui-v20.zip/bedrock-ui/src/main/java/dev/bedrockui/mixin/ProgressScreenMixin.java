package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Bedrock-style loading screen for progress screens (saving, loading, ...). */
@Mixin(ProgressScreen.class)
public abstract class ProgressScreenMixin {
    @Shadow
    private Component stage;

    @Shadow
    private int progress;

    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$progress(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (!BpConfig.bedrockLoadingScreen) return;
        Screen self = (Screen) (Object) this;
        BedrockLoading.render(g, self, mx, my, a, self.getTitle(), stage, progress);
        ci.cancel();
    }
}
