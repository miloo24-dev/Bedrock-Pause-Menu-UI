package dev.bedrockui.mixin;

import dev.bedrockui.ContainerAnim;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The vanilla PauseScreen is never drawn (this mod replaces it with BedrockPauseScreen),
 * so no frame of the vanilla menu can show up before the replacement finishes.
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$hideVanillaPause(CallbackInfo ci) {
        if (((Object) this).getClass() == PauseScreen.class) {
            ci.cancel();
        }
    }

    /** Container screens get their (fading) background from ContainerAnim instead. */
    @Inject(method = "extractBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$containerBackground(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (ContainerAnim.owns(this)) {
            ci.cancel();
        }
    }
}
