package dev.bedrockui;

/** Minecraft logo animation on the title screen: drops in with a small bounce, then floats gently. */
public final class LogoAnim {
    /** True only while BedrockTitleScreen is drawing the vanilla TitleScreen. */
    public static volatile boolean active;
    private static volatile long start = System.currentTimeMillis();

    private LogoAnim() {}

    public static void restart() {
        start = System.currentTimeMillis();
    }

    /** Vertical logo offset (GUI units). */
    public static float offsetY() {
        if (!BpConfig.animations) return 0f;
        float t = (System.currentTimeMillis() - start) / 1000f;
        float d = Math.min(1f, t / 0.7f);
        float s = 1.70158f;
        float k = d - 1f;
        float e = 1f + (s + 1f) * k * k * k + s * k * k; // ease-out-back (bounce)
        float drop = -(1f - e) * 70f;
        float bob = d >= 1f ? (float) Math.sin((t - 0.7f) * 1.4f) * 1.6f : 0f;
        return drop + bob;
    }
}
