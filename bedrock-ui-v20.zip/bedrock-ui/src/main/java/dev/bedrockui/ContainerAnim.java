package dev.bedrockui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

/**
 * Inventory / container animation. Opening: the GUI slides up from the bottom with a small overshoot while the
 * dark background fades in. Closing: the GUI drops back down quickly and the background fades out, then the
 * screen really closes. The vanilla background of these screens is skipped (see ScreenMixin) and drawn here.
 */
public final class ContainerAnim {
    private static final long OPEN_MS = 380L;
    private static final long CLOSE_MS = 200L;
    private static final float SLIDE = 0.30f; // fraction of the screen height

    private static final Map<Screen, Long> OPEN = new WeakHashMap<>();
    private static final Map<Screen, Long> CLOSING = new WeakHashMap<>();
    private static final Set<Screen> RELEASED = Collections.newSetFromMap(new WeakHashMap<>());
    private static boolean pushed;

    private ContainerAnim() {}

    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!BpConfig.containerAnimation) return;
            if (!(screen instanceof AbstractContainerScreen<?>) || OPEN.containsKey(screen)) return;
            OPEN.put(screen, System.currentTimeMillis());
            ScreenEvents.beforeExtract(screen).register((s, g, mx, my, td) -> before(s, g));
            ScreenEvents.afterExtract(screen).register((s, g, mx, my, td) -> after(g));
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick());
    }

    /** True for container screens whose background is drawn by this class. */
    public static boolean owns(Object screen) {
        return BpConfig.containerAnimation && OPEN.containsKey(screen);
    }

    /** Called when a container wants to close. Returns true when the close is postponed for the animation. */
    public static boolean interceptClose(Object screen) {
        if (!owns(screen) || RELEASED.contains(screen) || !BpConfig.animations) return false;
        if (!CLOSING.containsKey(screen)) CLOSING.put((Screen) screen, System.currentTimeMillis());
        return true;
    }

    private static void tick() {
        if (CLOSING.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (Map.Entry<Screen, Long> e : new ArrayList<>(CLOSING.entrySet())) {
            if (now - e.getValue() >= CLOSE_MS) {
                Screen s = e.getKey();
                CLOSING.remove(s);
                RELEASED.add(s);
                s.onClose();
            }
        }
    }

    private static void before(Screen s, GuiGraphicsExtractor g) {
        Long t0 = OPEN.get(s);
        if (t0 == null) return;
        long now = System.currentTimeMillis();
        Long tc = CLOSING.get(s);

        float dim;    // background strength 0..1
        float offset; // downward offset in GUI units
        if (tc != null) {
            float p = Math.min(1f, (now - tc) / (float) CLOSE_MS);
            dim = 1f - p;
            offset = p * p * p * s.height * SLIDE; // ease-in: drops faster and faster
        } else {
            float p = BpConfig.animations ? Math.min(1f, (now - t0) / (float) OPEN_MS) : 1f;
            float q = 1f - p;
            dim = 1f - q * q * q;
            float k = p - 1f;
            float c = 1.35f; // overshoot amount (ease-out-back)
            float e = 1f + (c + 1f) * k * k * k + c * k * k;
            offset = (1f - e) * s.height * SLIDE;
        }

        for (int i = 0; i < 8; i++) {
            int a = (int) ((0xC0 + 0x10 * i / 7) * dim);
            int y1 = s.height * i / 8;
            int y2 = s.height * (i + 1) / 8;
            if (a > 0) g.fill(0, y1, s.width, y2, (a << 24) | 0x101010);
        }

        if (Math.abs(offset) > 0.01f) {
            g.pose().pushMatrix();
            g.pose().translate(0f, offset);
            pushed = true;
        }
    }

    private static void after(GuiGraphicsExtractor g) {
        if (pushed) {
            pushed = false;
            g.pose().popMatrix();
        }
    }
}
