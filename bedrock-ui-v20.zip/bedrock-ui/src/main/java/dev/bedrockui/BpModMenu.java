package dev.bedrockui;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.fabricmc.loader.api.FabricLoader;

/** Config button in Mod Menu. */
public class BpModMenu implements ModMenuApi {
    public BpModMenu() {
        BedrockUiClient.LOG.info("Mod Menu entrypoint BpModMenu loaded");
    }

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        BedrockUiClient.LOG.info("Mod Menu requested the config screen");
        return parent -> FabricLoader.getInstance().isModLoaded("cloth-config")
                ? BpClothScreen.create(parent)
                : parent;
    }
}
