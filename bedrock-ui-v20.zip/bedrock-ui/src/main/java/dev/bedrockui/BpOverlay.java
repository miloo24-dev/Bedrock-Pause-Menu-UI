package dev.bedrockui;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

/** Bedrock-style overlay: coordinates, facing direction, FPS and days played, with a smooth slide-in. */
final class BpOverlay {
    private static long appearStart;
    private static boolean wasActive;

    private BpOverlay() {}

    static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("bedrockui", "overlay"),
                (g, tracker) -> render(g));
    }

    private record Line(String text, int rgb) {}

    private static void render(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        boolean any = BpConfig.showCoordinates || BpConfig.showFps || BpConfig.showDaysPlayed || BpConfig.showDirection;
        boolean active = any && mc.level != null && mc.player != null;
        if (active && !wasActive) appearStart = System.currentTimeMillis();
        wasActive = active;
        if (!active) return;

        List<Line> lines = new ArrayList<>();
        Entity cam = mc.getCameraEntity();
        if (BpConfig.showCoordinates && cam != null) {
            lines.add(new Line("Position: " + cam.getBlockX() + ", " + cam.getBlockY() + ", " + cam.getBlockZ(), 0xFFFFFF));
        }
        if (BpConfig.showDirection && cam != null) {
            Direction d = cam.getDirection();
            String n = d.getName();
            lines.add(new Line("Facing: " + Character.toUpperCase(n.charAt(0)) + n.substring(1), 0xFFFFFF));
        }
        if (BpConfig.showFps) {
            int fps = mc.getFps();
            lines.add(new Line("FPS: " + fps, fps >= 50 ? 0x7CFF7C : fps >= 30 ? 0xFFEB6B : 0xFF6B6B));
        }
        if (BpConfig.showDaysPlayed) lines.add(new Line("Days played: " + days(mc), 0xFFFFFF));

        float p = BpConfig.animations ? Math.min(1f, (System.currentTimeMillis() - appearStart) / 420f) : 1f;
        float q = 1f - p;
        float e = 1f - q * q * q;
        int alpha = (int) (255 * e);
        if (alpha < 8) return;

        int screenW = mc.getWindow().getGuiScaledWidth();
        int top = Math.max(26, (int) (mc.getWindow().getGuiScaledHeight() * BpConfig.overlayY / 100f));
        int slide = (int) ((1f - e) * 30f);
        int y = top;
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            Component c = Component.literal(l.text());
            int w = mc.font.width(c);
            int boxW = w + 10;
            int x = BpConfig.overlayRight ? screenW - boxW - 2 + slide : 2 - slide;
            // stagger each line a little for a smooth cascade
            float lp = Math.max(0f, Math.min(1f, e * 1.4f - i * 0.18f));
            int la = (int) (alpha * lp);
            if (la < 8) {
                y += 15;
                continue;
            }
            g.fill(x, y - 2, x + boxW, y + 11, ((int) (0x90 * lp) << 24));
            g.text(mc.font, c, x + 5, y, (la << 24) | l.rgb());
            y += 15;
        }
    }

    /** Whole in-game days since the world was created (game time / 24000), with fallbacks across versions. */
    private static long days(Minecraft mc) {
        Object level = mc.level;
        long ticks = tryLong(level, "getGameTime");
        if (ticks < 0) {
            try {
                Object data = level.getClass().getMethod("getLevelData").invoke(level);
                ticks = tryLong(data, "getGameTime");
            } catch (Throwable ignored) {
                // no level data accessor
            }
        }
        return ticks < 0 ? 0L : ticks / 24000L;
    }

    private static long tryLong(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            return ((Number) m.invoke(target)).longValue();
        } catch (Throwable t) {
            return -1L;
        }
    }
}
