package dev.bedrockui;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;

/**
 * Draws Mod Menu's own "mods" icon by finding its texture/sprite inside the Mod Menu jar at runtime,
 * so the title screen button looks exactly like the one Mod Menu adds to the pause menu.
 */
final class ModMenuIcon {
    private static boolean searched;
    private static Identifier sprite;
    private static Identifier texture;
    private static int texW;
    private static int texH;

    private ModMenuIcon() {}

    private static void find() {
        if (searched) return;
        searched = true;
        try {
            var container = FabricLoader.getInstance().getModContainer("modmenu");
            if (container.isEmpty()) return;
            List<String> found = new ArrayList<>();
            for (Path root : container.get().getRootPaths()) {
                Path gui = root.resolve("assets/modmenu/textures/gui");
                if (!Files.isDirectory(gui)) continue;
                try (Stream<Path> s = Files.walk(gui)) {
                    s.filter(p -> p.toString().endsWith(".png")).forEach(p -> found.add(gui.relativize(p).toString().replace('\\', '/')));
                }
                BedrockUiClient.LOG.info("Mod Menu gui textures: {}", found);
                String best = null;
                for (String f : found) {
                    String n = f.toLowerCase();
                    boolean spriteDir = n.startsWith("sprites/");
                    String base = n.substring(n.lastIndexOf('/') + 1);
                    if (base.startsWith("mods") && !base.contains("update") && (best == null || spriteDir)) best = f;
                }
                if (best == null) continue;
                if (best.startsWith("sprites/")) {
                    sprite = Identifier.fromNamespaceAndPath("modmenu", best.substring("sprites/".length(), best.length() - 4));
                } else {
                    texture = Identifier.fromNamespaceAndPath("modmenu", "textures/gui/" + best);
                    try (InputStream in = Files.newInputStream(gui.resolve(best))) {
                        byte[] h = in.readNBytes(24);
                        texW = ((h[16] & 255) << 24) | ((h[17] & 255) << 16) | ((h[18] & 255) << 8) | (h[19] & 255);
                        texH = ((h[20] & 255) << 24) | ((h[21] & 255) << 16) | ((h[22] & 255) << 8) | (h[23] & 255);
                    }
                }
                BedrockUiClient.LOG.info("Mod Menu icon: sprite={}, texture={} ({}x{})", sprite, texture, texW, texH);
                return;
            }
        } catch (Throwable t) {
            BedrockUiClient.LOG.warn("Could not look for the Mod Menu icon: {}", t.toString());
        }
    }

    /** Returns true when the real Mod Menu icon was drawn. */
    static boolean draw(GuiGraphicsExtractor g, AbstractWidget w, int alpha) {
        find();
        try {
            RenderPipeline pipeline = RenderPipelines.GUI_TEXTURED;
            int color = ARGB.color(Math.min(255, Math.max(0, alpha)) / 255f, -1);
            if (sprite != null) {
                g.blitSprite(pipeline, sprite, w.getX(), w.getY(), w.getWidth(), w.getHeight(), color);
                return true;
            }
            if (texture != null && texW > 0 && texH > 0) {
                int s = Math.min(Math.min(texW, texH), 20);
                g.blit(pipeline, texture, w.getX() + (w.getWidth() - s) / 2, w.getY() + (w.getHeight() - s) / 2,
                        0f, 0f, s, s, texW, texH);
                return true;
            }
        } catch (Throwable t) {
            sprite = null;
            texture = null;
        }
        return false;
    }
}
