package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BedrockUiClient;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Bedrock-style startup loading screen, drawn over the vanilla overlay once it finished drawing. */
@Mixin(LoadingOverlay.class)
public abstract class LoadingOverlayMixin {
    private static int bedrockui$failures;

    @Inject(method = "extractRenderState", at = @At("RETURN"), require = 0)
    private void bedrockui$startup(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (!BpConfig.bedrockStartupScreen || bedrockui$failures >= 3) return;
        try {
            BedrockLoading.renderStartup(g, this);
        } catch (Throwable t) {
            // never let the startup screen crash the game: after a few failures the vanilla screen is left alone
            bedrockui$failures++;
            BedrockUiClient.LOG.warn("Startup screen failed ({}): {}", bedrockui$failures, t.toString());
        }
    }
}
