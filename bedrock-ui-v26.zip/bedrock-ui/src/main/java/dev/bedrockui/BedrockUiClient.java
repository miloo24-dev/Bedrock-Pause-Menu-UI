package dev.bedrockui;

import dev.bedrockui.mixin.PauseScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockUiClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("bedrockui");

    /** Fallback: a vanilla pause screen that slipped through is replaced at the end of the tick. */
    private static PauseScreen pending;

    /** Vanilla PauseScreen just replaced directly by BEFORE_INIT (so AFTER_INIT ignores it). */
    private static PauseScreen swappedFrom;

    /** True while this mod itself initializes a vanilla screen (to borrow its widgets). */
    public static volatile boolean suppressFallback;

    @Override
    public void onInitializeClient() {
        BpConfig.load();
        BpOverlay.register();
        HudFade.register();
        LOG.info("Bedrock UI loaded (build 25, pause={}, title={}, animations={})", BpConfig.bedrockPauseMenu, BpConfig.bedrockTitleScreen, BpConfig.animations);

        // Replace BEFORE the vanilla screen gets initialized/drawn -> no flash of the vanilla menu.
        ScreenEvents.BEFORE_INIT.register((client, screen, w, h) -> {
            if (suppressFallback) return;
            if (screen.getClass() == PauseScreen.class && client.level == null) {
                // A PauseScreen opened as the "parent" of a borrowed widget while no world is loaded: go back to the title screen
                try {
                    client.setScreenAndShow(BpConfig.bedrockTitleScreen
                            ? new BedrockTitleScreen(new TitleScreen())
                            : new TitleScreen());
                } catch (Throwable t) {
                    LOG.error("Failed to return to the title screen", t);
                }
                return;
            }
            if (BpConfig.bedrockTitleScreen && screen.getClass() == TitleScreen.class) {
                try {
                    LOG.info("title screen replaced");
                    client.setScreenAndShow(new BedrockTitleScreen((TitleScreen) screen));
                } catch (Throwable t) {
                    LOG.error("Failed to replace the title screen", t);
                }
                return;
            }
            if (BpConfig.bedrockSettings && screen.getClass() == OptionsScreen.class) {
                try {
                    client.setScreenAndShow(new BedrockSettingsScreen(BedrockSettingsScreen.parentOf(screen)));
                } catch (Throwable t) {
                    LOG.error("Failed to open the Bedrock settings screen", t);
                }
                return;
            }
            if (!BpConfig.bedrockPauseMenu || screen.getClass() != PauseScreen.class || !showsMenu(screen)) return;
            try {
                swappedFrom = (PauseScreen) screen;
                LOG.info("swap via BEFORE_INIT");
                client.setScreenAndShow(new BedrockPauseScreen((PauseScreen) screen));
            } catch (Throwable t) {
                swappedFrom = null;
                LOG.error("Direct swap failed, using the tick fallback", t);
                pending = (PauseScreen) screen;
            }
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            Transition.onScreenInit(screen);
            if (suppressFallback || screen.getClass() != PauseScreen.class) return;
            if (screen == swappedFrom) {
                swappedFrom = null;
                return;
            }
            if (!BpConfig.bedrockPauseMenu) return;
            if (showsMenu(screen)) {
                // BEFORE_INIT did not replace it: replace it right now (before the first frame is drawn)
                LOG.info("swap via AFTER_INIT");
                try {
                    client.setScreenAndShow(new BedrockPauseScreen((PauseScreen) screen));
                } catch (Throwable t) {
                    LOG.warn("Swap in AFTER_INIT failed, using the tick fallback: {}", t.toString());
                    pending = (PauseScreen) screen;
                }
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PauseScreen p = pending;
            pending = null;
            if (p != null) {
                LOG.info("swap via END_CLIENT_TICK");
                client.setScreenAndShow(new BedrockPauseScreen(p));
            }
        });
    }

    private static boolean showsMenu(Screen screen) {
        try {
            return ((PauseScreenAccessor) (Object) screen).bedrockui$showPauseMenu();
        } catch (Throwable t) {
            LOG.warn("showPauseMenu accessor failed: {}", t.toString());
            return true;
        }
    }
}
