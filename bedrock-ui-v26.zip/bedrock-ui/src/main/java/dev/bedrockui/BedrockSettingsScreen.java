package dev.bedrockui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

/**
 * Bedrock-style settings screen: light header with a back arrow, a category sidebar on the left and the
 * options of the selected category on the right. Only options that exist in Java Edition are listed. The
 * options themselves are the vanilla widgets, borrowed from a hidden vanilla OptionsScreen.
 */
public class BedrockSettingsScreen extends Screen {
    private static final Logger LOG = BedrockUiClient.LOG;

    /** Hidden vanilla OptionsScreen -> the screen the settings were opened from. */
    static final Map<Screen, Screen> REAL_PARENT = new WeakHashMap<>();

    private static final String[] CATS = {"Accessibility", "Keyboard & Mouse", "General", "Video", "Audio", "Resource Packs"};
    private static final int[] ICON_RGB = {0x2D6CF0, 0x8A8A8A, 0xB5651D, 0x3A9A3A, 0xB5442C, 0x7A5BC4};
    private static final String[][] KEYS = {
            {"accessib", "chat"},
            {"control", "mouse", "keybind"},
            {"language", "skin", "difficulty", "online", "telemetry"},
            {"video", "fov"},
            {"sound", "music", "volume"},
            {"resourcepack", "resource"}
    };

    private final Screen parent;
    private final List<AbstractWidget> borrowed = new ArrayList<>();
    private final List<AbstractWidget> pane = new ArrayList<>();
    private final List<Button> side = new ArrayList<>();
    private int selected = 2;
    private int headerH = 24;
    private int sideW;
    private int rowH = 34;

    public BedrockSettingsScreen(Screen parent) {
        super(Component.literal("Settings"));
        this.parent = parent;
    }

    /** The screen a vanilla OptionsScreen was opened from. */
    static Screen parentOf(Screen options) {
        Screen p = REAL_PARENT.get(options);
        if (p != null) return p;
        try {
            for (Class<?> c = options.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (Screen.class.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true);
                        Object v = f.get(options);
                        if (v instanceof Screen s && s != options) return s;
                    }
                }
            }
        } catch (Throwable t) {
            LOG.warn("Could not find the parent of the options screen: {}", t.toString());
        }
        return null;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // intentionally empty: everything is drawn in extractRenderState
    }

    private static void callInit(Screen target, net.minecraft.client.Minecraft mc, int w, int h) throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(mc) && t[1] == int.class && t[2] == int.class) {
                m.invoke(target, mc, w, h);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(target, w, h);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    private void borrowVanillaOptions() {
        borrowed.clear();
        BedrockUiClient.suppressFallback = true;
        try {
            OptionsScreen tmp = new OptionsScreen(this, minecraft.options, false);
            REAL_PARENT.put(tmp, parent);
            callInit(tmp, minecraft, width, height);
            for (Object o : tmp.children()) {
                if (o instanceof AbstractWidget w && !(w instanceof StringWidget) && w.getWidth() >= 50) {
                    String t = text(w);
                    if (t.contains("done")) continue;
                    borrowed.add(w);
                }
            }
        } catch (Throwable t) {
            LOG.error("Could not borrow the vanilla option widgets", t);
        } finally {
            BedrockUiClient.suppressFallback = false;
        }
    }

    private static String text(AbstractWidget w) {
        return (String.valueOf(w.getMessage().getContents()) + " " + w.getMessage().getString()).toLowerCase();
    }

    private int categoryOf(AbstractWidget w) {
        String t = text(w);
        for (int i = 0; i < KEYS.length; i++) {
            for (String k : KEYS[i]) if (t.contains(k)) return i;
        }
        return 2; // unknown options go to General
    }

    private static String describe(String t) {
        if (t.contains("video")) return "Graphics, render distance and performance";
        if (t.contains("sound") || t.contains("music")) return "Music, sound effects and voices";
        if (t.contains("control")) return "Key binds and mouse settings";
        if (t.contains("language")) return "Change the language of the game";
        if (t.contains("skin")) return "Choose which parts of your skin are shown";
        if (t.contains("resourcepack") || t.contains("resource")) return "Textures, sounds and other packs";
        if (t.contains("accessib")) return "Make Minecraft easier to use";
        if (t.contains("chat")) return "Chat visibility, colors and size";
        if (t.contains("fov")) return "How wide your field of view is";
        if (t.contains("difficulty")) return "How hard the game is";
        if (t.contains("online")) return "Online options";
        if (t.contains("telemetry")) return "Data sharing options";
        return "";
    }

    @Override
    protected void init() {
        pane.clear();
        side.clear();
        sideW = Math.max(110, (int) (width * 0.30f));
        borrowVanillaOptions();

        addRenderableWidget(Button.builder(Component.literal("<"), b -> onClose()).bounds(4, 2, 24, 20).build());

        int y = headerH + 8;
        for (int i = 0; i < CATS.length; i++) {
            if (i == 1 || i == 2) y += 14; // room for the group heading ("Controls", "General")
            final int idx = i;
            Button b = Button.builder(Component.literal(""), btn -> {
                selected = idx;
                buildPane();
            }).bounds(0, y, sideW, 24).build();
            side.add(b);
            addRenderableWidget(b);
            y += 26;
        }
        buildPane();
    }

    private void buildPane() {
        for (AbstractWidget w : pane) removeWidget(w);
        pane.clear();
        List<AbstractWidget> rows = new ArrayList<>();
        for (AbstractWidget w : borrowed) if (categoryOf(w) == selected) rows.add(w);
        int avail = height - headerH - 16;
        rowH = Math.max(26, Math.min(36, rows.isEmpty() ? 34 : avail / rows.size()));
        int ww = Math.min(140, Math.max(90, (int) ((width - sideW) * 0.38f)));
        int y = headerH + 8;
        for (AbstractWidget w : rows) {
            w.setWidth(ww);
            w.setX(width - ww - 12);
            w.setY(y + (rowH - 20) / 2);
            w.setAlpha(1f);
            addRenderableWidget(w);
            pane.add(w);
            y += rowH;
        }
    }

    private static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        // backgrounds
        fill(g, 0, 0, width, height, 0xFF454547);
        fill(g, 0, headerH, sideW, height, 0xFF2D2D2F);
        fill(g, sideW, headerH, sideW + 2, height, 0xFF1E1E1F);

        // header
        fill(g, 0, 0, width, headerH, 0xFFE9EAEC);
        fill(g, 0, headerH, width, headerH + 2, 0xFF8D8E91);
        Component title = Component.literal("SETTINGS").withStyle(ChatFormatting.BOLD);
        g.text(font, title, (width - font.width(title)) / 2, (headerH - 8) / 2, 0xFF1E1E1F, false);

        // rows on the right: label, description and separator
        int y = headerH + 8;
        for (AbstractWidget w : pane) {
            String label = w.getMessage().getString();
            g.text(font, Component.literal(label), sideW + 12, y + (rowH - 18) / 2, 0xFFFFFFFF, false);
            String d = describe(text(w));
            if (!d.isEmpty()) g.text(font, Component.literal(d), sideW + 12, y + (rowH - 18) / 2 + 10, 0xFFB5B5B8, false);
            fill(g, sideW + 4, y + rowH - 1, width - 4, y + rowH, 0xFF5E5E61);
            y += rowH;
        }
        if (pane.isEmpty()) {
            g.text(font, Component.literal("Nothing to show here."), sideW + 12, headerH + 16, 0xFFB5B5B8, false);
        }

        super.extractRenderState(g, mx, my, a); // buttons (back arrow, sidebar rows, option widgets)

        // sidebar rows drawn over their (invisible) buttons
        for (int i = 0; i < side.size(); i++) {
            Button b = side.get(i);
            int by = b.getY();
            boolean hover = mx >= 0 && mx < sideW && my >= by && my < by + 24;
            fill(g, 0, by, sideW, by + 24, i == selected ? 0xFF454547 : hover ? 0xFF38383A : 0xFF2D2D2F);
            fill(g, 0, by + 23, sideW, by + 24, 0xFF1E1E1F);
            int ix = 8;
            int iy = by + 4;
            fill(g, ix - 1, iy - 1, ix + 17, iy + 17, 0xFF1E1E1F);
            fill(g, ix, iy, ix + 16, iy + 16, 0xFF000000 | ICON_RGB[i]);
            String ini = CATS[i].substring(0, 1);
            g.text(font, Component.literal(ini), ix + (16 - font.width(ini)) / 2, iy + 4, 0xFFFFFFFF, false);
            g.text(font, Component.literal(CATS[i]), ix + 24, by + 8, 0xFFFFFFFF, false);
            if (i == 1) g.text(font, Component.literal("Controls"), 8, by - 12, 0xFFA0A0A4, false);
            if (i == 2) g.text(font, Component.literal("General"), 8, by - 12, 0xFFA0A0A4, false);
        }
    }
}
