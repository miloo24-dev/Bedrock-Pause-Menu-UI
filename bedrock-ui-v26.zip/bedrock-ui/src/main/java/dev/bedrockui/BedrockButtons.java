package dev.bedrockui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.network.chat.Component;

/**
 * Bedrock-style button look, drawn over the vanilla button: light gray body with a thin dark outline and subtle shading,
 * dark text; on hover the button turns green with a white outline (it does not change size).
 */
final class BedrockButtons {
    private BedrockButtons() {}

    private static void rect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int rgb, int a) {
        if (a <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(a, 255) << 24) | rgb);
    }

    static void draw(GuiGraphicsExtractor g, Font font, AbstractWidget w, int mx, int my, float alpha) {
        int a = (int) (255 * Math.max(0f, Math.min(1f, alpha)));
        if (a <= 4) return;
        Component label = w.getMessage();
        int x = w.getX();
        int y = w.getY();
        int bw = w.getWidth();
        int bh = w.getHeight();
        boolean hover = w.active && mx >= x && mx < x + bw && my >= y && my < y + bh;

        if (hover) {
            // green body with a thin white outline inside the button bounds (no size change), light shading
            rect(g, x - 1, y - 1, x + bw + 1, y + bh + 1, 0x1E1E1F, a);
            rect(g, x, y, x + bw, y + bh, 0xFFFFFF, a);
            rect(g, x + 1, y + 1, x + bw - 1, y + bh - 1, 0x3C8527, a);
            rect(g, x + 1, y + 1, x + bw - 1, y + 2, 0x4A9A31, a);
            rect(g, x + 1, y + bh - 3, x + bw - 1, y + bh - 1, 0x2F6D20, a);
        } else {
            boolean on = w.active;
            rect(g, x - 1, y - 1, x + bw + 1, y + bh + 1, 0x1E1E1F, a);
            rect(g, x, y, x + bw, y + bh, on ? 0xD0D1D4 : 0x8E8E90, a);
            rect(g, x, y, x + bw, y + 1, on ? 0xE6E7E9 : 0x9C9C9E, a);
            rect(g, x, y + bh - 2, x + bw, y + bh, on ? 0xA9AAAE : 0x777779, a);
        }
        int text = hover ? 0xFFFFFF : (w.active ? 0x3A3A3C : 0x505050);

        if (label != null) {
            int tw = font.width(label);
            g.text(font, label, x + (bw - tw) / 2, y + (bh - 8) / 2, (a << 24) | text, false);
        }
    }
}
