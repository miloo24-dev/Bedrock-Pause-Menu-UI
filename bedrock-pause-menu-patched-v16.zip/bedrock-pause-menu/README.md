# Bedrock UI (Bedrock Pause Menu)

A Fabric mod for Minecraft Java 26.2 that gives the game a Minecraft Bedrock Edition look.

## Features
- Bedrock-style **pause menu** (slide/fade transitions, player skin display, small icon buttons).
- Bedrock-style **title screen** with an animated logo and a smooth, cursor-following player skin.
- Top-left **overlay** with coordinates, FPS and days played.
- Option to hide the "Java Edition" branding under the logo.
- In-game **config screen**: Mod Menu -> Bedrock Pause Menu -> Configure (needs Cloth Config).

## Requirements
- Fabric Loader 0.20.1+ and Fabric API
- Optional: Mod Menu and Cloth Config API (for the config screen)

## Building
`gradle build` with Java 25. The jar is written to `build/libs/`.

## Credits
Some GUI features are based on BedrockIfy by juancarloscp52 (GPL-3.0), used with the author's permission.
