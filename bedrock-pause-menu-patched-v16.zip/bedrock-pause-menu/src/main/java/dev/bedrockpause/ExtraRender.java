package dev.bedrockpause;

import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.LivingEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Logo & player model. Called via reflection because method names change often
 * between versions; if it fails this part is simply skipped (the menu keeps working).
 */
final class ExtraRender {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    private static Object logo;
    private static Method logoMethod;
    private static boolean logoFailed;

    private static Method playerMethod;
    private static boolean playerFailed;

    private ExtraRender() {}

    static void logo(GuiGraphicsExtractor g, int width, float alpha) {
        if (logoFailed) return;
        try {
            if (logo == null) {
                Class<?> c = Class.forName("net.minecraft.client.gui.components.LogoRenderer");
                logo = c.getConstructor(boolean.class).newInstance(false);
                for (Method m : c.getMethods()) {
                    Class<?>[] t = m.getParameterTypes();
                    if (t.length == 3 && t[0] == GuiGraphicsExtractor.class && t[1] == int.class) {
                        logoMethod = m;
                        break;
                    }
                }
                if (logoMethod == null) throw new NoSuchMethodException("LogoRenderer render method");
            }
            logoMethod.invoke(logo, g, width, alpha);
        } catch (Throwable t) {
            logoFailed = true;
            LOG.warn("Logo rendering disabled: {}", t.toString());
        }
    }

    static void player(GuiGraphicsExtractor g, int x0, int y0, int x1, int y1, int scale, int mx, int my) {
        if (playerFailed) return;
        LivingEntity p = Minecraft.getInstance().player;
        if (p == null) return;
        try {
            if (playerMethod == null) {
                for (Method m : InventoryScreen.class.getMethods()) {
                    if (m.getParameterCount() == 10 && m.getName().contains("FollowsMouse")) {
                        playerMethod = m;
                        break;
                    }
                }
                if (playerMethod == null) throw new NoSuchMethodException("InventoryScreen *FollowsMouse");
            }
            double[] v = {x0, y0, x1, y1, scale, 0.0625, mx, my};
            Class<?>[] types = playerMethod.getParameterTypes();
            Object[] args = new Object[10];
            args[0] = g;
            for (int i = 1; i <= 8; i++) {
                args[i] = types[i] == int.class ? (Object) (int) Math.round(v[i - 1]) : (Object) (float) v[i - 1];
            }
            args[9] = p;
            playerMethod.invoke(null, args);
        } catch (Throwable t) {
            playerFailed = true;
            LOG.warn("Player model disabled: {}", t.toString());
        }
    }
}
