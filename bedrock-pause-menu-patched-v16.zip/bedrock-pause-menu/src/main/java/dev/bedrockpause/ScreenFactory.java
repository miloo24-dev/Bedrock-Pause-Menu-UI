package dev.bedrockpause;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Creates vanilla screens (Statistics, Options, Mod Menu, ...) via reflection.
 * Constructor arguments are matched by type, so changes in parameter order
 * between versions do not matter. On failure it returns null (the menu is shown again).
 */
final class ScreenFactory {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    private ScreenFactory() {}

    static Screen advancements(Screen parent) {
        Minecraft mc = Minecraft.getInstance();
        Object adv = findByReturnType(mc.getConnection(), "ClientAdvancements");
        return create("net.minecraft.client.gui.screens.advancements.AdvancementsScreen", parent, adv);
    }

    static Screen stats(Screen parent) {
        Minecraft mc = Minecraft.getInstance();
        Object stats = findByReturnType(mc.player, "StatsCounter");
        return create("net.minecraft.client.gui.screens.achievement.StatsScreen", parent, stats);
    }

    static Screen social(Screen parent) {
        return create("net.minecraft.client.gui.screens.social.SocialInteractionsScreen", parent);
    }

    static Screen lan(Screen parent) {
        return create("net.minecraft.client.gui.screens.ShareToLanScreen", parent);
    }

    private static Object findByReturnType(Object target, String simpleName) {
        if (target == null) return null;
        try {
            for (Method m : target.getClass().getMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType().getSimpleName().equals(simpleName)) {
                    return m.invoke(target);
                }
            }
        } catch (Throwable t) {
            LOG.warn("Failed to get {}: {}", simpleName, t.toString());
        }
        return null;
    }

    static Screen create(String className, Object... candidates) {
        try {
            Class<?> c = Class.forName(className);
            outer:
            for (Constructor<?> k : c.getDeclaredConstructors()) {
                Class<?>[] types = k.getParameterTypes();
                Object[] args = new Object[types.length];
                for (int i = 0; i < types.length; i++) {
                    Object match = null;
                    for (Object cand : candidates) {
                        if (cand != null && types[i].isInstance(cand)) {
                            match = cand;
                            break;
                        }
                    }
                    if (match == null) continue outer;
                    args[i] = match;
                }
                k.setAccessible(true);
                return (Screen) k.newInstance(args);
            }
            throw new NoSuchMethodException("No matching constructor for " + className);
        } catch (Throwable t) {
            LOG.error("Failed to open screen {}", className, t);
            return null;
        }
    }
}
