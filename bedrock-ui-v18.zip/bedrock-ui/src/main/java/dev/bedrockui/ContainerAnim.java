package dev.bedrockui;

import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

/**
 * Inventory / container animation: the GUI slides up from the bottom while the dark background fades in.
 * The vanilla background of these screens is skipped (see ScreenMixin) and drawn here instead, outside the slide.
 */
public final class ContainerAnim {
    private static final long MS = 320L;
    private static final Map<Screen, Long> OPEN = new WeakHashMap<>();
    private static boolean pushed;

    private ContainerAnim() {}

    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!BpConfig.containerAnimation) return;
            if (!(screen instanceof AbstractContainerScreen<?>) || OPEN.containsKey(screen)) return;
            OPEN.put(screen, System.currentTimeMillis());
            ScreenEvents.beforeExtract(screen).register((s, g, mx, my, td) -> before(s, g));
            ScreenEvents.afterExtract(screen).register((s, g, mx, my, td) -> after(g));
        });
    }

    /** True for container screens whose background is drawn by this class. */
    public static boolean owns(Object screen) {
        return BpConfig.containerAnimation && OPEN.containsKey(screen);
    }

    private static void before(Screen s, GuiGraphicsExtractor g) {
        Long t0 = OPEN.get(s);
        if (t0 == null) return;
        float p = BpConfig.animations ? Math.min(1f, (System.currentTimeMillis() - t0) / (float) MS) : 1f;
        float q = 1f - p;
        float e = 1f - q * q * q * q; // ease-out quart

        // Dark background (same colors as the vanilla dim), fading in; drawn before the slide so it stays put
        for (int i = 0; i < 8; i++) {
            int a = (int) ((0xC0 + 0x10 * i / 7) * e);
            int y1 = s.height * i / 8;
            int y2 = s.height * (i + 1) / 8;
            if (a > 0) g.fill(0, y1, s.width, y2, (a << 24) | 0x101010);
        }

        if (p < 1f) {
            g.pose().pushMatrix();
            g.pose().translate(0f, (1f - e) * s.height * 0.18f);
            pushed = true;
        }
    }

    private static void after(GuiGraphicsExtractor g) {
        if (pushed) {
            pushed = false;
            g.pose().popMatrix();
        }
    }
}
