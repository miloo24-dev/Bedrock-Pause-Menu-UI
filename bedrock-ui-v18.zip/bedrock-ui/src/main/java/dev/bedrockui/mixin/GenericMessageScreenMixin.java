package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.GenericMessageScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Bedrock-style loading screen for simple message screens (e.g. "Saving world"). */
@Mixin(GenericMessageScreen.class)
public abstract class GenericMessageScreenMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$message(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (!BpConfig.bedrockLoadingScreen) return;
        Screen self = (Screen) (Object) this;
        BedrockLoading.render(g, self.getTitle(), null, -1);
        ci.cancel();
    }
}
