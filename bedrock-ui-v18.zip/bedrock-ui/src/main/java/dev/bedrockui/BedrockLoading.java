package dev.bedrockui;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.network.chat.Component;

/** Bedrock-style loading screen: dark background, logo, progress bar, percentage and a rotating tip. */
public final class BedrockLoading {
    private static final LogoRenderer LOGO = new LogoRenderer(false);
    private static final String[] TIPS = {
            "Place a bed and sleep to skip the night.",
            "Sprinting makes you hungrier, so keep some food around.",
            "A crafting table unlocks many more recipes.",
            "Torches stop monsters from spawning around them.",
            "A bucket of water can break a long fall.",
            "Hold Shift while walking to avoid falling off edges.",
            "Pickaxes mine stone, axes chop wood and shovels dig dirt faster.",
            "Furnaces smelt ores and cook food.",
            "Eating restores your hunger bar and helps you heal.",
            "Wolves can be tamed with bones.",
            "Sleeping in a bed sets your spawn point.",
            "Diamonds are usually found deep underground.",
            "You can trade with villagers using emeralds.",
            "Chests keep your items safe while you explore."
    };
    private static final Random RANDOM = new Random();
    private static int tipIndex = -1;
    private static long tipTime;
    private static final long START = System.currentTimeMillis();

    private BedrockLoading() {}

    private static String tip() {
        long now = System.currentTimeMillis();
        if (tipIndex < 0 || now - tipTime > 6000L) {
            tipIndex = RANDOM.nextInt(TIPS.length);
            tipTime = now;
        }
        return "Tip: " + TIPS[tipIndex];
    }

    /** progress: 0-100, or a negative value for an indeterminate bar. */
    public static void render(GuiGraphicsExtractor g, Component title, Component subtitle, int progress) {
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        g.fill(0, 0, w, h / 2, 0xFF1B1511);
        g.fill(0, h / 2, w, h, 0xFF110D0A);

        LOGO.extractRenderState(g, w, 1.0f, Math.max(8, h / 2 - 90));

        int cy = h / 2 - 6;
        if (title != null) g.centeredText(mc.font, title, w / 2, cy, 0xFFFFFFFF);

        int bw = Math.min(220, w - 40);
        int bx = (w - bw) / 2;
        int by = cy + 14;
        int bh = 8;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFF000000);
        g.fill(bx, by, bx + bw, by + bh, 0xFF3C3C3C);
        if (progress >= 0) {
            int fw = bw * Math.min(100, progress) / 100;
            g.fill(bx, by, bx + fw, by + bh, 0xFF3FB83F);
            g.fill(bx, by, bx + fw, by + 2, 0xFF7BE07B);
            g.fill(bx, by + bh - 2, bx + fw, by + bh, 0xFF2A8A2A);
        } else {
            int seg = bw / 4;
            float t = ((System.currentTimeMillis() - START) % 1600L) / 1600f;
            int start = (int) (t * (bw + seg)) - seg;
            int x1 = Math.max(0, start);
            int x2 = Math.min(bw, start + seg);
            if (x2 > x1) {
                g.fill(bx + x1, by, bx + x2, by + bh, 0xFF3FB83F);
                g.fill(bx + x1, by, bx + x2, by + 2, 0xFF7BE07B);
            }
        }

        Component sub = progress >= 0 ? Component.literal(progress + "%") : subtitle;
        if (sub != null) g.centeredText(mc.font, sub, w / 2, by + bh + 6, 0xFFB0B0B0);

        g.centeredText(mc.font, Component.literal(tip()), w / 2, h - 34, 0xFFC8C8C8);
    }
}
