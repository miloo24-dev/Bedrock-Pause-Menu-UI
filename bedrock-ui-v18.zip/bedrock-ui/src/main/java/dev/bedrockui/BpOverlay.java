package dev.bedrockui;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

/** Bedrock-style top-left overlay: coordinates, FPS, days played. */
final class BpOverlay {
    private BpOverlay() {}

    static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("bedrockui", "overlay"),
                (g, tracker) -> render(g));
    }

    private static void render(GuiGraphicsExtractor g) {
        if (!BpConfig.showCoordinates && !BpConfig.showFps && !BpConfig.showDaysPlayed) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        List<String> lines = new ArrayList<>();
        Entity cam = mc.getCameraEntity();
        if (BpConfig.showCoordinates && cam != null) {
            lines.add("Position: " + cam.getBlockX() + ", " + cam.getBlockY() + ", " + cam.getBlockZ());
        }
        if (BpConfig.showFps) lines.add("FPS: " + mc.getFps());
        if (BpConfig.showDaysPlayed) lines.add("Days played: " + days(mc));

        int y = Math.max(30, (int) (mc.getWindow().getGuiScaledHeight() * 0.2f));
        for (String s : lines) {
            Component c = Component.literal(s);
            int w = mc.font.width(c);
            g.fill(2, y - 2, 2 + w + 8, y + 11, 0x90000000);
            g.text(mc.font, c, 6, y, 0xFFFFFFFF);
            y += 15;
        }
    }

    /** Whole in-game days since the world was created (game time / 24000), with fallbacks across versions. */
    private static long days(Minecraft mc) {
        Object level = mc.level;
        long ticks = tryLong(level, "getGameTime");
        if (ticks < 0) {
            try {
                Object data = level.getClass().getMethod("getLevelData").invoke(level);
                ticks = tryLong(data, "getGameTime");
            } catch (Throwable ignored) {
                // no level data accessor
            }
        }
        return ticks < 0 ? 0L : ticks / 24000L;
    }

    private static long tryLong(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            return ((Number) m.invoke(target)).longValue();
        } catch (Throwable t) {
            return -1L;
        }
    }
}
