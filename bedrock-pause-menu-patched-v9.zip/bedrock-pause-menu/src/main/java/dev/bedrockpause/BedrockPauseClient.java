package dev.bedrockpause;

import dev.bedrockpause.mixin.PauseScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    /** Pause screen vanilla yang lolos dari mixin; diganti pada akhir tick (fallback). */
    private static PauseScreen pending;

    /** True saat mod sendiri men-init PauseScreen vanilla (untuk meminjam tombolnya); fallback jangan ikut jalan. */
    public static volatile boolean suppressFallback;

    @Override
    public void onInitializeClient() {
        LOG.info("Bedrock Pause Menu loaded");

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            Transition.onScreenInit(screen);
            if (!suppressFallback && screen.getClass() == PauseScreen.class && showsMenu(screen)) {
                LOG.warn("Vanilla PauseScreen muncul (mixin swap tidak jalan) -> pakai fallback");
                pending = (PauseScreen) screen;
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PauseScreen p = pending;
            pending = null;
            if (p != null) {
                client.setScreenAndShow(new BedrockPauseScreen(p));
            }
        });
    }

    private static boolean showsMenu(Screen screen) {
        try {
            return ((PauseScreenAccessor) (Object) screen).bedrockpause$showPauseMenu();
        } catch (Throwable t) {
            LOG.warn("Accessor showPauseMenu gagal: {}", t.toString());
            return true;
        }
    }
}
