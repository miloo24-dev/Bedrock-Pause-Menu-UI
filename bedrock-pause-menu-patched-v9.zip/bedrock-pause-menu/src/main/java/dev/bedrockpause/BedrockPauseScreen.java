package dev.bedrockpause;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseScreen extends Screen {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    private static final long ENTER_MS = 220L;
    private static final long EXIT_MS = 170L;
    private static final float SLIDE = 36f;

    private enum Phase { ENTER, IDLE, EXIT }

    private final PauseScreen vanilla;

    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<AbstractWidget> sliding = new ArrayList<>();
    private final List<Integer> slidingBaseX = new ArrayList<>();

    private Phase phase = Phase.ENTER;
    private long phaseStart = System.currentTimeMillis();
    private Supplier<Screen> pendingTarget;
    private boolean switchNow;
    /** Di-set oleh mixin saat layar ini ditampilkan lagi (balik dari Options dll). */
    public boolean replayEnter;

    // Arah pandang model pemain: mengikuti kursor dengan halus, tapi klik/sentuhan di atas tombol diabaikan
    private float lookX;
    private float lookY;
    private float targetX;
    private float targetY;
    private boolean lookInit;
    private long lastFrame;

    private float animAlpha;
    private float animOffset;
    private int panelW;

    private Button resume;
    private StringWidget status;
    private StringWidget nameTag;

    public BedrockPauseScreen(PauseScreen vanilla) {
        super(Component.translatable("menu.game"));
        this.vanilla = vanilla;
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }

    @Override
    protected void init() {
        all.clear();
        sliding.clear();
        slidingBaseX.clear();
        // Balik dari layar lain (Options dll): fase masih EXIT & target sudah dipakai -> putar animasi masuk.
        if (replayEnter || (phase == Phase.EXIT && pendingTarget == null)) {
            replayEnter = false;
            startPhase(Phase.ENTER);
        }

        panelW = (int) (width * 0.557f);
        int bw = Math.min(Math.max((int) (width * 0.34f), 150), 240);
        int bh = height >= 300 ? 24 : 20;
        int gap = 4;
        int bx = (panelW - bw) / 2;
        int cx = panelW + (width - panelW) / 2;

        // "Game is paused": tepat di bawah teks edition (logo berakhir sekitar y=81), jarak tipis
        Component pausedText = Component.literal("Game is paused");
        int tw = font.width(pausedText);
        int sy = 86;
        status = new StringWidget(bx + (bw - tw) / 2, sy + 2, tw, 10, pausedText, font);
        add(status, true);
        int y = sy + 14 + 4;

        // Tombol panjang: Resume Game, Settings, (Open to LAN), Save & Quit
        resume = Button.builder(Component.literal("Resume Game"), b -> onClose())
                .bounds(bx, y, bw, bh).build();
        add(resume, true);
        y += bh + gap;

        add(Button.builder(Component.literal("Settings"),
                        b -> go(() -> new OptionsScreen(this, minecraft.options, true)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap;

        // Tombol asli dari PauseScreen vanilla dipinjam, supaya aksinya persis vanilla (LAN, Save & Quit)
        List<AbstractWidget> vw = vanillaWidgets();

        var server = minecraft.getSingleplayerServer();
        boolean canLan = server != null && !server.isPublished();
        if (canLan) {
            AbstractWidget lan = findVanilla(vw, "sharetolan");
            if (lan != null) {
                place(lan, "Open to LAN", bx, y, bw, bh);
                add(lan, true);
            } else {
                add(Button.builder(Component.literal("Open to LAN"), b -> go(() -> ScreenFactory.lan(this)))
                        .bounds(bx, y, bw, bh).build(), true);
            }
            y += bh + gap;
        }

        String quitLabel = minecraft.isLocalServer() ? "Save & Quit" : "Disconnect";
        AbstractWidget quit = findVanilla(vw, "returntomenu", "disconnect");
        if (quit == null) {
            quit = lowestWide(vw);
            if (quit != null) LOG.warn("Tombol quit vanilla dicari lewat posisi: {}", quit.getMessage().getContents());
        }
        if (quit != null) {
            place(quit, quitLabel, bx, y, bw, bh);
            add(quit, true);
        } else {
            add(Button.builder(Component.literal(quitLabel), b -> saveAndQuit())
                    .bounds(bx, y, bw, bh).build(), true);
        }
        y += bh + gap + 2;

        // Baris tombol ikon kecil (kotak 20x20), urutan: Bug Report, Report Player, Friends, Mods, Accessibility
        int is = 20;
        int ix = bx + (bw - (5 * is + 4 * gap)) / 2;
        iconWidgets.clear();
        iconShapes.clear();

        addIcon(Button.builder(Component.literal(""), b -> openLink("https://aka.ms/javabugs"))
                .bounds(ix, y, is, is).build(), "Report Bugs", ICON_BUG);
        ix += is + gap;
        addIcon(Button.builder(Component.literal(""), b -> go(() -> ScreenFactory.social(this)))
                .bounds(ix, y, is, is).build(), "Report Player", ICON_FLAG);
        ix += is + gap;
        addIcon(Button.builder(Component.literal(""), b -> go(() -> ScreenFactory.social(this)))
                .bounds(ix, y, is, is).build(), "Friends", ICON_FRIENDS);
        ix += is + gap;

        boolean hasModMenu = FabricLoader.getInstance().isModLoaded("modmenu");
        Button mods = Button.builder(Component.literal(""), b -> go(() -> modsScreen(this)))
                .bounds(ix, y, is, is).build();
        mods.active = hasModMenu;
        addIcon(mods, hasModMenu ? "Mods" : "Mods (Mod Menu belum terpasang)", ICON_MODS);
        ix += is + gap;

        Button access = CommonButtons.accessibility(20, b ->
                go(() -> new AccessibilityOptionsScreen(this, minecraft.options)), true);
        access.setTooltip(Tooltip.create(Component.literal("Accessibility")));
        access.setX(ix);
        access.setY(y);
        add(access, true);

        // Panel kanan: nametag, model pemain, lalu tombol Statistics di bawah model
        Component name = Component.literal(minecraft.getUser().getName());
        int nw = font.width(name);
        nameTag = new StringWidget(cx - nw / 2, (int) (height * 0.17f), nw, 12, name, font);
        add(nameTag, false);

        int sbw = Math.max(60, Math.min(110, width - panelW - 16));
        int sby = Math.min((int) (height * 0.77f), height - 28);
        add(Button.builder(Component.literal("Statistics"), b -> go(() -> ScreenFactory.stats(this)))
                .bounds(cx - sbw / 2, sby, sbw, 20).build(), false);

        updateAnimation();
    }

    private void add(AbstractWidget w, boolean slide) {
        addRenderableWidget(w);
        all.add(w);
        if (slide) {
            sliding.add(w);
            slidingBaseX.add(w.getX());
        }
    }

    // ---------- meminjam tombol vanilla ----------

    /** Daftar widget PauseScreen vanilla; layar vanilla di-init dulu kalau belum dibangun. */
    private List<AbstractWidget> vanillaWidgets() {
        List<AbstractWidget> out = new ArrayList<>();
        try {
            if (vanilla.children().isEmpty()) {
                BedrockPauseClient.suppressFallback = true;
                try {
                    initVanilla();
                } finally {
                    BedrockPauseClient.suppressFallback = false;
                }
            }
            for (Object c : vanilla.children()) {
                if (c instanceof AbstractWidget w) {
                    out.add(w);
                    LOG.info("vanilla widget: {} '{}' {}x{}", w.getClass().getSimpleName(),
                            w.getMessage().getContents(), w.getWidth(), w.getHeight());
                }
            }
        } catch (Throwable t) {
            LOG.error("Gagal membaca tombol vanilla", t);
        }
        return out;
    }

    private void initVanilla() throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(minecraft) && t[1] == int.class && t[2] == int.class) {
                m.invoke(vanilla, minecraft, width, height);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(vanilla, width, height);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    private static AbstractWidget findVanilla(List<AbstractWidget> list, String... keys) {
        for (AbstractWidget w : list) {
            String s = String.valueOf(w.getMessage().getContents()).toLowerCase();
            for (String k : keys) {
                if (s.contains(k.toLowerCase())) return w;
            }
        }
        return null;
    }

    /** Tombol lebar (>=150) yang paling bawah; di vanilla itu tombol Save & Quit / Disconnect. */
    private static AbstractWidget lowestWide(List<AbstractWidget> list) {
        AbstractWidget best = null;
        for (AbstractWidget w : list) {
            if (w instanceof Button && w.getWidth() >= 150 && (best == null || w.getY() >= best.getY())) best = w;
        }
        return best;
    }

    private static void place(AbstractWidget w, String label, int x, int y, int width, int height) {
        w.setMessage(Component.literal(label));
        w.setX(x);
        w.setY(y);
        resize(w, width, height);
    }

    private static void resize(AbstractWidget w, int width, int height) {
        try {
            w.setWidth(width);
        } catch (Throwable t) {
            setIntField(w, "width", width);
        }
        try {
            Method m = AbstractWidget.class.getMethod("setHeight", int.class);
            m.invoke(w, height);
        } catch (Throwable t) {
            setIntField(w, "height", height);
        }
    }

    private static void setIntField(Object o, String name, int value) {
        try {
            for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
                try {
                    java.lang.reflect.Field f = c.getDeclaredField(name);
                    f.setAccessible(true);
                    f.setInt(o, value);
                    return;
                } catch (NoSuchFieldException ignored) {
                    // cari di superclass
                }
            }
        } catch (Throwable t) {
            LOG.warn("Gagal mengatur {}: {}", name, t.toString());
        }
    }

    // ---------- ikon kecil (digambar lewat kode) ----------

    // Legenda warna ikon (lihat iconColor)
    private static final String[] ICON_BUG = {
            "..b.......b..",
            "...b.....b...",
            ".....kkk.....",
            "....krrrk....",
            "b..kRRrrrk..b",
            ".bbkRrrrrkbb.",
            "b..krrkrrk..b",
            ".bbkrrkrrkbb.",
            "b..krrkrrk..b",
            "....krrrk....",
            ".....kkk.....",
    };
    private static final String[] ICON_FLAG = {
            "..wwww.......",
            ".wwwwww......",
            ".wwwwww......",
            "..wwww.......",
            "..wwww.......",
            ".wwwwww..y...",
            "wwwwwww.yyy..",
            "wwwwwww.yxy..",
            "wwwwww.yyxyy.",
            "wwwwww.yyyyy.",
            "wwwww.yyyxyyy",
            "wwwww.yyyyyyy",
    };
    private static final String[] ICON_FRIENDS = {
            ".....hhhhhhhh",
            ".....hhhhhhhh",
            ".....hssssssh",
            ".....sesssses",
            ".....ssssssss",
            "ooooooooddsss",
            "oaaaaaaosssss",
            "oagaagaosssss",
            "aaaaaaaa.....",
            "aaaddaaa.....",
            "aaaaaaaa.....",
            "aaaaaaaa.....",
    };
    private static final String[] ICON_MODS = {
            "..........cCc",
            "..........CcC",
            "..........cCc",
            "nnnnnnnnnnn..",
            "nwwnwwwwwwn..",
            "nnnnnnnnnnn..",
            "nwwnwwwwwwn..",
            "nnnnnnnnnnn..",
            "nwwnwwwwwwn..",
            "nnnnnnnnnnn..",
    };

    private static int iconColor(char ch) {
        return switch (ch) {
            case 'b' -> 0x2F4F6B;
            case 'k' -> 0x6E0A12;
            case 'r' -> 0xD01C24;
            case 'R' -> 0xFF5A5A;
            case 'h' -> 0x3A2418;
            case 's' -> 0xB58A64;
            case 'e' -> 0x6A4AA8;
            case 'd' -> 0x6A4030;
            case 'o' -> 0xE07A20;
            case 'a' -> 0xF0A870;
            case 'g' -> 0x3A9A3A;
            case 'w' -> 0xF4F4F4;
            case 'y' -> 0xF2C21A;
            case 'x' -> 0x2A2A2A;
            case 'n' -> 0x3A3A3A;
            case 'c' -> 0x2BC4AE;
            case 'C' -> 0x8FF2E4;
            default -> 0xFF00FF;
        };
    }

    private final List<AbstractWidget> iconWidgets = new ArrayList<>();
    private final List<String[]> iconShapes = new ArrayList<>();

    private void addIcon(Button b, String tip, String[] shape) {
        b.setTooltip(Tooltip.create(Component.literal(tip)));
        add(b, true);
        iconWidgets.add(b);
        iconShapes.add(shape);
    }

    private static void drawIcon(GuiGraphicsExtractor g, AbstractWidget w, String[] rows, int alpha) {
        int h = rows.length;
        int wd = rows[0].length();
        int ox = w.getX() + (w.getWidth() - wd) / 2;
        int oy = w.getY() + (w.getHeight() - h) / 2;
        for (int pass = 0; pass < 2; pass++) { // pass 0 = bayangan tipis, pass 1 = ikon berwarna
            for (int r = 0; r < h; r++) {
                String row = rows[r];
                int c = 0;
                while (c < row.length()) {
                    char ch = row.charAt(c);
                    if (ch == '.') {
                        c++;
                        continue;
                    }
                    int start = c;
                    while (c < row.length() && row.charAt(c) == ch) c++;
                    if (pass == 0) {
                        fillA(g, ox + start + 1, oy + r + 1, ox + c + 1, oy + r + 2, alpha / 3, 0x000000);
                    } else {
                        fillA(g, ox + start, oy + r, ox + c, oy + r + 1, alpha, iconColor(ch));
                    }
                }
            }
        }
    }

    /** Buka tautan lewat layar konfirmasi bawaan (ConfirmLinkScreen.confirmLinkNow). */
    private void openLink(String url) {
        try {
            Class<?> c = Class.forName("net.minecraft.client.gui.screens.ConfirmLinkScreen");
            for (Method m : c.getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getName().equals("confirmLinkNow")
                        && t.length == 2 && t[0] == Screen.class && t[1] == String.class) {
                    m.invoke(null, this, url);
                    return;
                }
            }
            throw new NoSuchMethodException("ConfirmLinkScreen.confirmLinkNow(Screen, String)");
        } catch (Throwable t) {
            LOG.error("Gagal membuka tautan", t);
        }
    }

    // ---------- transisi ----------

    private void startPhase(Phase p) {
        phase = p;
        phaseStart = System.currentTimeMillis();
    }

    /** Pause menu geser ke kiri + fade out, baru layar tujuan muncul (fade in + geser ke kanan). */
    private void go(Supplier<Screen> target) {
        if (phase == Phase.EXIT) return;
        pendingTarget = target;
        switchNow = false;
        startPhase(Phase.EXIT);
    }

    private void updateAnimation() {
        long el = System.currentTimeMillis() - phaseStart;
        switch (phase) {
            case ENTER -> {
                float p = Math.min(1f, el / (float) ENTER_MS);
                float q = 1f - p;
                float e = 1f - q * q * q;
                animAlpha = e;
                animOffset = -(1f - e) * SLIDE;
                if (p >= 1f) phase = Phase.IDLE;
            }
            case IDLE -> {
                animAlpha = 1f;
                animOffset = 0f;
            }
            case EXIT -> {
                float p = Math.min(1f, el / (float) EXIT_MS);
                animAlpha = 1f - p;
                animOffset = -p * SLIDE;
                if (p >= 1f && pendingTarget != null) switchNow = true;
            }
        }
        int off = Math.round(animOffset);
        for (int i = 0; i < sliding.size(); i++) {
            sliding.get(i).setX(slidingBaseX.get(i) + off);
        }
        for (AbstractWidget w : all) w.setAlpha(animAlpha);
    }

    @Override
    public void tick() {
        super.tick();
        if (switchNow) {
            switchNow = false;
            Supplier<Screen> t = pendingTarget;
            pendingTarget = null;
            Screen next = t == null ? null : t.get();
            if (next == null) {
                startPhase(Phase.ENTER); // gagal membuka -> munculkan lagi
            } else {
                Transition.show(minecraft, next);
            }
        }
    }

    // ---------- render ----------

    /** fill yang dilewati kalau alpha 0 (alpha 0 bisa dianggap opaque oleh sebagian versi). */
    private static void fillA(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int alpha, int rgb) {
        if (alpha <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(alpha, 255) << 24) | (rgb & 0xFFFFFF));
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // Tanpa blur/dim di sisi kanan, hanya panel kiri yang digelapkan (seperti Bedrock).
        int off = Math.round(animOffset);
        int px2 = panelW + off;
        fillA(g, off, 0, px2, height, (int) (0xB4 * animAlpha), 0x000000);

        if (status != null) {
            int x1 = status.getX() - 6;
            int x2 = status.getX() + status.getWidth() + 6;
            int y1 = status.getY() - 2;
            int y2 = status.getY() + status.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0xC8 * animAlpha), 0x000000);
        }
        if (nameTag != null) {
            int x1 = nameTag.getX() - 4;
            int x2 = nameTag.getX() + nameTag.getWidth() + 4;
            int y1 = nameTag.getY() - 2;
            int y2 = nameTag.getY() + nameTag.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0x70 * animAlpha), 0x000000);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        updateAnimation();
        super.extractRenderState(g, mx, my, a);

        // Ikon pada tombol kotak kecil
        int ia = (int) (0xFF * animAlpha);
        for (int i = 0; i < iconWidgets.size(); i++) {
            AbstractWidget w = iconWidgets.get(i);
            drawIcon(g, w, iconShapes.get(i), w.active ? ia : ia * 4 / 10);
        }

        ExtraRender.logo(g, panelW + 2 * Math.round(animOffset), animAlpha);

        int cx = panelW + (width - panelW) / 2;
        long now = System.currentTimeMillis();
        if (!lookInit) {
            lookInit = true;
            lookX = targetX = cx - 30;
            lookY = targetY = height * 0.34f;
            lastFrame = now;
        }
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;

        // Kalau kursor/jari sedang di atas tombol, target pandangan tidak diubah (tidak "melompat" saat klik)
        boolean overButton = false;
        for (AbstractWidget w : all) {
            if (!(w instanceof Button)) continue;
            if (mx >= w.getX() && mx < w.getX() + w.getWidth() && my >= w.getY() && my < w.getY() + w.getHeight()) {
                overButton = true;
                break;
            }
        }
        if (!overButton) {
            targetX = mx;
            targetY = my;
        }
        float k = 1f - (float) Math.exp(-dt * 8f); // gerak halus menuju target
        lookX += (targetX - lookX) * k;
        lookY += (targetY - lookY) * k;

        if (animAlpha > 0.05f) {
            int half = (int) (height * 0.14f);
            ExtraRender.player(g, cx - half, (int) (height * 0.24f), cx + half, (int) (height * 0.74f),
                    (int) (height * 0.22f), Math.round(lookX), Math.round(lookY));
        }
    }

    // ---------- aksi ----------

    private static Screen modsScreen(Screen parent) {
        try {
            Class<?> c = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            return (Screen) c.getConstructor(Screen.class).newInstance(parent);
        } catch (Throwable t) {
            LOG.error("Gagal membuka Mod Menu", t);
            return null;
        }
    }

    /** Memakai logika disconnect bawaan PauseScreen (private onDisconnect) lewat reflection. */
    private void saveAndQuit() {
        if (phase == Phase.EXIT) return;
        try {
            Field f = Screen.class.getDeclaredField("minecraft");
            f.setAccessible(true);
            f.set(vanilla, minecraft);
            Method m = null;
            try {
                m = PauseScreen.class.getDeclaredMethod("onDisconnect");
            } catch (NoSuchMethodException e) {
                for (Method c : PauseScreen.class.getDeclaredMethods()) {
                    if (c.getParameterCount() == 0 && c.getName().toLowerCase().contains("disconnect")) {
                        m = c;
                        break;
                    }
                }
            }
            if (m == null) throw new NoSuchMethodException("PauseScreen.*disconnect");
            m.setAccessible(true);
            m.invoke(vanilla);
        } catch (Throwable t) {
            LOG.error("Gagal Save & Quit", t);
        }
    }
}
