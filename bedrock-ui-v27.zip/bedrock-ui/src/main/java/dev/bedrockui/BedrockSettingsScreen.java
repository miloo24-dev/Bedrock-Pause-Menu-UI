package dev.bedrockui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

/**
 * Bedrock-style settings screen: light header with a back arrow, a category sidebar on the left and the options of
 * the selected category on the right. Only options that exist in Java Edition are listed; they are the vanilla
 * widgets borrowed from a hidden OptionsScreen. A "Bedrock UI" category holds this mod's own settings.
 */
public class BedrockSettingsScreen extends Screen {
    private static final Logger LOG = BedrockUiClient.LOG;

    /** Hidden vanilla OptionsScreen -> the screen the settings were opened from. */
    static final Map<Screen, Screen> REAL_PARENT = new WeakHashMap<>();

    private static final String[] CATS = {"Accessibility", "Keyboard & Mouse", "General", "Video", "Audio", "Resource Packs", "Bedrock UI"};
    private static final String[] SUBTITLE = {
            "Minecraft is for everyone, including you", "Key binds and mouse settings", "Language, skin and game options",
            "Graphics, render distance and performance", "Music, sound effects and voices",
            "Textures, sounds and other packs", "Settings for this mod"};
    private static final int[] ICON_RGB = {0x2D6CF0, 0x8A8A8A, 0xB5651D, 0x3A9A3A, 0xB5442C, 0x7A5BC4, 0x3C8527};
    private static final String[][] KEYS = {
            {"accessib", "chat"},
            {"control", "mouse", "keybind"},
            {"language", "skin", "difficulty", "online", "telemetry"},
            {"video", "fov"},
            {"sound", "music", "volume"},
            {"resourcepack", "resource"},
            {}
    };
    private static final int CUSTOM = 6;
    private static final long ENTER_MS = 320L;
    private static final long PANE_MS = 260L;

    private record Row(String label, String desc, AbstractWidget widget) {}

    private final Screen parent;
    private final List<Row> borrowed = new ArrayList<>();
    private final List<Row> custom = new ArrayList<>();
    private final List<Row> pageRows = new ArrayList<>();
    private final List<AbstractWidget> pane = new ArrayList<>();
    private final List<Button> side = new ArrayList<>();
    private Button prev;
    private Button next;
    private int selected = 2;
    private int page;
    private int perPage = 6;
    private int pages = 1;
    private int headerH = 24;
    private int sideW;
    private int rowH = 32;
    private int paneTop;
    private int ww = 130;
    private long enterStart = System.currentTimeMillis();
    private long paneStart = System.currentTimeMillis();

    public BedrockSettingsScreen(Screen parent) {
        super(Component.literal("Settings"));
        this.parent = parent;
    }

    /** The screen a vanilla OptionsScreen was opened from. */
    static Screen parentOf(Screen options) {
        Screen p = REAL_PARENT.get(options);
        if (p != null) return p;
        try {
            for (Class<?> c = options.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (Screen.class.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true);
                        Object v = f.get(options);
                        if (v instanceof Screen s && s != options) return s;
                    }
                }
            }
        } catch (Throwable t) {
            LOG.warn("Could not find the parent of the options screen: {}", t.toString());
        }
        return null;
    }

    @Override
    public void onClose() {
        minecraft.setScreenAndShow(parent == null && minecraft.level == null ? new TitleScreen() : parent);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // intentionally empty: everything is drawn in extractRenderState
    }

    private static void callInit(Screen target, net.minecraft.client.Minecraft mc, int w, int h) throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(mc) && t[1] == int.class && t[2] == int.class) {
                m.invoke(target, mc, w, h);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(target, w, h);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    private static String text(AbstractWidget w) {
        return (String.valueOf(w.getMessage().getContents()) + " " + w.getMessage().getString()).toLowerCase();
    }

    private static String describe(String t) {
        if (t.contains("video")) return "Graphics, render distance and performance";
        if (t.contains("sound") || t.contains("music")) return "Music, sound effects and voices";
        if (t.contains("control")) return "Key binds and mouse settings";
        if (t.contains("language")) return "Change the language of the game";
        if (t.contains("skin")) return "Choose which parts of your skin are shown";
        if (t.contains("resourcepack") || t.contains("resource")) return "Textures, sounds and other packs";
        if (t.contains("accessib")) return "Make Minecraft easier to use";
        if (t.contains("chat")) return "Chat visibility, colors and size";
        if (t.contains("fov")) return "How wide your field of view is";
        if (t.contains("difficulty")) return "How hard the game is";
        if (t.contains("online")) return "Online options";
        if (t.contains("telemetry")) return "Data sharing options";
        return "";
    }

    private int categoryOf(String t) {
        for (int i = 0; i < KEYS.length; i++) {
            for (String k : KEYS[i]) if (t.contains(k)) return i;
        }
        return 2; // unknown options go to General
    }

    private void borrowVanillaOptions() {
        borrowed.clear();
        BedrockUiClient.suppressFallback = true;
        try {
            OptionsScreen tmp = new OptionsScreen(this, minecraft.options, false);
            REAL_PARENT.put(tmp, parent);
            callInit(tmp, minecraft, width, height);
            for (Object o : tmp.children()) {
                if (o instanceof AbstractWidget w && !(w instanceof StringWidget) && w.getWidth() >= 50) {
                    String t = text(w);
                    if (t.contains("done")) continue;
                    borrowed.add(new Row(w.getMessage().getString(), describe(t), w));
                }
            }
        } catch (Throwable t) {
            LOG.error("Could not borrow the vanilla option widgets", t);
        } finally {
            BedrockUiClient.suppressFallback = false;
        }
    }

    // ---------- this mod's own settings ----------

    private void toggle(String label, String desc, BooleanSupplier get, Consumer<Boolean> set) {
        Button b = Button.builder(Component.literal(get.getAsBoolean() ? "ON" : "OFF"), btn -> {
            set.accept(!get.getAsBoolean());
            BpConfig.save();
            btn.setMessage(Component.literal(get.getAsBoolean() ? "ON" : "OFF"));
        }).bounds(0, 0, 70, 20).build();
        custom.add(new Row(label, desc, b));
    }

    private void cycle(String label, String desc, int[] values, String unit, IntSupplier get, IntConsumer set) {
        Button b = Button.builder(Component.literal(get.getAsInt() + unit), btn -> {
            int cur = get.getAsInt();
            int idx = 0;
            for (int i = 0; i < values.length; i++) if (values[i] <= cur) idx = i;
            set.accept(values[(idx + 1) % values.length]);
            BpConfig.save();
            btn.setMessage(Component.literal(get.getAsInt() + unit));
        }).bounds(0, 0, 70, 20).build();
        custom.add(new Row(label, desc, b));
    }

    private void buildCustom() {
        custom.clear();
        toggle("Pause menu style", "Bedrock-style pause menu", () -> BpConfig.bedrockPauseMenu, v -> BpConfig.bedrockPauseMenu = v);
        toggle("Title screen style", "Bedrock-style main menu", () -> BpConfig.bedrockTitleScreen, v -> BpConfig.bedrockTitleScreen = v);
        toggle("Settings style", "This settings screen", () -> BpConfig.bedrockSettings, v -> BpConfig.bedrockSettings = v);
        toggle("Bedrock buttons", "Light buttons that turn green on hover", () -> BpConfig.bedrockButtons, v -> BpConfig.bedrockButtons = v);
        toggle("Animations", "Slide and fade animations", () -> BpConfig.animations, v -> BpConfig.animations = v);
        toggle("Player skin", "Skin model in the menus", () -> BpConfig.skinDisplay, v -> BpConfig.skinDisplay = v);
        toggle("Coordinates", "Show your position on screen", () -> BpConfig.showCoordinates, v -> BpConfig.showCoordinates = v);
        toggle("FPS", "Show the frame rate on screen", () -> BpConfig.showFps, v -> BpConfig.showFps = v);
        toggle("Days played", "Show the days played in this world", () -> BpConfig.showDaysPlayed, v -> BpConfig.showDaysPlayed = v);
        toggle("Fade HUD when idle", "Hotbar and bars become translucent", () -> BpConfig.hudFade, v -> BpConfig.hudFade = v);
        cycle("HUD fade delay", "Seconds without activity", new int[] {3, 5, 10, 15, 30}, " s",
                () -> BpConfig.hudFadeSeconds, v -> BpConfig.hudFadeSeconds = v);
        cycle("HUD faded opacity", "How visible the faded HUD is", new int[] {25, 50, 75, 100}, "%",
                () -> BpConfig.hudOpacity, v -> BpConfig.hudOpacity = v);
        cycle("HUD height", "Raise the hotbar and bars", new int[] {0, 4, 8, 12, 16, 24, 32}, " px",
                () -> BpConfig.hudOffsetY, v -> BpConfig.hudOffsetY = v);
    }

    // ---------- layout ----------

    @Override
    protected void init() {
        pane.clear();
        side.clear();
        sideW = Math.max(110, (int) (width * 0.30f));
        borrowVanillaOptions();
        buildCustom();

        addRenderableWidget(Button.builder(Component.literal("<"), b -> onClose()).bounds(4, 2, 24, 20).build());

        int y = headerH + 8;
        for (int i = 0; i < CATS.length; i++) {
            if (i == 1 || i == 2) y += 14; // room for the group heading ("Controls", "General")
            final int idx = i;
            Button b = Button.builder(Component.literal(""), btn -> {
                selected = idx;
                page = 0;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(0, y, sideW, 24).build();
            side.add(b);
            addRenderableWidget(b);
            y += 26;
        }
        buildPane();
    }

    private void buildPane() {
        for (AbstractWidget w : pane) removeWidget(w);
        pane.clear();
        if (prev != null) removeWidget(prev);
        if (next != null) removeWidget(next);
        prev = null;
        next = null;

        List<Row> all = new ArrayList<>();
        if (selected == CUSTOM) {
            all.addAll(custom);
        } else {
            for (Row r : borrowed) if (categoryOf(text(r.widget())) == selected) all.add(r);
        }
        paneTop = headerH + 8 + 30; // after the category title block
        rowH = 30;
        int avail = height - paneTop - 24;
        perPage = Math.max(1, avail / rowH);
        pages = Math.max(1, (all.size() + perPage - 1) / perPage);
        page = Math.min(page, pages - 1);

        pageRows.clear();
        ww = selected == CUSTOM ? 70 : Math.min(140, Math.max(90, (int) ((width - sideW) * 0.38f)));
        for (int i = page * perPage; i < Math.min(all.size(), (page + 1) * perPage); i++) {
            Row r = all.get(i);
            r.widget().setWidth(ww);
            addRenderableWidget(r.widget());
            pane.add(r.widget());
            pageRows.add(r);
        }
        if (pages > 1) {
            prev = Button.builder(Component.literal("<"), b -> {
                page = (page + pages - 1) % pages;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(sideW + 12, height - 22, 24, 18).build();
            next = Button.builder(Component.literal(">"), b -> {
                page = (page + 1) % pages;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(sideW + 40, height - 22, 24, 18).build();
            addRenderableWidget(prev);
            addRenderableWidget(next);
        }
    }

    private static float ease(long start, long ms) {
        if (!BpConfig.animations) return 1f;
        float p = Math.min(1f, (System.currentTimeMillis() - start) / (float) ms);
        float q = 1f - p;
        return 1f - q * q * q * q;
    }

    private static int argb(float alpha, int rgb) {
        return ((int) (255 * Math.max(0f, Math.min(1f, alpha))) << 24) | (rgb & 0xFFFFFF);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        float en = ease(enterStart, ENTER_MS);
        float pe = ease(paneStart, PANE_MS);
        int sideOff = -(int) ((1f - en) * sideW);
        int slide = (int) ((1f - pe) * 18f);

        // backgrounds
        g.fill(0, 0, width, height, 0xFF454547);
        g.fill(sideOff, headerH, sideOff + sideW, height, 0xFF2D2D2F);
        g.fill(sideOff + sideW, headerH, sideOff + sideW + 2, height, 0xFF1E1E1F);

        // header
        g.fill(0, 0, width, headerH, 0xFFE9EAEC);
        g.fill(0, headerH, width, headerH + 2, 0xFF8D8E91);
        Component title = Component.literal("SETTINGS").withStyle(ChatFormatting.BOLD);
        g.text(font, title, (width - font.width(title)) / 2, (headerH - 8) / 2, 0xFF1E1E1F, false);

        // category title block
        int px = sideW + 12 + slide;
        Component ct = Component.literal(CATS[selected].toUpperCase()).withStyle(ChatFormatting.BOLD);
        g.text(font, ct, px, headerH + 10, argb(pe, 0xFFFFFF), false);
        g.text(font, Component.literal(SUBTITLE[selected]), px, headerH + 21, argb(pe, 0xB5B5B8), false);
        g.fill(sideW + 4, headerH + 34, width - 4, headerH + 35, 0xFF5E5E61);

        // option rows: hover highlight, label, description, separator; the widgets sit on the right
        int y = paneTop;
        int wx = width - ww - 12 + slide;
        for (Row r : pageRows) {
            boolean hover = mx >= sideW + 2 && my >= y && my < y + rowH;
            if (hover) g.fill(sideW + 4, y, width - 4, y + rowH - 1, argb(pe * 0.5f, 0x5A5A5E));
            g.text(font, Component.literal(r.label()), px, y + (r.desc().isEmpty() ? 11 : 5), argb(pe, 0xFFFFFF), false);
            if (!r.desc().isEmpty()) g.text(font, Component.literal(r.desc()), px, y + 16, argb(pe, 0xB5B5B8), false);
            g.fill(sideW + 4, y + rowH - 1, width - 4, y + rowH, argb(pe, 0x5E5E61));
            AbstractWidget w = r.widget();
            w.setX(wx);
            w.setY(y + (rowH - 20) / 2);
            w.setAlpha(pe);
            y += rowH;
        }
        if (pageRows.isEmpty()) {
            g.text(font, Component.literal("Nothing to show here."), px, paneTop + 8, argb(pe, 0xB5B5B8), false);
        }
        if (pages > 1) {
            g.text(font, Component.literal((page + 1) + " / " + pages), sideW + 72, height - 17, 0xFFB5B5B8, false);
        }

        // sidebar buttons follow the slide-in
        for (Button b : side) b.setX(sideOff);

        super.extractRenderState(g, mx, my, a); // buttons (back arrow, sidebar rows, option widgets)

        // sidebar rows drawn over their (invisible) buttons
        for (int i = 0; i < side.size(); i++) {
            Button b = side.get(i);
            int by = b.getY();
            boolean hover = mx >= 0 && mx < sideW && my >= by && my < by + 24;
            g.fill(sideOff, by, sideOff + sideW, by + 24, i == selected ? 0xFF454547 : hover ? 0xFF38383A : 0xFF2D2D2F);
            g.fill(sideOff, by + 23, sideOff + sideW, by + 24, 0xFF1E1E1F);
            if (i == selected) g.fill(sideOff, by, sideOff + 3, by + 23, 0xFF3C8527);
            int ix = 8 + sideOff;
            int iy = by + 4;
            g.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0xFF1E1E1F);
            g.fill(ix, iy, ix + 16, iy + 16, 0xFF000000 | ICON_RGB[i]);
            String ini = CATS[i].substring(0, 1);
            g.text(font, Component.literal(ini), ix + (16 - font.width(ini)) / 2, iy + 4, 0xFFFFFFFF, false);
            g.text(font, Component.literal(CATS[i]), ix + 24, by + 8, 0xFFFFFFFF, false);
            if (i == 1) g.text(font, Component.literal("Controls"), 8 + sideOff, by - 12, 0xFFA0A0A4, false);
            if (i == 2) g.text(font, Component.literal("General"), 8 + sideOff, by - 12, 0xFFA0A0A4, false);
        }
    }
}
