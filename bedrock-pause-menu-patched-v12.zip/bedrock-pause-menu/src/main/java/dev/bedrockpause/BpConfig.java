package dev.bedrockpause;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Config sederhana: config/bedrockpause.properties */
final class BpConfig {
    /** Tampilkan tombol ikon Report Bugs, Feedback, Report Player, dan Friends di bawah tombol panjang. */
    static volatile boolean showExtraButtons = false;

    private BpConfig() {}

    static void load() {
        try {
            Path p = FabricLoader.getInstance().getConfigDir().resolve("bedrockpause.properties");
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (var in = Files.newInputStream(p)) {
                    props.load(in);
                }
                showExtraButtons = Boolean.parseBoolean(props.getProperty("showExtraButtons", "false").trim());
            } else {
                Files.createDirectories(p.getParent());
                Files.writeString(p,
                        "# Bedrock Pause Menu\n"
                                + "# true  = tampilkan tombol ikon Report Bugs, Feedback, Report Player, dan Friends\n"
                                + "# false = sembunyikan (default)\n"
                                + "showExtraButtons=false\n");
            }
        } catch (Throwable t) {
            BedrockPauseClient.LOG.warn("Gagal membaca config: {}", t.toString());
        }
    }
}
