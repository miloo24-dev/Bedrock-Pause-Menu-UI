package dev.bedrockpause;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseScreen extends Screen {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    private static final long ENTER_MS = 220L;
    private static final long EXIT_MS = 170L;
    private static final float SLIDE = 36f;

    private enum Phase { ENTER, IDLE, EXIT }

    private final PauseScreen vanilla;

    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<AbstractWidget> sliding = new ArrayList<>();
    private final List<Integer> slidingBaseX = new ArrayList<>();

    private Phase phase = Phase.ENTER;
    private long phaseStart = System.currentTimeMillis();
    private Supplier<Screen> pendingTarget;
    private boolean switchNow;
    /** Di-set oleh mixin saat layar ini ditampilkan lagi (balik dari Options dll). */
    public boolean replayEnter;

    private float animAlpha;
    private float animOffset;
    private int panelW;

    private Button resume;
    private StringWidget status;
    private StringWidget nameTag;

    public BedrockPauseScreen(PauseScreen vanilla) {
        super(Component.translatable("menu.game"));
        this.vanilla = vanilla;
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }

    @Override
    protected void init() {
        all.clear();
        sliding.clear();
        slidingBaseX.clear();
        // Balik dari layar lain (Options dll): fase masih EXIT & target sudah dipakai -> putar animasi masuk.
        if (replayEnter || (phase == Phase.EXIT && pendingTarget == null)) {
            replayEnter = false;
            startPhase(Phase.ENTER);
        }

        panelW = (int) (width * 0.557f);
        int bw = Math.min(Math.max((int) (width * 0.34f), 150), 240);
        int bh = height >= 300 ? 24 : 20;
        int gap = 4;
        int bx = (panelW - bw) / 2;
        int cx = panelW + (width - panelW) / 2;

        // "Game is paused": tepat di bawah teks edition (logo berakhir sekitar y=81), jarak tipis
        Component pausedText = Component.literal("Game is paused");
        int tw = font.width(pausedText);
        int sy = 86;
        status = new StringWidget(bx + (bw - tw) / 2, sy + 2, tw, 10, pausedText, font);
        add(status, true);
        int y = sy + 14 + 4;

        // Tombol panjang: Resume Game, Settings, (Open to LAN), Save & Quit
        resume = Button.builder(Component.literal("Resume Game"), b -> onClose())
                .bounds(bx, y, bw, bh).build();
        add(resume, true);
        y += bh + gap;

        add(Button.builder(Component.literal("Settings"),
                        b -> go(() -> new OptionsScreen(this, minecraft.options, true)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap;

        var server = minecraft.getSingleplayerServer();
        boolean canLan = server != null && !server.isPublished();
        if (canLan) {
            add(Button.builder(Component.literal("Open to LAN"), b -> go(() -> ScreenFactory.lan(this)))
                    .bounds(bx, y, bw, bh).build(), true);
            y += bh + gap;
        }

        String quitLabel = minecraft.isLocalServer() ? "Save & Quit" : "Disconnect";
        add(Button.builder(Component.literal(quitLabel), b -> saveAndQuit())
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap + 2;

        // Baris kecil: Accessibility (ikon) | Mods | Advancements
        int sh = 20;
        Button access = CommonButtons.accessibility(20, b ->
                go(() -> new AccessibilityOptionsScreen(this, minecraft.options)), true);
        access.setTooltip(Tooltip.create(Component.literal("Accessibility")));
        access.setX(bx);
        access.setY(y);
        add(access, true);

        int rest = bw - 20 - 2 * gap;
        int half = rest / 2;
        Button mods = Button.builder(Component.literal("Mods"), b -> go(() -> modsScreen(this)))
                .bounds(bx + 20 + gap, y, half, sh).build();
        if (!FabricLoader.getInstance().isModLoaded("modmenu")) {
            mods.active = false;
            mods.setTooltip(Tooltip.create(Component.literal("Mod Menu belum terpasang")));
        }
        add(mods, true);

        int ax = bx + 20 + gap + half + gap;
        add(Button.builder(Component.literal("Advancements"), b -> go(() -> ScreenFactory.advancements(this)))
                .bounds(ax, y, bx + bw - ax, sh).build(), true);

        // Panel kanan: nametag, model pemain, lalu tombol Statistics di bawah model
        Component name = Component.literal(minecraft.getUser().getName());
        int nw = font.width(name);
        nameTag = new StringWidget(cx - nw / 2, (int) (height * 0.17f), nw, 12, name, font);
        add(nameTag, false);

        int sbw = Math.max(60, Math.min(110, width - panelW - 16));
        int sby = Math.min((int) (height * 0.77f), height - 28);
        add(Button.builder(Component.literal("Statistics"), b -> go(() -> ScreenFactory.stats(this)))
                .bounds(cx - sbw / 2, sby, sbw, 20).build(), false);

        updateAnimation();
    }

    private void add(AbstractWidget w, boolean slide) {
        addRenderableWidget(w);
        all.add(w);
        if (slide) {
            sliding.add(w);
            slidingBaseX.add(w.getX());
        }
    }

    // ---------- transisi ----------

    private void startPhase(Phase p) {
        phase = p;
        phaseStart = System.currentTimeMillis();
    }

    /** Pause menu geser ke kiri + fade out, baru layar tujuan muncul (fade in + geser ke kanan). */
    private void go(Supplier<Screen> target) {
        if (phase == Phase.EXIT) return;
        pendingTarget = target;
        switchNow = false;
        startPhase(Phase.EXIT);
    }

    private void updateAnimation() {
        long el = System.currentTimeMillis() - phaseStart;
        switch (phase) {
            case ENTER -> {
                float p = Math.min(1f, el / (float) ENTER_MS);
                float q = 1f - p;
                float e = 1f - q * q * q;
                animAlpha = e;
                animOffset = -(1f - e) * SLIDE;
                if (p >= 1f) phase = Phase.IDLE;
            }
            case IDLE -> {
                animAlpha = 1f;
                animOffset = 0f;
            }
            case EXIT -> {
                float p = Math.min(1f, el / (float) EXIT_MS);
                animAlpha = 1f - p;
                animOffset = -p * SLIDE;
                if (p >= 1f && pendingTarget != null) switchNow = true;
            }
        }
        int off = Math.round(animOffset);
        for (int i = 0; i < sliding.size(); i++) {
            sliding.get(i).setX(slidingBaseX.get(i) + off);
        }
        for (AbstractWidget w : all) w.setAlpha(animAlpha);
    }

    @Override
    public void tick() {
        super.tick();
        if (switchNow) {
            switchNow = false;
            Supplier<Screen> t = pendingTarget;
            pendingTarget = null;
            Screen next = t == null ? null : t.get();
            if (next == null) {
                startPhase(Phase.ENTER); // gagal membuka -> munculkan lagi
            } else {
                Transition.show(minecraft, next);
            }
        }
    }

    // ---------- render ----------

    /** fill yang dilewati kalau alpha 0 (alpha 0 bisa dianggap opaque oleh sebagian versi). */
    private static void fillA(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int alpha, int rgb) {
        if (alpha <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(alpha, 255) << 24) | (rgb & 0xFFFFFF));
    }

    /** Bingkai timbul: tepi atas/kiri terang, bawah/kanan gelap. */
    private static void bevel(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, float a) {
        int la = (int) (0x48 * a);
        int da = (int) (0x58 * a);
        fillA(g, x1, y1, x2, y1 + 1, la, 0xFFFFFF);
        fillA(g, x1, y1, x1 + 1, y2, la, 0xFFFFFF);
        fillA(g, x1, y2 - 1, x2, y2, da, 0x000000);
        fillA(g, x2 - 1, y1, x2, y2, da, 0x000000);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // Tanpa blur/dim di sisi kanan, hanya panel kiri yang digelapkan (seperti Bedrock).
        int off = Math.round(animOffset);
        int px2 = panelW + off;
        fillA(g, off, 0, px2, height, (int) (0x99 * animAlpha), 0x101828);

        // Tekstur halus panel: garis horizontal tipis + tepi kanan bercahaya
        int lineA = (int) (0x0E * animAlpha);
        for (int yy = 0; yy < height; yy += 4) {
            fillA(g, off, yy, px2 - 2, yy + 1, lineA, 0xFFFFFF);
        }
        fillA(g, px2 - 2, 0, px2, height, (int) (0x70 * animAlpha), 0x6C8CC8);
        fillA(g, px2, 0, px2 + 1, height, (int) (0x70 * animAlpha), 0x000000);

        if (status != null) {
            int x1 = status.getX() - 6;
            int x2 = status.getX() + status.getWidth() + 6;
            int y1 = status.getY() - 2;
            int y2 = status.getY() + status.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0xC8 * animAlpha), 0x000000);
            bevel(g, x1, y1, x2, y2, animAlpha);
        }
        if (nameTag != null) {
            int x1 = nameTag.getX() - 4;
            int x2 = nameTag.getX() + nameTag.getWidth() + 4;
            int y1 = nameTag.getY() - 2;
            int y2 = nameTag.getY() + nameTag.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0x70 * animAlpha), 0x000000);
            bevel(g, x1, y1, x2, y2, animAlpha);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        updateAnimation();
        super.extractRenderState(g, mx, my, a);

        // Bingkai timbul di semua tombol
        for (AbstractWidget w : all) {
            if (w instanceof Button) {
                bevel(g, w.getX(), w.getY(), w.getX() + w.getWidth(), w.getY() + w.getHeight(), animAlpha);
            }
        }

        // Hover: tombol berwarna hijau + outline putih (gaya Bedrock)
        for (AbstractWidget w : all) {
            if (!(w instanceof Button) || !w.active) continue;
            int x1 = w.getX();
            int y1 = w.getY();
            int x2 = x1 + w.getWidth();
            int y2 = y1 + w.getHeight();
            if (mx >= x1 && mx < x2 && my >= y1 && my < y2) {
                // Hijau hanya saat hover
                int ha = (int) (0x78 * animAlpha);
                fillA(g, x1, y1, x2, y2, ha, 0x2EC02E);
                int oa = (int) (0xFF * animAlpha);
                fillA(g, x1 - 1, y1 - 1, x2 + 1, y1 + 1, oa, 0xFFFFFF);
                fillA(g, x1 - 1, y2 - 1, x2 + 1, y2 + 1, oa, 0xFFFFFF);
                fillA(g, x1 - 1, y1, x1 + 1, y2, oa, 0xFFFFFF);
                fillA(g, x2 - 1, y1, x2 + 1, y2, oa, 0xFFFFFF);
            }
        }

        ExtraRender.logo(g, panelW + 2 * Math.round(animOffset), animAlpha);

        if (animAlpha > 0.05f) {
            int cx = panelW + (width - panelW) / 2;
            int half = (int) (height * 0.14f);
            ExtraRender.player(g, cx - half, (int) (height * 0.24f), cx + half, (int) (height * 0.74f),
                    (int) (height * 0.22f), mx, my);
        }
    }

    // ---------- aksi ----------

    private static Screen modsScreen(Screen parent) {
        try {
            Class<?> c = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            return (Screen) c.getConstructor(Screen.class).newInstance(parent);
        } catch (Throwable t) {
            LOG.error("Gagal membuka Mod Menu", t);
            return null;
        }
    }

    /** Memakai logika disconnect bawaan PauseScreen (private onDisconnect) lewat reflection. */
    private void saveAndQuit() {
        if (phase == Phase.EXIT) return;
        try {
            Field f = Screen.class.getDeclaredField("minecraft");
            f.setAccessible(true);
            f.set(vanilla, minecraft);
            Method m = null;
            try {
                m = PauseScreen.class.getDeclaredMethod("onDisconnect");
            } catch (NoSuchMethodException e) {
                for (Method c : PauseScreen.class.getDeclaredMethods()) {
                    if (c.getParameterCount() == 0 && c.getName().toLowerCase().contains("disconnect")) {
                        m = c;
                        break;
                    }
                }
            }
            if (m == null) throw new NoSuchMethodException("PauseScreen.*disconnect");
            m.setAccessible(true);
            m.invoke(vanilla);
        } catch (Throwable t) {
            LOG.error("Gagal Save & Quit", t);
        }
    }
}
