package dev.bedrockpause.mixin;

import dev.bedrockpause.BedrockPauseClient;
import dev.bedrockpause.BedrockPauseScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {

    // 26.2: setScreenAndShow, 26.1 dan sebelumnya: setScreen
    @ModifyVariable(method = {"setScreenAndShow", "setScreen"}, at = @At("HEAD"), argsOnly = true)
    private Screen bedrockpause$swapPauseScreen(Screen screen) {
        if (screen != null && screen.getClass().getName().contains("Pause")) {
            BedrockPauseClient.LOG.info("setScreen menerima {}", screen.getClass().getName());
        }
        if (screen instanceof BedrockPauseScreen bedrock) {
            bedrock.replayEnter = true; // balik dari Options dll -> putar animasi masuk lagi
            return screen;
        }
        if (screen != null
                && screen.getClass() == PauseScreen.class
                && ((PauseScreenAccessor) (Object) screen).bedrockpause$showPauseMenu()) {
            return new BedrockPauseScreen((PauseScreen) screen);
        }
        return screen;
    }
}
