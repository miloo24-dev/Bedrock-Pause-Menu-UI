package dev.bedrockpause;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseScreen extends Screen {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    private static final long ENTER_MS = 220L;
    private static final long EXIT_MS = 170L;
    private static final float SLIDE = 36f;

    private enum Phase { ENTER, IDLE, EXIT }

    private final PauseScreen vanilla;

    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<AbstractWidget> sliding = new ArrayList<>();
    private final List<Integer> slidingBaseX = new ArrayList<>();

    private Phase phase = Phase.ENTER;
    private long phaseStart = System.currentTimeMillis();
    private Supplier<Screen> pendingTarget;
    private boolean switchNow;
    /** Di-set oleh mixin saat layar ini ditampilkan lagi (balik dari Options dll). */
    public boolean replayEnter;

    private float animAlpha;
    private float animOffset;
    private int panelW;

    private Button resume;
    private StringWidget status;
    private StringWidget nameTag;

    public BedrockPauseScreen(PauseScreen vanilla) {
        super(Component.translatable("menu.game"));
        this.vanilla = vanilla;
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }

    @Override
    protected void init() {
        all.clear();
        sliding.clear();
        slidingBaseX.clear();
        if (replayEnter) {
            replayEnter = false;
            startPhase(Phase.ENTER);
        }

        panelW = (int) (width * 0.557f);
        int bw = Math.min(Math.max((int) (width * 0.34f), 150), 240);
        int bh = 24;
        int gap = 4;
        int bx = (panelW - bw) / 2;
        int y = 82;

        // Resume Game (dibuat hijau di extractRenderState)
        resume = Button.builder(Component.literal("Resume Game"), b -> onClose())
                .bounds(bx, y, bw, bh).build();
        add(resume, true);
        y += bh + gap;

        // Browse Add-ons -> Mod Menu
        Button mods = Button.builder(Component.literal("Mods"), b -> go(() -> modsScreen(this)))
                .bounds(bx, y, bw, bh).build();
        if (!FabricLoader.getInstance().isModLoaded("modmenu")) {
            mods.active = false;
            mods.setTooltip(Tooltip.create(Component.literal("Mod Menu belum terpasang")));
        }
        add(mods, true);
        y += bh + gap;

        // Save & Quit
        String quitLabel = minecraft.isLocalServer() ? "Save & Quit" : "Disconnect";
        add(Button.builder(Component.literal(quitLabel), b -> saveAndQuit())
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + 6;

        // Baris kecil 1: Advancements | Statistics
        int half = (bw - gap) / 2;
        add(Button.builder(Component.literal("Advancements"), b -> go(() -> ScreenFactory.advancements(this)))
                .bounds(bx, y, half, 20).build(), true);
        add(Button.builder(Component.literal("Statistics"), b -> go(() -> ScreenFactory.stats(this)))
                .bounds(bx + half + gap, y, bw - half - gap, 20).build(), true);
        y += 20 + gap;

        // Baris kecil 2: Accessibility (ikon) + Open to LAN (hanya singleplayer yang belum dibuka ke LAN)
        var server = minecraft.getSingleplayerServer();
        boolean canLan = server != null && !server.isPublished();
        Button access = CommonButtons.accessibility(20, b ->
                go(() -> new AccessibilityOptionsScreen(this, minecraft.options)), true);
        access.setTooltip(Tooltip.create(Component.literal("Accessibility")));
        access.setX(canLan ? bx : bx + (bw - 20) / 2);
        access.setY(y);
        add(access, true);
        if (canLan) {
            add(Button.builder(Component.literal("Open to LAN"), b -> go(() -> ScreenFactory.lan(this)))
                    .bounds(bx + 20 + gap, y, bw - 20 - gap, 20).build(), true);
        }
        y += 20 + 8;

        // "Game is paused"
        Component pausedText = Component.literal("Game is paused");
        int lw = font.width(pausedText) + 24;
        status = new StringWidget(bx + (bw - lw) / 2, y, lw, 16, pausedText, font);
        add(status, true);

        // Kanan atas: Settings (pengganti Social)
        Button settings = Button.builder(Component.literal("Settings"),
                        b -> go(() -> new OptionsScreen(this, minecraft.options, true)))
                .bounds(width - 104, 8, 96, 22).build();
        add(settings, false);

        // Nametag pemain
        Component name = Component.literal(minecraft.getUser().getName());
        int nw = font.width(name) + 8;
        int cx = panelW + (width - panelW) / 2;
        nameTag = new StringWidget(cx - nw / 2, (int) (height * 0.17f), nw, 12, name, font);
        add(nameTag, false);

        updateAnimation();
    }

    private void add(AbstractWidget w, boolean slide) {
        addRenderableWidget(w);
        all.add(w);
        if (slide) {
            sliding.add(w);
            slidingBaseX.add(w.getX());
        }
    }

    // ---------- transisi ----------

    private void startPhase(Phase p) {
        phase = p;
        phaseStart = System.currentTimeMillis();
    }

    /** Pause menu geser ke kiri + fade out, baru layar tujuan muncul (fade in + geser ke kanan). */
    private void go(Supplier<Screen> target) {
        if (phase == Phase.EXIT) return;
        pendingTarget = target;
        switchNow = false;
        startPhase(Phase.EXIT);
    }

    private void updateAnimation() {
        long el = System.currentTimeMillis() - phaseStart;
        switch (phase) {
            case ENTER -> {
                float p = Math.min(1f, el / (float) ENTER_MS);
                float q = 1f - p;
                float e = 1f - q * q * q;
                animAlpha = e;
                animOffset = -(1f - e) * SLIDE;
                if (p >= 1f) phase = Phase.IDLE;
            }
            case IDLE -> {
                animAlpha = 1f;
                animOffset = 0f;
            }
            case EXIT -> {
                float p = Math.min(1f, el / (float) EXIT_MS);
                animAlpha = 1f - p;
                animOffset = -p * SLIDE;
                if (p >= 1f && pendingTarget != null) switchNow = true;
            }
        }
        int off = Math.round(animOffset);
        for (int i = 0; i < sliding.size(); i++) {
            sliding.get(i).setX(slidingBaseX.get(i) + off);
        }
        for (AbstractWidget w : all) w.setAlpha(animAlpha);
    }

    @Override
    public void tick() {
        super.tick();
        if (switchNow) {
            switchNow = false;
            Supplier<Screen> t = pendingTarget;
            pendingTarget = null;
            Screen next = t == null ? null : t.get();
            if (next == null) {
                startPhase(Phase.ENTER); // gagal membuka -> munculkan lagi
            } else {
                Transition.show(minecraft, next);
            }
        }
    }

    // ---------- render ----------

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // Tanpa blur/dim di sisi kanan, hanya panel kiri yang digelapkan (seperti Bedrock).
        int off = Math.round(animOffset);
        int pa = (int) (0x99 * animAlpha);
        g.fill(off, 0, panelW + off, height, (pa << 24) | 0x101828);

        if (status != null) {
            int sa = (int) (0xFF * animAlpha);
            g.fill(status.getX(), status.getY(), status.getX() + status.getWidth(),
                    status.getY() + status.getHeight(), (sa << 24) | 0x0B4F0B);
        }
        if (nameTag != null) {
            int na = (int) (0x70 * animAlpha);
            g.fill(nameTag.getX() - 2, nameTag.getY() - 2, nameTag.getX() + nameTag.getWidth() + 2,
                    nameTag.getY() + nameTag.getHeight() + 2, na << 24);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        updateAnimation();
        super.extractRenderState(g, mx, my, a);

        // Tint hijau di tombol Resume Game
        if (resume != null) {
            int ga = (int) (0x88 * animAlpha);
            g.fill(resume.getX(), resume.getY(), resume.getX() + resume.getWidth(),
                    resume.getY() + resume.getHeight(), (ga << 24) | 0x1C9A1C);
        }

        ExtraRender.logo(g, panelW + 2 * Math.round(animOffset), animAlpha);

        if (animAlpha > 0.05f) {
            int cx = panelW + (width - panelW) / 2;
            int half = (int) (height * 0.14f);
            ExtraRender.player(g, cx - half, (int) (height * 0.24f), cx + half, (int) (height * 0.80f),
                    (int) (height * 0.24f), mx, my);
        }
    }

    // ---------- aksi ----------

    private static Screen modsScreen(Screen parent) {
        try {
            Class<?> c = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            return (Screen) c.getConstructor(Screen.class).newInstance(parent);
        } catch (Throwable t) {
            LOG.error("Gagal membuka Mod Menu", t);
            return null;
        }
    }

    /** Memakai logika disconnect bawaan PauseScreen (private onDisconnect) lewat reflection. */
    private void saveAndQuit() {
        if (phase == Phase.EXIT) return;
        try {
            Field f = Screen.class.getDeclaredField("minecraft");
            f.setAccessible(true);
            f.set(vanilla, minecraft);
            Method m = PauseScreen.class.getDeclaredMethod("onDisconnect");
            m.setAccessible(true);
            m.invoke(vanilla);
        } catch (Throwable t) {
            LOG.error("Gagal Save & Quit", t);
        }
    }
}
