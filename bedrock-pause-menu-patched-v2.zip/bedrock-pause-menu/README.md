# Bedrock Pause Menu (Fabric, MC 26.2, Loader 0.20.1)

Build:
1. Install JDK 25.
2. Taruh Gradle wrapper (salin folder `gradle/`, `gradlew`, `gradlew.bat` dari Fabric example mod 26.2),
   atau jalankan `gradle wrapper` jika Gradle 9.3+ sudah terpasang.
3. `./gradlew build` -> jar ada di `build/libs/`.
4. Pasang jar + Fabric API + Mod Menu di folder mods.

Kalau error saat compile, lihat bagian "Titik rawan" di chat; semuanya ada di 3 file:
BedrockPauseScreen.java, Transition.java, mixin/MinecraftMixin.java.
