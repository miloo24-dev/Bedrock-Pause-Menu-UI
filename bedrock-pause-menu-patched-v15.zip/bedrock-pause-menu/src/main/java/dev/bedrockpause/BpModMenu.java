package dev.bedrockpause;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.fabricmc.loader.api.FabricLoader;

/** Tombol konfigurasi di Mod Menu. */
public class BpModMenu implements ModMenuApi {
    public BpModMenu() {
        BedrockPauseClient.LOG.info("Mod Menu entrypoint BpModMenu dimuat");
    }

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        BedrockPauseClient.LOG.info("Mod Menu meminta layar konfigurasi");
        return parent -> FabricLoader.getInstance().isModLoaded("cloth-config")
                ? BpClothScreen.create(parent)
                : parent;
    }
}
