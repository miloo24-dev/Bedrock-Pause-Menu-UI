package dev.bedrockpause;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import org.slf4j.Logger;

/**
 * Model skin untuk title screen (tanpa dunia/pemain): memakai PlayerSkinWidget bawaan Minecraft lewat
 * reflection. Arah pandang digerakkan lewat field rotasi widget, dengan penghalusan.
 */
final class SkinWidget {
    private static final Logger LOG = BedrockPauseClient.LOG;

    private AbstractWidget widget;
    private Field rotX;
    private Field rotY;
    private float yaw;
    private float pitch;
    private float targetYaw;
    private float targetPitch;
    private long last;

    AbstractWidget create(Minecraft mc, int w, int h) {
        try {
            Class<?> cls = Class.forName("net.minecraft.client.gui.components.PlayerSkinWidget");
            Object models = byReturnType(mc, "EntityModelSet");
            Supplier<?> skin = skinSupplier(mc);
            LOG.info("PlayerSkinWidget: models={}, skin={}", models != null, skin != null);
            for (Constructor<?> k : cls.getConstructors()) {
                Class<?>[] t = k.getParameterTypes();
                Object[] args = new Object[t.length];
                int ints = 0;
                boolean ok = true;
                for (int i = 0; i < t.length; i++) {
                    if (t[i] == int.class) {
                        args[i] = ints++ == 0 ? w : h;
                    } else if (models != null && t[i].isInstance(models)) {
                        args[i] = models;
                    } else if (t[i] == Supplier.class && skin != null) {
                        args[i] = skin;
                    } else {
                        ok = false;
                        break;
                    }
                }
                if (!ok) continue;
                widget = (AbstractWidget) k.newInstance(args);
                break;
            }
            if (widget == null) {
                LOG.warn("PlayerSkinWidget: tidak ada constructor yang cocok");
                return null;
            }
            List<Field> floats = new ArrayList<>();
            for (Class<?> c = cls; c != null && c != AbstractWidget.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (f.getType() == float.class && !Modifier.isStatic(f.getModifiers())) floats.add(f);
                }
            }
            for (Field f : floats) LOG.info("PlayerSkinWidget float field: {}", f.getName());
            if (floats.size() >= 2) {
                rotX = floats.get(0);
                rotY = floats.get(1);
                rotX.setAccessible(true);
                rotY.setAccessible(true);
            }
            last = System.currentTimeMillis();
            return widget;
        } catch (Throwable t) {
            LOG.warn("Model skin title screen gagal dibuat: {}", t.toString());
            widget = null;
            return null;
        }
    }

    /** Perbarui arah pandang; kursor di atas tombol tidak mengubah target. */
    void update(int cx, int headY, int mx, int my, boolean overButton) {
        if (widget == null || rotX == null || rotY == null) return;
        long now = System.currentTimeMillis();
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        if (!overButton) {
            targetYaw = clamp((mx - cx) * 0.15f, -45f, 45f);
            targetPitch = clamp(-(my - headY) * 0.1f, -25f, 25f);
        }
        float k = 1f - (float) Math.exp(-dt * 8f);
        yaw += (targetYaw - yaw) * k;
        pitch += (targetPitch - pitch) * k;
        try {
            rotX.setFloat(widget, pitch);
            rotY.setFloat(widget, yaw);
        } catch (Throwable t) {
            rotX = null;
            rotY = null;
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static Object byReturnType(Object target, String simpleName) {
        try {
            for (Method m : target.getClass().getMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType().getSimpleName().equals(simpleName)) {
                    return m.invoke(target);
                }
            }
        } catch (Throwable ignored) {
            // lanjut ke null
        }
        return null;
    }

    private static Supplier<?> skinSupplier(Minecraft mc) {
        try {
            Object profile = byReturnType(mc, "GameProfile");
            Object sm = byReturnType(mc, "SkinManager");
            if (profile != null && sm != null) {
                for (Method m : sm.getClass().getMethods()) {
                    Class<?>[] t = m.getParameterTypes();
                    if (m.getName().equals("createLookup") && t.length == 2 && t[1] == boolean.class) {
                        return (Supplier<?>) m.invoke(sm, profile, false);
                    }
                }
            }
        } catch (Throwable t) {
            LOG.warn("createLookup gagal: {}", t.toString());
        }
        try {
            Class<?> d = Class.forName("net.minecraft.client.resources.DefaultPlayerSkin");
            UUID id = mc.getUser().getProfileId();
            for (Method m : d.getMethods()) {
                if (Modifier.isStatic(m.getModifiers()) && m.getName().equals("get") && m.getParameterCount() == 1
                        && m.getParameterTypes()[0] == UUID.class) {
                    Object skin = m.invoke(null, id);
                    return () -> skin;
                }
            }
        } catch (Throwable t) {
            LOG.warn("DefaultPlayerSkin gagal: {}", t.toString());
        }
        return null;
    }
}
