package dev.bedrockpause;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Konfigurasi mod: config/bedrockpause.properties (bisa diubah lewat Mod Menu + Cloth Config). */
public final class BpConfig {
    /** Ganti menu pause vanilla dengan menu pause ala Bedrock. */
    public static volatile boolean bedrockPauseMenu = true;
    /** Ganti title screen vanilla dengan title screen ala Bedrock. */
    public static volatile boolean bedrockTitleScreen = true;
    /** false = tanpa animasi slide/fade saat menu dibuka/ditutup. */
    public static volatile boolean animations = true;
    /** Tampilkan model skin pemain di sisi kanan (pause menu dan title screen). */
    public static volatile boolean skinDisplay = true;
    /** Tampilkan tombol ikon Report Bugs, Feedback, Report Player, dan Friends di pause menu. */
    public static volatile boolean showExtraButtons = false;
    /** Sembunyikan tulisan "Java Edition" di bawah logo Minecraft. */
    public static volatile boolean hideEditionBranding = false;

    /** Overlay kiri atas: koordinat, FPS, dan hari bermain (ala Bedrock). */
    public static volatile boolean showCoordinates = true;
    public static volatile boolean showFps = false;
    public static volatile boolean showDaysPlayed = false;

    private BpConfig() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("bedrockpause.properties");
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (var in = Files.newInputStream(p)) {
                    props.load(in);
                }
                bedrockPauseMenu = bool(props, "bedrockPauseMenu", true);
                bedrockTitleScreen = bool(props, "bedrockTitleScreen", true);
                animations = bool(props, "animations", true);
                skinDisplay = bool(props, "skinDisplay", true);
                showExtraButtons = bool(props, "showExtraButtons", false);
                hideEditionBranding = bool(props, "hideEditionBranding", false);
                showCoordinates = bool(props, "showCoordinates", true);
                showFps = bool(props, "showFps", false);
                showDaysPlayed = bool(props, "showDaysPlayed", false);
            } else {
                save();
            }
        } catch (Throwable t) {
            BedrockPauseClient.LOG.warn("Gagal membaca config: {}", t.toString());
        }
    }

    public static void save() {
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            Files.writeString(p,
                    "# Bedrock UI - bisa diubah lewat Mod Menu (butuh Cloth Config) atau langsung di file ini\n"
                            + "bedrockPauseMenu=" + bedrockPauseMenu + "\n"
                            + "bedrockTitleScreen=" + bedrockTitleScreen + "\n"
                            + "animations=" + animations + "\n"
                            + "skinDisplay=" + skinDisplay + "\n"
                            + "showExtraButtons=" + showExtraButtons + "\n"
                            + "hideEditionBranding=" + hideEditionBranding + "\n"
                            + "showCoordinates=" + showCoordinates + "\n"
                            + "showFps=" + showFps + "\n"
                            + "showDaysPlayed=" + showDaysPlayed + "\n");
        } catch (Throwable t) {
            BedrockPauseClient.LOG.warn("Gagal menyimpan config: {}", t.toString());
        }
    }
}
