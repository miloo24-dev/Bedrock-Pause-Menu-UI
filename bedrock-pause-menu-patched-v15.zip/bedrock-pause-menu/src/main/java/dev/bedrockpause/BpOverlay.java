package dev.bedrockpause;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;

/** Overlay kiri atas ala Bedrock: koordinat, FPS, hari bermain. */
final class BpOverlay {
    private BpOverlay() {}

    static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("bedrockpause", "overlay"),
                (g, tracker) -> render(g));
    }

    private static void render(GuiGraphicsExtractor g) {
        if (!BpConfig.showCoordinates && !BpConfig.showFps && !BpConfig.showDaysPlayed) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        List<String> lines = new ArrayList<>();
        Entity cam = mc.getCameraEntity();
        if (BpConfig.showCoordinates && cam != null) {
            lines.add("Position: " + cam.getBlockX() + ", " + cam.getBlockY() + ", " + cam.getBlockZ());
        }
        if (BpConfig.showFps) lines.add("FPS: " + mc.getFps());
        if (BpConfig.showDaysPlayed) lines.add("Day: " + days(mc));

        int y = 6;
        for (String s : lines) {
            Component c = Component.literal(s);
            int w = mc.font.width(c);
            g.fill(3, y - 3, 3 + w + 8, y + 11, 0x90000000);
            g.text(mc.font, c, 7, y, 0xFFFFFFFF);
            y += 16;
        }
    }

    private static long days(Minecraft mc) {
        try {
            Method m = mc.level.getClass().getMethod("getGameTime");
            return ((Number) m.invoke(mc.level)).longValue() / 24000L;
        } catch (Throwable t) {
            return 0L;
        }
    }
}
