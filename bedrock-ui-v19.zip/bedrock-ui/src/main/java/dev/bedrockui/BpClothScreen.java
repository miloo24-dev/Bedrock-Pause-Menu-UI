package dev.bedrockui;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Config screen (Cloth Config). Kept separate so Cloth Config is not required to run the mod. */
final class BpClothScreen {
    private BpClothScreen() {}

    static Screen create(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.literal("Bedrock UI"))
                .setSavingRunnable(BpConfig::save);
        ConfigEntryBuilder eb = builder.entryBuilder();

        ConfigCategory general = builder.getOrCreateCategory(Component.literal("Menus"));
        general.addEntry(eb.startBooleanToggle(Component.literal("Bedrock-style pause menu"), BpConfig.bedrockPauseMenu)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Replaces the vanilla pause menu with the Bedrock-style one."))
                .setSaveConsumer(v -> BpConfig.bedrockPauseMenu = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Bedrock-style title screen"), BpConfig.bedrockTitleScreen)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Replaces the vanilla main menu. Applies the next time the title screen opens."))
                .setSaveConsumer(v -> BpConfig.bedrockTitleScreen = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Slide/fade animations"), BpConfig.animations)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Turn off to open and close menus without animations."))
                .setSaveConsumer(v -> BpConfig.animations = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Show player skin"), BpConfig.skinDisplay)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Player model on the right side of the pause menu and title screen."))
                .setSaveConsumer(v -> BpConfig.skinDisplay = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Extra icon buttons (pause menu)"), BpConfig.showExtraButtons)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Report Bugs, Feedback, Report Player and Friends."))
                .setSaveConsumer(v -> BpConfig.showExtraButtons = v)
                .build());

        general.addEntry(eb.startBooleanToggle(Component.literal("Bedrock-style loading screen"), BpConfig.bedrockLoadingScreen)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Bedrock-style loading screen when joining or leaving a world."))
                .setSaveConsumer(v -> BpConfig.bedrockLoadingScreen = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Inventory/container animation"), BpConfig.containerAnimation)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Inventories and containers slide up while the dark background fades in."))
                .setSaveConsumer(v -> BpConfig.containerAnimation = v)
                .build());

        ConfigCategory gui = builder.getOrCreateCategory(Component.literal("GUI"));
        gui.addEntry(eb.startBooleanToggle(Component.literal("Inventory slot highlight"), BpConfig.slotHighlight)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Green highlight on the slot you hover in inventories and containers."))
                .setSaveConsumer(v -> BpConfig.slotHighlight = v)
                .build());
        gui.addEntry(eb.startBooleanToggle(Component.literal("Hide edition branding"), BpConfig.hideEditionBranding)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Hides the \"Java Edition\" text under the Minecraft logo."))
                .setSaveConsumer(v -> BpConfig.hideEditionBranding = v)
                .build());
        gui.addEntry(eb.startBooleanToggle(Component.literal("Overlay: coordinates"), BpConfig.showCoordinates)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Shows your position (X, Y, Z) at the top left of the screen."))
                .setSaveConsumer(v -> BpConfig.showCoordinates = v)
                .build());
        gui.addEntry(eb.startBooleanToggle(Component.literal("Overlay: FPS"), BpConfig.showFps)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Shows the current FPS at the top left of the screen."))
                .setSaveConsumer(v -> BpConfig.showFps = v)
                .build());
        gui.addEntry(eb.startBooleanToggle(Component.literal("Overlay: days played"), BpConfig.showDaysPlayed)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Shows how many in-game days have passed in this world."))
                .setSaveConsumer(v -> BpConfig.showDaysPlayed = v)
                .build());

        gui.addEntry(eb.startBooleanToggle(Component.literal("Overlay: facing direction"), BpConfig.showDirection)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Shows the compass direction you are facing."))
                .setSaveConsumer(v -> BpConfig.showDirection = v)
                .build());
        gui.addEntry(eb.startBooleanToggle(Component.literal("Overlay: right side"), BpConfig.overlayRight)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Show the overlay on the right side of the screen."))
                .setSaveConsumer(v -> BpConfig.overlayRight = v)
                .build());
        gui.addEntry(eb.startIntSlider(Component.literal("Overlay: vertical position (%)"), BpConfig.overlayY, 0, 60)
                .setDefaultValue(20)
                .setTooltip(Component.literal("How far down the screen the overlay starts."))
                .setSaveConsumer(v -> BpConfig.overlayY = v)
                .build());

        return builder.build();
    }
}
