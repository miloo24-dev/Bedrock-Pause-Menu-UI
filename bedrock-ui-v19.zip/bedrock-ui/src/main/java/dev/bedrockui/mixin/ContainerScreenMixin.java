package dev.bedrockui.mixin;

import dev.bedrockui.BpConfig;
import dev.bedrockui.ContainerAnim;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Close animation hook and the green slot highlight (same targets as BedrockIfy's slot highlight). */
@Mixin(AbstractContainerScreen.class)
public abstract class ContainerScreenMixin {
    @Shadow
    protected Slot hoveredSlot;

    @Inject(method = "onClose", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$close(CallbackInfo ci) {
        if (ContainerAnim.interceptClose(this)) {
            ci.cancel();
        }
    }

    @Inject(method = "extractSlotHighlightBack", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$highlightBack(GuiGraphicsExtractor g, CallbackInfo ci) {
        if (!BpConfig.slotHighlight || hoveredSlot == null || !hoveredSlot.isHighlightable()) return;
        ci.cancel();
        int x = hoveredSlot.x;
        int y = hoveredSlot.y;
        // gentle pulse so the highlight feels alive
        double t = (System.currentTimeMillis() % 1400L) / 1400.0 * Math.PI * 2.0;
        int fill = 0x40 + (int) (0x14 * Math.sin(t));
        g.fill(x, y, x + 16, y + 16, (fill << 24) | 0x3CD84A);
        int line = 0xFF5BE86A;
        g.fill(x - 1, y - 1, x + 17, y, line);
        g.fill(x - 1, y + 16, x + 17, y + 17, line);
        g.fill(x - 1, y, x, y + 16, line);
        g.fill(x + 16, y, x + 17, y + 16, line);
    }

    @Inject(method = "extractSlotHighlightFront", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockui$highlightFront(GuiGraphicsExtractor g, CallbackInfo ci) {
        if (BpConfig.slotHighlight) {
            ci.cancel();
        }
    }
}
