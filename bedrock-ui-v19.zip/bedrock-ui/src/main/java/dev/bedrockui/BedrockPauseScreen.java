package dev.bedrockui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseScreen extends Screen {
    private static final Logger LOG = LoggerFactory.getLogger("bedrockui");

    private static final long ENTER_MS = 280L;
    private static final long EXIT_MS = 200L;
    private static final float SLIDE = 40f;

    private enum Phase { ENTER, IDLE, EXIT }

    private final PauseScreen vanilla;

    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<AbstractWidget> sliding = new ArrayList<>();
    private final List<Integer> slidingBaseX = new ArrayList<>();

    private Phase phase = Phase.ENTER;
    private long phaseStart = System.currentTimeMillis();
    private Supplier<Screen> pendingTarget;
    private boolean switchNow;
    /** Set by the mixin when this screen is shown again (coming back from Options etc.). */
    public boolean replayEnter;

    // Player model look direction: follows the cursor smoothly, but clicks/touches over buttons are ignored
    private float lookX;
    private float lookY;
    private float targetX;
    private float targetY;
    private boolean lookInit;
    private long lastFrame;

    private float animAlpha;
    private float animOffset;
    private int panelW;

    private Button resume;
    private StringWidget status;
    private StringWidget nameTag;

    public BedrockPauseScreen(PauseScreen vanilla) {
        super(Component.translatable("menu.game"));
        this.vanilla = vanilla;
    }

    @Override
    public boolean isPauseScreen() {
        return true;
    }

    @Override
    protected void init() {
        all.clear();
        sliding.clear();
        slidingBaseX.clear();
        // Coming back from another screen (Options etc.): still in EXIT and the target was consumed -> play the enter animation.
        if (replayEnter || (phase == Phase.EXIT && pendingTarget == null)) {
            replayEnter = false;
            startPhase(Phase.ENTER);
        }

        panelW = (int) (width * 0.557f);
        int bw = Math.min(Math.max((int) (width * 0.34f), 150), 240);
        int bh = height >= 300 ? 24 : 20;
        int gap = 4;
        int bx = (panelW - bw) / 2;
        int cx = panelW + (width - panelW) / 2;

        // Left layout: logo -> "Game is paused" -> long buttons -> small icon row.
        // The whole block is shifted down so it is vertically centered.
        boolean hasModMenu = FabricLoader.getInstance().isModLoaded("modmenu");
        // Original vanilla PauseScreen buttons are borrowed (so their actions match vanilla): Multiplayer, Save & Quit, icon buttons.
        // In 26.2 "Open to LAN" was replaced by "Multiplayer Options" (ShareToLanScreen no longer exists).
        List<AbstractWidget> vw = vanillaWidgets();
        AbstractWidget mp = findVanilla(vw, "multiplayeroptions", "sharetolan");
        var server = minecraft.getSingleplayerServer();
        boolean canLan = server != null && !server.isPublished();
        int nLong = 3 + (mp != null ? 1 : 0); // Resume, Settings, (Multiplayer), Save & Quit
        int contentBottom = 86 + 14 + 4 + nLong * (bh + gap) + 2 + 20;
        layoutShift = Math.max(0, Math.min(40, (height - contentBottom - 30) / 2));

        Component pausedText = Component.literal("Game is paused");
        int tw = font.width(pausedText);
        int sy = 86 + layoutShift;
        status = new StringWidget(bx + (bw - tw) / 2, sy + 2, tw, 10, pausedText, font);
        add(status, true);
        int y = sy + 14 + 4;

        // Tombol panjang: Resume Game, Settings, (Multiplayer), Save & Quit
        resume = Button.builder(Component.literal("Resume Game"), b -> onClose())
                .bounds(bx, y, bw, bh).build();
        add(resume, true);
        y += bh + gap;

        add(Button.builder(Component.literal("Settings"),
                        b -> go(() -> new OptionsScreen(this, minecraft.options, true)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap;

        String debug = null;

        if (mp != null) {
            place(mp, null, bx, y, bw, bh); // label vanilla dipertahankan
            add(mp, true);
            y += bh + gap;
        } else if (canLan) {
            debug = "[bp] vanilla Multiplayer button not found (widgets=" + vw.size() + ")";
        }

        String quitLabel = minecraft.isLocalServer() ? "Save & Quit" : "Disconnect";
        AbstractWidget quit = findVanilla(vw, "returntomenu", "disconnect", "save & quit");
        if (quit == null) {
            quit = lowestWide(vw);
            if (quit != null) LOG.warn("Vanilla quit button found by position: {}", quit.getMessage().getContents());
        }
        if (quit != null) {
            place(quit, quitLabel, bx, y, bw, bh);
            add(quit, true);
        } else {
            if (debug == null) debug = "[bp] vanilla quit button not found (widgets=" + vw.size() + ")";
            add(Button.builder(Component.literal(quitLabel), b -> saveAndQuit())
                    .bounds(bx, y, bw, bh).build(), true);
        }
        y += bh + gap + 2;

        if (debug != null) {
            Component dc = Component.literal(debug);
            add(new StringWidget(bx, height - 14, font.width(dc), 10, dc, font), false);
        }

        // Small icon button row (20x20 squares), centered. Extra buttons (Report Bugs, Feedback, Report Player,
        // Friends) only show when showExtraButtons is enabled in the config.
        int is = 20;
        boolean extras = BpConfig.showExtraButtons;
        final AbstractWidget modWidget = findVanilla(vw, "modmenu");
        boolean showMods = modWidget != null || hasModMenu;
        int count = (extras ? 4 : 0) + (showMods ? 1 : 0) + 1; // + Accessibility
        int ix = bx + (bw - (count * is + (count - 1) * gap)) / 2;
        iconWidgets.clear();
        iconShapes.clear();

        if (extras) {
            iconSlot(vw, "reportbugs", ix, y, () -> openLink("https://aka.ms/javabugs"), "Report Bugs", Icons.BUG);
            ix += is + gap;
            iconSlot(vw, "sendfeedback", ix, y, () -> openLink("https://aka.ms/javafeedback"), "Send Feedback", Icons.FEEDBACK);
            ix += is + gap;
            iconSlot(vw, "playerreporting", ix, y, () -> go(() -> ScreenFactory.social(this)), "Report Player", Icons.REPORT);
            ix += is + gap;
            iconSlot(vw, "friends", ix, y, () -> go(() -> ScreenFactory.social(this)), "Friends", Icons.FRIENDS);
            ix += is + gap;
        }

        // Mods: the small icon button from Mod Menu itself (if installed)
        if (modWidget != null) {
            modWidget.setX(ix);
            modWidget.setY(y);
            add(modWidget, true);
            ix += is + gap;
        } else if (hasModMenu) {
            Button m = Button.builder(Component.literal("M"), b -> go(() -> modsScreen(this)))
                    .bounds(ix, y, is, is).build();
            m.setTooltip(Tooltip.create(Component.literal("Mods")));
            add(m, true);
            ix += is + gap;
        }

        Button access = CommonButtons.accessibility(20, b ->
                go(() -> new AccessibilityOptionsScreen(this, minecraft.options)), true);
        access.setTooltip(Tooltip.create(Component.literal("Accessibility")));
        access.setX(ix);
        access.setY(y);
        add(access, true);

        // Right panel: name tag, player model, then the Statistics button below the model
        Component name = Component.literal(minecraft.getUser().getName());
        int nw = font.width(name);
        if (BpConfig.skinDisplay) {
            nameTag = new StringWidget(cx - nw / 2, (int) (height * 0.17f), nw, 12, name, font);
            add(nameTag, false);
        }

        int sbw = Math.max(60, Math.min(110, width - panelW - 16));
        int sby = Math.min((int) (height * 0.77f), height - 28);
        AbstractWidget statsW = findVanilla(vw, "gui.stats", "literal{statistics}");
        if (statsW != null) {
            place(statsW, "Statistics", cx - sbw / 2, sby, sbw, 20);
            add(statsW, false);
        } else {
            add(Button.builder(Component.literal("Statistics"), b -> go(() -> ScreenFactory.stats(this)))
                            .bounds(cx - sbw / 2, sby, sbw, 20).build(), false);
        }

        updateAnimation();
    }

    private void add(AbstractWidget w, boolean slide) {
        addRenderableWidget(w);
        all.add(w);
        if (slide) {
            sliding.add(w);
            slidingBaseX.add(w.getX());
        }
    }

    /** Vanilla icon button (the game's own icon) if available; otherwise our own button with an icon converted from PNG. */
    private void iconSlot(List<AbstractWidget> vw, String key, int x, int y, Runnable action, String tip, Icons.Icon fallback) {
        AbstractWidget w = findVanilla(vw, key);
        if (w != null) {
            w.setX(x);
            w.setY(y);
            add(w, true);
            return;
        }
        addIcon(Button.builder(Component.literal(""), b -> action.run()).bounds(x, y, 20, 20).build(), tip, fallback);
    }

    /** Presses a vanilla/mod widget through its onPress method (with a null argument if needed). */
    private static boolean press(AbstractWidget w) {
        if (w == null) return false;
        for (Method m : w.getClass().getMethods()) {
            if (!m.getName().equals("onPress")) continue;
            Class<?>[] types = m.getParameterTypes();
            try {
                if (types.length == 0) {
                    m.invoke(w);
                    return true;
                }
                if (types.length == 1 && !types[0].isPrimitive()) {
                    m.invoke(w, new Object[] {null});
                    return true;
                }
            } catch (Throwable ex) {
                LOG.warn("press failed: {}", ex.toString());
            }
        }
        return false;
    }

    // ---------- borrowing vanilla buttons ----------

    /** List of vanilla PauseScreen widgets; the vanilla screen is initialized first if it has not been built yet. */
    private List<AbstractWidget> vanillaWidgets() {
        List<AbstractWidget> out = new ArrayList<>();
        try {
            if (vanilla.children().isEmpty()) {
                BedrockUiClient.suppressFallback = true;
                try {
                    initVanilla();
                } finally {
                    BedrockUiClient.suppressFallback = false;
                }
            }
            for (Object c : vanilla.children()) {
                if (c instanceof AbstractWidget w) {
                    out.add(w);
                    if (!loggedWidgets) {
                        LOG.info("vanilla widget: {} '{}' {}x{}", w.getClass().getSimpleName(),
                                w.getMessage().getContents(), w.getWidth(), w.getHeight());
                    }
                }
            }
            loggedWidgets = true;
        } catch (Throwable t) {
            LOG.error("Failed to read the vanilla buttons", t);
        }
        return out;
    }

    private void initVanilla() throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(minecraft) && t[1] == int.class && t[2] == int.class) {
                m.invoke(vanilla, minecraft, width, height);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(vanilla, width, height);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    private static AbstractWidget findVanilla(List<AbstractWidget> list, String... keys) {
        for (AbstractWidget w : list) {
            String s = String.valueOf(w.getMessage().getContents()).toLowerCase();
            for (String k : keys) {
                if (s.contains(k.toLowerCase())) return w;
            }
        }
        return null;
    }

    /** The lowest wide (>=150) button; in vanilla that is Save & Quit / Disconnect. */
    private static AbstractWidget lowestWide(List<AbstractWidget> list) {
        AbstractWidget best = null;
        for (AbstractWidget w : list) {
            if (w instanceof Button && w.getWidth() >= 150 && (best == null || w.getY() >= best.getY())) best = w;
        }
        return best;
    }

    private static void place(AbstractWidget w, String label, int x, int y, int width, int height) {
        if (label != null) w.setMessage(Component.literal(label));
        w.setX(x);
        w.setY(y);
        resize(w, width, height);
    }

    private static void resize(AbstractWidget w, int width, int height) {
        try {
            w.setWidth(width);
        } catch (Throwable t) {
            setIntField(w, "width", width);
        }
        try {
            Method m = AbstractWidget.class.getMethod("setHeight", int.class);
            m.invoke(w, height);
        } catch (Throwable t) {
            setIntField(w, "height", height);
        }
    }

    private static void setIntField(Object o, String name, int value) {
        try {
            for (Class<?> c = o.getClass(); c != null; c = c.getSuperclass()) {
                try {
                    java.lang.reflect.Field f = c.getDeclaredField(name);
                    f.setAccessible(true);
                    f.setInt(o, value);
                    return;
                } catch (NoSuchFieldException ignored) {
                    // cari di superclass
                }
            }
        } catch (Throwable t) {
            LOG.warn("Failed to set {}: {}", name, t.toString());
        }
    }

    // ---------- small icons (drawn in code) ----------

    private final List<AbstractWidget> iconWidgets = new ArrayList<>();
    private final List<Icons.Icon> iconShapes = new ArrayList<>();
    private int layoutShift;
    private static boolean loggedWidgets;

    private void addIcon(Button b, String tip, Icons.Icon shape) {
        b.setTooltip(Tooltip.create(Component.literal(tip)));
        add(b, true);
        iconWidgets.add(b);
        iconShapes.add(shape);
    }

    private static void drawIcon(GuiGraphicsExtractor g, AbstractWidget w, Icons.Icon icon, int alpha) {
        int ox = w.getX() + (w.getWidth() - icon.w()) / 2;
        int oy = w.getY() + (w.getHeight() - icon.h()) / 2;
        int[] r = icon.r();
        for (int i = 0; i + 4 < r.length; i += 5) {
            int argb = r[i + 4];
            int a = (argb >>> 24) * alpha / 255;
            fillA(g, ox + r[i], oy + r[i + 1], ox + r[i] + r[i + 2], oy + r[i + 1] + r[i + 3], a, argb & 0xFFFFFF);
        }
    }

    /** Opens a link through the built-in confirmation screen (ConfirmLinkScreen.confirmLinkNow). */
    private void openLink(String url) {
        try {
            Class<?> c = Class.forName("net.minecraft.client.gui.screens.ConfirmLinkScreen");
            for (Method m : c.getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getName().equals("confirmLinkNow")
                        && t.length == 2 && t[0] == Screen.class && t[1] == String.class) {
                    m.invoke(null, this, url);
                    return;
                }
            }
            throw new NoSuchMethodException("ConfirmLinkScreen.confirmLinkNow(Screen, String)");
        } catch (Throwable t) {
            LOG.error("Failed to open the link", t);
        }
    }

    // ---------- transisi ----------

    private void startPhase(Phase p) {
        phase = p;
        phaseStart = System.currentTimeMillis();
    }

    /** The pause menu slides left + fades out, then the destination screen appears (fade in + slide right). */
    private void go(Supplier<Screen> target) {
        if (phase == Phase.EXIT) return;
        pendingTarget = target;
        switchNow = false;
        startPhase(Phase.EXIT);
    }

    private void updateAnimation() {
        long el = System.currentTimeMillis() - phaseStart;
        switch (phase) {
            case ENTER -> {
                float p = BpConfig.animations ? Math.min(1f, el / (float) ENTER_MS) : 1f;
                float q = 1f - p;
                float e = 1f - q * q * q * q; // ease-out quart
                animAlpha = e;
                animOffset = -(1f - e) * SLIDE;
                if (p >= 1f) phase = Phase.IDLE;
            }
            case IDLE -> {
                animAlpha = 1f;
                animOffset = 0f;
            }
            case EXIT -> {
                float p = BpConfig.animations ? Math.min(1f, el / (float) EXIT_MS) : 1f;
                animAlpha = 1f - p * p;
                animOffset = -(p * p) * SLIDE;
                if (p >= 1f && pendingTarget != null) switchNow = true;
            }
        }
        int off = Math.round(animOffset);
        for (int i = 0; i < sliding.size(); i++) {
            sliding.get(i).setX(slidingBaseX.get(i) + off);
        }
        for (AbstractWidget w : all) w.setAlpha(animAlpha);
    }

    @Override
    public void tick() {
        super.tick();
        if (switchNow) {
            switchNow = false;
            Supplier<Screen> t = pendingTarget;
            pendingTarget = null;
            Screen next = t == null ? null : t.get();
            if (next == null) {
                startPhase(Phase.ENTER); // failed to open -> show the menu again
            } else {
                Transition.show(minecraft, next);
            }
        }
    }

    // ---------- render ----------

    /** fill that is skipped when alpha is 0 (some versions treat alpha 0 as opaque). */
    private static void fillA(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int alpha, int rgb) {
        if (alpha <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(alpha, 255) << 24) | (rgb & 0xFFFFFF));
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // No blur/dim on the right side; only the left panel is darkened (like Bedrock).
        int off = Math.round(animOffset);
        int px2 = panelW + off;
        fillA(g, off, 0, px2, height, (int) (0xB4 * animAlpha), 0x000000);

        if (status != null) {
            int x1 = status.getX() - 6;
            int x2 = status.getX() + status.getWidth() + 6;
            int y1 = status.getY() - 2;
            int y2 = status.getY() + status.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0xC8 * animAlpha), 0x000000);
        }
        if (nameTag != null) {
            int x1 = nameTag.getX() - 4;
            int x2 = nameTag.getX() + nameTag.getWidth() + 4;
            int y1 = nameTag.getY() - 2;
            int y2 = nameTag.getY() + nameTag.getHeight() + 2;
            fillA(g, x1, y1, x2, y2, (int) (0x70 * animAlpha), 0x000000);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        updateAnimation();
        super.extractRenderState(g, mx, my, a);

        // Icons on the small square buttons
        int ia = (int) (0xFF * animAlpha);
        for (int i = 0; i < iconWidgets.size(); i++) {
            AbstractWidget w = iconWidgets.get(i);
            drawIcon(g, w, iconShapes.get(i), w.active ? ia : ia * 4 / 10);
        }

        g.pose().pushMatrix();
        g.pose().translate(0f, (float) layoutShift);
        ExtraRender.logo(g, panelW + 2 * Math.round(animOffset), animAlpha);
        g.pose().popMatrix();

        int cx = panelW + (width - panelW) / 2;
        long now = System.currentTimeMillis();
        if (!lookInit) {
            lookInit = true;
            lookX = targetX = cx - 30;
            lookY = targetY = height * 0.34f;
            lastFrame = now;
        }
        float dt = Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;

        // While the cursor/finger is over a button the look target is unchanged (no "jump" when clicking)
        boolean overButton = false;
        for (AbstractWidget w : all) {
            if (!(w instanceof Button)) continue;
            if (mx >= w.getX() && mx < w.getX() + w.getWidth() && my >= w.getY() && my < w.getY() + w.getHeight()) {
                overButton = true;
                break;
            }
        }
        if (!overButton) {
            targetX = mx;
            targetY = my;
        }
        float k = 1f - (float) Math.exp(-dt * 8f); // gerak halus menuju target
        lookX += (targetX - lookX) * k;
        lookY += (targetY - lookY) * k;

        if (BpConfig.skinDisplay && animAlpha > 0.05f) {
            int half = (int) (height * 0.14f);
            ExtraRender.player(g, cx - half, (int) (height * 0.24f), cx + half, (int) (height * 0.74f),
                    (int) (height * 0.22f), Math.round(lookX), Math.round(lookY));
        }
    }

    // ---------- aksi ----------

    private static Screen modsScreen(Screen parent) {
        try {
            Class<?> c = Class.forName("com.terraformersmc.modmenu.gui.ModsScreen");
            return (Screen) c.getConstructor(Screen.class).newInstance(parent);
        } catch (Throwable t) {
            LOG.error("Failed to open Mod Menu", t);
            return null;
        }
    }

    /** Uses the PauseScreen's own disconnect logic (private onDisconnect) via reflection. */
    private void saveAndQuit() {
        if (phase == Phase.EXIT) return;
        try {
            Field f = Screen.class.getDeclaredField("minecraft");
            f.setAccessible(true);
            f.set(vanilla, minecraft);
            Method m = null;
            try {
                m = PauseScreen.class.getDeclaredMethod("onDisconnect");
            } catch (NoSuchMethodException e) {
                for (Method c : PauseScreen.class.getDeclaredMethods()) {
                    if (c.getParameterCount() == 0 && c.getName().toLowerCase().contains("disconnect")) {
                        m = c;
                        break;
                    }
                }
            }
            if (m == null) throw new NoSuchMethodException("PauseScreen.*disconnect");
            m.setAccessible(true);
            m.invoke(vanilla);
        } catch (Throwable t) {
            LOG.error("Save & Quit failed", t);
        }
    }
}
