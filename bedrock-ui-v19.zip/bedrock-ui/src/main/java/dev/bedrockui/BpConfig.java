package dev.bedrockui;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Mod settings: config/bedrockui.properties (editable through Mod Menu + Cloth Config). */
public final class BpConfig {
    /** Replace the vanilla pause menu with the Bedrock-style one. */
    public static volatile boolean bedrockPauseMenu = true;
    /** Replace the vanilla title screen with the Bedrock-style one. */
    public static volatile boolean bedrockTitleScreen = true;
    /** false = no slide/fade animation when menus open or close. */
    public static volatile boolean animations = true;
    /** Show the player skin model on the right side (pause menu and title screen). */
    public static volatile boolean skinDisplay = true;
    /** Show the Report Bugs, Feedback, Report Player and Friends icon buttons in the pause menu. */
    public static volatile boolean showExtraButtons = false;
    /** Hide the "Java Edition" text under the Minecraft logo. */
    public static volatile boolean hideEditionBranding = false;

    /** Top-left overlay: coordinates, FPS and days played (Bedrock style). */
    public static volatile boolean showCoordinates = true;
    public static volatile boolean showFps = false;
    public static volatile boolean showDaysPlayed = false;

    /** Bedrock-style loading screens (joining a world, saving, progress screens). */
    public static volatile boolean bedrockLoadingScreen = true;
    /** Inventories and containers slide up from the bottom while the dark background fades in. */
    public static volatile boolean containerAnimation = true;

    /** Green highlight on the hovered slot in inventories and containers. */
    public static volatile boolean slotHighlight = true;
    /** Overlay: show the direction you are facing. */
    public static volatile boolean showDirection = false;
    /** Overlay: put it on the right side of the screen instead of the left. */
    public static volatile boolean overlayRight = false;
    /** Overlay: vertical position in percent of the screen height. */
    public static volatile int overlayY = 20;

    private BpConfig() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("bedrockui.properties");
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (var in = Files.newInputStream(p)) {
                    props.load(in);
                }
                bedrockPauseMenu = bool(props, "bedrockPauseMenu", true);
                bedrockTitleScreen = bool(props, "bedrockTitleScreen", true);
                animations = bool(props, "animations", true);
                skinDisplay = bool(props, "skinDisplay", true);
                showExtraButtons = bool(props, "showExtraButtons", false);
                hideEditionBranding = bool(props, "hideEditionBranding", false);
                showCoordinates = bool(props, "showCoordinates", true);
                showFps = bool(props, "showFps", false);
                showDaysPlayed = bool(props, "showDaysPlayed", false);
                bedrockLoadingScreen = bool(props, "bedrockLoadingScreen", true);
                containerAnimation = bool(props, "containerAnimation", true);
                slotHighlight = bool(props, "slotHighlight", true);
                showDirection = bool(props, "showDirection", false);
                overlayRight = bool(props, "overlayRight", false);
                try {
                    overlayY = Math.max(0, Math.min(60, Integer.parseInt(props.getProperty("overlayY", "20").trim())));
                } catch (NumberFormatException e) {
                    overlayY = 20;
                }
            } else {
                save();
            }
        } catch (Throwable t) {
            BedrockUiClient.LOG.warn("Failed to read config: {}", t.toString());
        }
    }

    public static void save() {
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            Files.writeString(p,
                    "# Bedrock UI - edit through Mod Menu (needs Cloth Config) or directly in this file\n"
                            + "bedrockPauseMenu=" + bedrockPauseMenu + "\n"
                            + "bedrockTitleScreen=" + bedrockTitleScreen + "\n"
                            + "animations=" + animations + "\n"
                            + "skinDisplay=" + skinDisplay + "\n"
                            + "showExtraButtons=" + showExtraButtons + "\n"
                            + "hideEditionBranding=" + hideEditionBranding + "\n"
                            + "showCoordinates=" + showCoordinates + "\n"
                            + "showFps=" + showFps + "\n"
                            + "showDaysPlayed=" + showDaysPlayed + "\n"
                            + "bedrockLoadingScreen=" + bedrockLoadingScreen + "\n"
                            + "containerAnimation=" + containerAnimation + "\n"
                            + "slotHighlight=" + slotHighlight + "\n"
                            + "showDirection=" + showDirection + "\n"
                            + "overlayRight=" + overlayRight + "\n"
                            + "overlayY=" + overlayY + "\n");
        } catch (Throwable t) {
            BedrockUiClient.LOG.warn("Failed to save config: {}", t.toString());
        }
    }
}
