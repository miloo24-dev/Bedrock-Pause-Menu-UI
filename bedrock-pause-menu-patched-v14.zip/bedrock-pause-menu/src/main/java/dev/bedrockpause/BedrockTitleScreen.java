package dev.bedrockpause;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CommonButtons;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

/**
 * Title screen ala Bedrock. Latar (panorama), logo, splash, dan teks versi tetap digambar oleh
 * TitleScreen vanilla (widget-nya dibuang); tombol, skin pemain, dan animasinya milik kita.
 */
public class BedrockTitleScreen extends Screen {
    private static final Logger LOG = BedrockPauseClient.LOG;
    private static final long ENTER_MS = 220L;
    private static final long EXIT_MS = 170L;
    private static final int SLIDE = 36;

    private enum Phase { ENTER, IDLE, EXIT }

    private final TitleScreen vanilla;
    private final List<AbstractWidget> all = new ArrayList<>();
    private final List<AbstractWidget> sliding = new ArrayList<>();
    private final List<Integer> slidingBaseX = new ArrayList<>();
    private final SkinDisplay skin = new SkinDisplay();

    private Phase phase = Phase.ENTER;
    private long phaseStart = System.currentTimeMillis();
    private float animAlpha;
    private float animOffset;
    private Supplier<Screen> pendingTarget;
    private boolean switchNow;

    private StringWidget nameTag;
    private int skinCx;

    public BedrockTitleScreen(TitleScreen vanilla) {
        super(Component.literal("Minecraft"));
        this.vanilla = vanilla;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    protected void init() {
        all.clear();
        sliding.clear();
        slidingBaseX.clear();
        nameTag = null;
        if (phase == Phase.EXIT && pendingTarget == null) {
            startPhase(Phase.ENTER); // kembali dari layar lain
        }
        buildVanilla();

        int bw = Math.min(Math.max((int) (width * 0.34f), 150), 240);
        int bh = height >= 300 ? 24 : 20;
        int gap = 4;
        int bx = (width - bw) / 2;
        int blockH = 3 * (bh + gap) + 2 + 20;
        int y = Math.max(96, (int) (height * 0.46f));
        y = Math.max(60, Math.min(y, height - blockH - 26));

        add(Button.builder(Component.literal("Play"), b -> go(() -> ScreenFactory.create(
                        "net.minecraft.client.gui.screens.worldselection.SelectWorldScreen", this)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap;
        add(Button.builder(Component.literal("Multiplayer"), b -> go(() -> ScreenFactory.create(
                        "net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen", this)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap;
        add(Button.builder(Component.literal("Settings"),
                        b -> go(() -> new OptionsScreen(this, minecraft.options, false)))
                .bounds(bx, y, bw, bh).build(), true);
        y += bh + gap + 2;

        // Baris kecil: Accessibility (ikon) + Mods
        int mw = 56;
        int rx = bx + (bw - (20 + gap + mw)) / 2;
        Button access = CommonButtons.accessibility(20, b ->
                go(() -> new AccessibilityOptionsScreen(this, minecraft.options)), true);
        access.setTooltip(Tooltip.create(Component.literal("Accessibility")));
        access.setX(rx);
        access.setY(y);
        add(access, true);

        boolean hasModMenu = FabricLoader.getInstance().isModLoaded("modmenu");
        Button mods = Button.builder(Component.literal("Mods"), b -> go(() -> ScreenFactory.create(
                        "com.terraformersmc.modmenu.gui.ModsScreen", this)))
                .bounds(rx + 20 + gap, y, mw, 20).build();
        mods.active = hasModMenu;
        if (!hasModMenu) mods.setTooltip(Tooltip.create(Component.literal("Mod Menu belum terpasang")));
        add(mods, true);

        // Kiri bawah: Quit
        add(Button.builder(Component.literal("Quit"), b -> minecraft.stop())
                .bounds(8, height - 28, 60, 20).build(), false);

        // Kanan: nama pemain, model skin (digambar di extractRenderState), tombol Skins
        skinCx = (int) (width * 0.83f);
        if (BpConfig.skinDisplay) {
            Component name = Component.literal(minecraft.getUser().getName());
            int nw = font.width(name);
            nameTag = new StringWidget(skinCx - nw / 2, (int) (height * 0.17f), nw, 12, name, font);
            add(nameTag, false);
        }
        int sbw = 80;
        int sby = Math.min((int) (height * 0.77f), height - 28);
        add(Button.builder(Component.literal("Skins"), b -> go(() -> ScreenFactory.create(
                        "net.minecraft.client.gui.screens.options.SkinCustomizationScreen", this, minecraft.options)))
                .bounds(skinCx - sbw / 2, sby, sbw, 20).build(), false);

        updateAnimation();
    }

    /** Bangun TitleScreen vanilla (panorama, logo, splash), lalu buang widget bawaannya. */
    private void buildVanilla() {
        BedrockPauseClient.suppressFallback = true;
        try {
            for (Method m : Screen.class.getMethods()) {
                if (!m.getName().equals("init")) continue;
                Class<?>[] t = m.getParameterTypes();
                if (t.length == 3 && t[0].isInstance(minecraft) && t[1] == int.class && t[2] == int.class) {
                    m.invoke(vanilla, minecraft, width, height);
                    break;
                }
            }
            try {
                Method c = Screen.class.getDeclaredMethod("clearWidgets");
                c.setAccessible(true);
                c.invoke(vanilla);
            } catch (Throwable t) {
                LOG.warn("clearWidgets gagal, widget vanilla disembunyikan: {}", t.toString());
                for (Object o : vanilla.children()) {
                    if (o instanceof AbstractWidget w) {
                        w.visible = false;
                        w.active = false;
                    }
                }
            }
        } catch (Throwable t) {
            LOG.error("Gagal membangun title screen vanilla", t);
        } finally {
            BedrockPauseClient.suppressFallback = false;
        }
    }

    private void add(AbstractWidget w, boolean slide) {
        addRenderableWidget(w);
        all.add(w);
        if (slide) {
            sliding.add(w);
            slidingBaseX.add(w.getX());
        }
    }

    private void go(Supplier<Screen> target) {
        if (phase == Phase.EXIT) return;
        pendingTarget = target;
        switchNow = false;
        startPhase(Phase.EXIT);
    }

    private void startPhase(Phase p) {
        phase = p;
        phaseStart = System.currentTimeMillis();
    }

    private void updateAnimation() {
        long el = System.currentTimeMillis() - phaseStart;
        switch (phase) {
            case ENTER -> {
                float p = BpConfig.animations ? Math.min(1f, el / (float) ENTER_MS) : 1f;
                float q = 1f - p;
                float e = 1f - q * q * q;
                animAlpha = e;
                animOffset = -(1f - e) * SLIDE;
                if (p >= 1f) phase = Phase.IDLE;
            }
            case IDLE -> {
                animAlpha = 1f;
                animOffset = 0f;
            }
            case EXIT -> {
                float p = BpConfig.animations ? Math.min(1f, el / (float) EXIT_MS) : 1f;
                animAlpha = 1f - p;
                animOffset = -p * SLIDE;
                if (p >= 1f && pendingTarget != null) switchNow = true;
            }
        }
        int off = Math.round(animOffset);
        for (int i = 0; i < sliding.size(); i++) {
            sliding.get(i).setX(slidingBaseX.get(i) + off);
        }
        for (AbstractWidget w : all) w.setAlpha(animAlpha);
    }

    @Override
    public void tick() {
        super.tick();
        vanilla.tick();
        if (switchNow) {
            switchNow = false;
            Supplier<Screen> t = pendingTarget;
            pendingTarget = null;
            Screen next = t == null ? null : t.get();
            if (next == null) {
                startPhase(Phase.ENTER); // gagal membuka -> munculkan lagi
            } else {
                Transition.show(minecraft, next);
            }
        }
    }

    @Override
    public void removed() {
        super.removed();
        vanilla.removed();
    }

    private static void fillA(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int alpha, int rgb) {
        if (alpha <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(alpha, 255) << 24) | (rgb & 0xFFFFFF));
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // dikosongkan: latar digambar oleh TitleScreen vanilla di extractRenderState
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        updateAnimation();
        vanilla.extractRenderState(g, mx, my, a); // panorama + logo + splash + teks versi

        if (nameTag != null) {
            fillA(g, nameTag.getX() - 4, nameTag.getY() - 2, nameTag.getX() + nameTag.getWidth() + 4,
                    nameTag.getY() + nameTag.getHeight() + 2, (int) (0x70 * animAlpha), 0x000000);
        }
        super.extractRenderState(g, mx, my, a); // tombol kita

        boolean overButton = false;
        for (AbstractWidget w : all) {
            if (!(w instanceof Button)) continue;
            if (mx >= w.getX() && mx < w.getX() + w.getWidth() && my >= w.getY() && my < w.getY() + w.getHeight()) {
                overButton = true;
                break;
            }
        }
        skin.render(g, skinCx, height, mx, my, overButton, animAlpha);
    }
}
