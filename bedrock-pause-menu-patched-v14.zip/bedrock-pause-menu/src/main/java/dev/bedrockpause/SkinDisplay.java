package dev.bedrockpause;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Model skin pemain: mengikuti kursor dengan halus, tapi kursor/sentuhan di atas tombol diabaikan
 * (supaya model tidak "melompat" saat tombol ditekan). Dipakai di title screen.
 */
final class SkinDisplay {
    private float lookX;
    private float lookY;
    private float targetX;
    private float targetY;
    private boolean ready;
    private long last;

    void render(GuiGraphicsExtractor g, int cx, int height, int mx, int my, boolean overButton, float alpha) {
        long now = System.currentTimeMillis();
        if (!ready) {
            ready = true;
            lookX = targetX = cx - 30;
            lookY = targetY = height * 0.34f;
            last = now;
        }
        float dt = Math.min(0.1f, (now - last) / 1000f);
        last = now;
        if (!overButton) {
            targetX = mx;
            targetY = my;
        }
        float k = 1f - (float) Math.exp(-dt * 8f);
        lookX += (targetX - lookX) * k;
        lookY += (targetY - lookY) * k;
        if (!BpConfig.skinDisplay || alpha <= 0.05f) return;
        int half = (int) (height * 0.14f);
        ExtraRender.player(g, cx - half, (int) (height * 0.24f), cx + half, (int) (height * 0.74f),
                (int) (height * 0.22f), Math.round(lookX), Math.round(lookY));
    }
}
