package dev.bedrockpause;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Layar konfigurasi (Cloth Config). Dipisah supaya Cloth Config tidak wajib terpasang. */
final class BpClothScreen {
    private BpClothScreen() {}

    static Screen create(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.literal("Bedrock UI"))
                .setSavingRunnable(BpConfig::save);
        ConfigEntryBuilder eb = builder.entryBuilder();

        ConfigCategory general = builder.getOrCreateCategory(Component.literal("Menu"));
        general.addEntry(eb.startBooleanToggle(Component.literal("Pause menu ala Bedrock"), BpConfig.bedrockPauseMenu)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Ganti menu pause bawaan dengan versi Bedrock."))
                .setSaveConsumer(v -> BpConfig.bedrockPauseMenu = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Title screen ala Bedrock"), BpConfig.bedrockTitleScreen)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Ganti menu utama bawaan dengan versi Bedrock. Berlaku setelah kembali ke menu utama."))
                .setSaveConsumer(v -> BpConfig.bedrockTitleScreen = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Animasi slide/fade"), BpConfig.animations)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Matikan untuk membuka/menutup menu tanpa animasi."))
                .setSaveConsumer(v -> BpConfig.animations = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Tampilkan skin pemain"), BpConfig.skinDisplay)
                .setDefaultValue(true)
                .setTooltip(Component.literal("Model skin di sisi kanan pause menu dan title screen."))
                .setSaveConsumer(v -> BpConfig.skinDisplay = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Tombol ikon tambahan (pause menu)"), BpConfig.showExtraButtons)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Report Bugs, Feedback, Report Player, dan Friends."))
                .setSaveConsumer(v -> BpConfig.showExtraButtons = v)
                .build());

        ConfigCategory gui = builder.getOrCreateCategory(Component.literal("GUI"));
        gui.addEntry(eb.startBooleanToggle(Component.literal("Sembunyikan Edition Branding"), BpConfig.hideEditionBranding)
                .setDefaultValue(false)
                .setTooltip(Component.literal("Sembunyikan tulisan \"Java Edition\" di bawah logo Minecraft."))
                .setSaveConsumer(v -> BpConfig.hideEditionBranding = v)
                .build());

        return builder.build();
    }
}
