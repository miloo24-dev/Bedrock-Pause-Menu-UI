package dev.bedrockpause;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;

/** Animasi masuk (fade in + slide ke kanan) untuk layar tujuan, mis. Options / Mods / Accessibility. */
public final class Transition {
    private static final long ENTER_MS = 220L;
    private static final float SLIDE = 36f;

    private static boolean armed;
    private static Screen active;
    private static long start;
    private static boolean pushed;
    private static Screen registered;

    private Transition() {}

    /** Semua perpindahan layar dari pause menu lewat sini. */
    public static void show(Minecraft mc, Screen screen) {
        armed = true;
        try {
            mc.setScreenAndShow(screen); // 26.1: ganti jadi mc.setScreen(screen)
        } finally {
            armed = false;
        }
    }

    static void onScreenInit(Screen screen) {
        if (screen instanceof BedrockPauseScreen) return; // pause menu animasi sendiri
        if (armed) {
            armed = false;
            active = screen;
            start = System.currentTimeMillis();
        }
        if (screen != active || registered == screen) return;
        registered = screen;
        ScreenEvents.beforeExtract(screen).register((s, g, mx, my, td) -> before(s, g));
        ScreenEvents.afterExtract(screen).register((s, g, mx, my, td) -> after(g));
    }

    private static void before(Screen s, GuiGraphicsExtractor g) {
        if (s != active) return;
        float p = Math.min(1f, (System.currentTimeMillis() - start) / (float) ENTER_MS);
        float q = 1f - p;
        float e = 1f - q * q * q; // ease-out
        for (var child : s.children()) {
            if (child instanceof AbstractWidget w) w.setAlpha(e);
        }
        g.pose().pushMatrix();
        g.pose().translate(-(1f - e) * SLIDE, 0f); // mulai dari kiri, geser ke kanan
        pushed = true;
        if (p >= 1f) active = null;
    }

    private static void after(GuiGraphicsExtractor g) {
        if (pushed) {
            pushed = false;
            g.pose().popMatrix();
        }
    }
}
