package dev.bedrockpause.mixin;

import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * PauseScreen vanilla tidak digambar sama sekali (mod ini menggantinya dengan BedrockPauseScreen),
 * jadi tidak ada kedipan menu vanilla di frame sebelum penggantian selesai.
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void bedrockpause$hideVanillaPause(CallbackInfo ci) {
        if (((Object) this).getClass() == PauseScreen.class) {
            ci.cancel();
        }
    }
}
