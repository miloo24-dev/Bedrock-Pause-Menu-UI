package dev.bedrockpause.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.bedrockpause.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Opsi "Sembunyikan Edition Branding": melewati gambar "Java Edition" di bawah logo (target sama dengan BedrockIfy). */
@Mixin(LogoRenderer.class)
public abstract class LogoRendererMixin {
    @Shadow
    @Final
    private static Identifier MINECRAFT_EDITION;

    @Redirect(
            method = "extractRenderState(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IFI)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIFFIIIII)V"),
            require = 0)
    private void bedrockpause$blit(GuiGraphicsExtractor g, RenderPipeline pipeline, Identifier id,
                                   int a, int b, float c, float d, int e, int f, int h, int i, int j) {
        if (id == MINECRAFT_EDITION && BpConfig.hideEditionBranding) return;
        g.blit(pipeline, id, a, b, c, d, e, f, h, i, j);
    }
}
