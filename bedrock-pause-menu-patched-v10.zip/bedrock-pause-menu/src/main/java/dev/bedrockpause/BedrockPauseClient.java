package dev.bedrockpause;

import dev.bedrockpause.mixin.PauseScreenAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BedrockPauseClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("bedrockpause");

    /** Cadangan: pause screen vanilla yang lolos, diganti pada akhir tick. */
    private static PauseScreen pending;

    /** Vanilla PauseScreen yang baru saja diganti langsung oleh BEFORE_INIT (agar AFTER_INIT mengabaikannya). */
    private static PauseScreen swappedFrom;

    /** True saat mod sendiri men-init PauseScreen vanilla (untuk meminjam tombolnya). */
    public static volatile boolean suppressFallback;

    @Override
    public void onInitializeClient() {
        LOG.info("Bedrock Pause Menu loaded");

        // Ganti SEBELUM layar vanilla sempat di-init/digambar -> tidak ada kedipan menu vanilla.
        ScreenEvents.BEFORE_INIT.register((client, screen, w, h) -> {
            if (suppressFallback || screen.getClass() != PauseScreen.class || !showsMenu(screen)) return;
            try {
                swappedFrom = (PauseScreen) screen;
                client.setScreenAndShow(new BedrockPauseScreen((PauseScreen) screen));
            } catch (Throwable t) {
                swappedFrom = null;
                LOG.error("Swap langsung gagal, pakai fallback tick", t);
                pending = (PauseScreen) screen;
            }
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            Transition.onScreenInit(screen);
            if (suppressFallback || screen.getClass() != PauseScreen.class) return;
            if (screen == swappedFrom) {
                swappedFrom = null;
                return;
            }
            if (showsMenu(screen)) {
                LOG.warn("Vanilla PauseScreen muncul (swap tidak jalan) -> pakai fallback");
                pending = (PauseScreen) screen;
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PauseScreen p = pending;
            pending = null;
            if (p != null) {
                client.setScreenAndShow(new BedrockPauseScreen(p));
            }
        });
    }

    private static boolean showsMenu(Screen screen) {
        try {
            return ((PauseScreenAccessor) (Object) screen).bedrockpause$showPauseMenu();
        } catch (Throwable t) {
            LOG.warn("Accessor showPauseMenu gagal: {}", t.toString());
            return true;
        }
    }
}
