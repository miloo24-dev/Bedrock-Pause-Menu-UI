package dev.bedrockui;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;

/** Enter animation (fade in + slide right) for destination screens, e.g. Options / Mods / Accessibility. */
public final class Transition {
    private static final long ENTER_MS = 300L;
    private static final float SLIDE = 44f;

    private static boolean armed;
    private static Screen active;
    private static long start;
    private static boolean pushed;
    private static int dim;
    private static int dimW;
    private static int dimH;
    private static Screen registered;

    private Transition() {}

    /** All screen changes from the pause menu go through here. */
    public static void show(Minecraft mc, Screen screen) {
        armed = true;
        try {
            mc.setScreenAndShow(screen); // 26.1 and earlier: mc.setScreen(screen)
        } finally {
            armed = false;
        }
    }

    static void onScreenInit(Screen screen) {
        if (BedrockUiClient.suppressFallback) return; // hidden screens we only borrow widgets from
        if (screen instanceof BedrockPauseScreen || screen instanceof BedrockTitleScreen) return; // the pause menu animates itself
        if (armed) {
            armed = false;
            active = screen;
            start = System.currentTimeMillis();
        }
        if (screen != active || registered == screen) return;
        registered = screen;
        ScreenEvents.beforeExtract(screen).register((s, g, mx, my, td) -> before(s, g));
        ScreenEvents.afterExtract(screen).register((s, g, mx, my, td) -> after(g));
    }

    private static void before(Screen s, GuiGraphicsExtractor g) {
        if (s != active) return;
        float p = BpConfig.animations ? Math.min(1f, (System.currentTimeMillis() - start) / (float) ENTER_MS) : 1f;
        float q = 1f - p;
        float e = 1f - q * q * q * q; // ease-out quart
        for (var child : s.children()) {
            if (child instanceof AbstractWidget w) w.setAlpha(e);
        }
        g.pose().pushMatrix();
        g.pose().translate(-(1f - e) * SLIDE, 0f); // start on the left, slide to the right
        dim = 0;
        dimW = s.width;
        dimH = s.height;
        pushed = true;
        if (p >= 1f) active = null;
    }

    private static void after(GuiGraphicsExtractor g) {
        if (pushed) {
            pushed = false;
            g.pose().popMatrix();
            if (dim > 0) g.fill(0, 0, dimW, dimH, dim << 24); // soft dark veil that fades away
        }
    }
}
