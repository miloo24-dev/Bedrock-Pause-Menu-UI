package dev.bedrockui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.network.chat.Component;

/**
 * Bedrock-style button look, drawn over the vanilla button: light gray body with a thin dark outline and subtle shading,
 * dark text; on hover the button turns green with a white outline (it does not change size).
 */
final class BedrockButtons {
    private BedrockButtons() {}

    private static void rect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int rgb, int a) {
        if (a <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(a, 255) << 24) | rgb);
    }

    static void draw(GuiGraphicsExtractor g, Font font, AbstractWidget w, int mx, int my, float alpha) {
        draw(g, font, w, mx, my, alpha, 0);
    }

    /** style: 0 = light gray, 1 = primary green (white outline), 2 = purple. */
    static void draw(GuiGraphicsExtractor g, Font font, AbstractWidget w, int mx, int my, float alpha, int style) {
        int a = (int) (255 * Math.max(0f, Math.min(1f, alpha)));
        if (a <= 4) return;
        Component label = w.getMessage();
        int x = w.getX();
        int y = w.getY();
        int bw = w.getWidth();
        int bh = w.getHeight();
        boolean hover = w.active && mx >= x && mx < x + bw && my >= y && my < y + bh;

        if (hover) {
            // green body with a thin white outline inside the dark outline; the button keeps its size
            rect(g, x - 2, y - 2, x + bw + 2, y + bh + 2, 0x1B1B1C, a);
            rect(g, x - 1, y - 1, x + bw + 1, y + bh + 1, 0xFFFFFF, a);
            rect(g, x, y, x + bw, y + bh, 0x3C8527, a);
            rect(g, x, y, x + bw, y + 1, 0x58A83C, a);
            rect(g, x, y + bh - 3, x + bw, y + bh, 0x2B6420, a);
        } else {
            boolean on = w.active;
            rect(g, x - 2, y - 2, x + bw + 2, y + bh + 2, 0x1B1B1C, a);
            rect(g, x, y, x + bw, y + bh, on ? 0xC9CACD : 0x8E8E90, a);
            rect(g, x, y, x + bw, y + 1, on ? 0xE9EAEC : 0x9C9C9E, a);
            rect(g, x, y + bh - 3, x + bw, y + bh, on ? 0x9A9B9F : 0x777779, a);
        }
        int text = hover ? 0xFFFFFF : (w.active ? 0x3A3A3C : 0x505050);

        if (label != null) {
            int tw = font.width(label);
            g.text(font, label, x + (bw - tw) / 2, y + (bh - 8) / 2, (a << 24) | text, false);
        }
    }
}
