package dev.bedrockui.mixin;

import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.screens.LoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/** Gray (instead of red) background for the game's own startup loading screen. */
@Mixin(LoadingOverlay.class)
public abstract class LoadingOverlayMixin {
    @ModifyArg(method = "extractRenderState",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphicsExtractor;fill(IIIII)V"),
            index = 4, require = 0)
    private int bedrockui$grayBackground(int color) {
        if (!BpConfig.graySplash || (color & 0xFFFFFF) == 0xFFFFFF) return color; // keep the white progress bar
        return (color & 0xFF000000) | 0x1E1E1E;
    }
}
