package dev.bedrockui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

/**
 * Bedrock-style settings screen: light header with a back arrow, a tab sidebar with icons on the left and a
 * scrollable list of options on the right (Bedrock-style sliders and switches). Only options that exist in Java
 * Edition are listed. Option widgets come from the game's own OptionInstances; extra vanilla buttons are borrowed
 * from a hidden vanilla OptionsScreen. The Resource Packs tab opens a full "Global Resources" view.
 */
public class BedrockSettingsScreen extends Screen {
    private static final Logger LOG = BedrockUiClient.LOG;

    /** Hidden vanilla OptionsScreen -> the screen the settings were opened from. */
    static final Map<Screen, Screen> REAL_PARENT = new WeakHashMap<>();

    private enum Kind { BUTTON, TOGGLE, SLIDER, INFO, HEADING, GROUP }

    private static final class Row {
        final Kind kind;
        final String label;
        final String desc;
        final AbstractWidget widget;
        final BooleanSupplier state;
        final DoubleSupplier value;
        final int icon;
        final String group;
        int y;

        Row(Kind kind, String label, String desc, AbstractWidget widget, BooleanSupplier state, DoubleSupplier value, int icon, String group) {
            this.kind = kind;
            this.label = label;
            this.desc = desc;
            this.widget = widget;
            this.state = state;
            this.value = value;
            this.icon = icon;
            this.group = group;
        }

        int height() {
            return switch (kind) {
                case HEADING -> 22;
                case GROUP -> 36;
                case SLIDER -> 50;
                default -> icon != 0 ? 40 : 34;
            };
        }
    }

    private static final String[] TABS = {"Accessibility", "Keyboard & Mouse", "General", "Video", "Audio",
            "Resource Packs", "Shader", "Mods"};
    private static final String[] SUB = {
            "Minecraft is for everyone, including you", "Key binds and mouse settings",
            "Language, skin and game options", "Graphics, render distance and performance",
            "Music, sound effects and voices", "Choose which packs are active", "Shader packs", "Installed mods"};
    private static final int ACCESS = 0, CONTROLS = 1, GENERAL = 2, VIDEO = 3, AUDIO = 4, PACKS = 5, SHADER = 6, MODS = 7;
    private static final long ENTER_MS = 320L;
    private static final long PANE_MS = 260L;
    private static final int PANE_BG = 0xFF454547;

    private final Screen parent;
    private final List<Row> borrowed = new ArrayList<>();
    private final List<Row> rows = new ArrayList<>();
    private final List<AbstractWidget> pane = new ArrayList<>();
    private final List<Button> side = new ArrayList<>();
    private final Map<Row, long[]> switchAnim = new HashMap<>();
    private final Map<String, Boolean> groupOpen = new HashMap<>();
    private final boolean iris = FabricLoader.getInstance().isModLoaded("iris");
    private boolean packsDirty;
    private boolean packsMode;
    private int selected = GENERAL;
    private int headerH = 24;
    private int sideW;
    private int tabH = 24;
    private int paneTop;
    private int paneLeft;
    private int paneW;
    private int totalH;
    private float scroll;
    private float shownScroll;
    private int lastMy = -1;
    private boolean wasDown;
    private boolean dragging;
    private long enterStart = System.currentTimeMillis();
    private long paneStart = System.currentTimeMillis();
    private Button back;

    public BedrockSettingsScreen(Screen parent) {
        super(Component.literal("Settings"));
        this.parent = parent;
    }

    /** The screen a vanilla OptionsScreen was opened from. */
    static Screen parentOf(Screen options) {
        Screen p = REAL_PARENT.get(options);
        if (p != null) return p;
        try {
            for (Class<?> c = options.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (Screen.class.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true);
                        Object v = f.get(options);
                        if (v instanceof Screen s && s != options) return s;
                    }
                }
            }
        } catch (Throwable t) {
            LOG.warn("Could not find the parent of the options screen: {}", t.toString());
        }
        return null;
    }

    @Override
    public void onClose() {
        if (packsMode) {
            packsMode = false;
            selected = GENERAL;
            scroll = 0;
            paneStart = System.currentTimeMillis();
            buildPane();
            return;
        }
        try {
            if (packsDirty) {
                Object repo = call(minecraft, "getResourcePackRepository");
                call(minecraft.options, "updateResourcePacks", repo);
                call(minecraft, "reloadResourcePacks");
            }
            call(minecraft.options, "save");
        } catch (Throwable t) {
            LOG.warn("Could not apply the settings: {}", t.toString());
        }
        minecraft.setScreenAndShow(parent == null && minecraft.level == null ? new TitleScreen() : parent);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // intentionally empty: everything is drawn in extractRenderState
    }

    /** Mouse wheel scrolling (no @Override on purpose: the signature differs between versions). */
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scroll -= (float) sy * 24f;
        clampScroll();
        return true;
    }

    private void clampScroll() {
        float max = Math.max(0, totalH - (height - paneTop - 6));
        scroll = Math.max(0f, Math.min(max, scroll));
    }

    // ---------- reflection helpers ----------

    private static Object call(Object target, String name, Object... args) {
        if (target == null) return null;
        try {
            for (Method m : target.getClass().getMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                try {
                    m.setAccessible(true);
                    return m.invoke(target, args);
                } catch (IllegalArgumentException ignored) {
                    // try the next overload
                }
            }
        } catch (Throwable t) {
            LOG.debug("call {} failed: {}", name, t.toString());
        }
        return null;
    }

    private Object opt(String... names) {
        for (String n : names) {
            Object o = call(minecraft.options, n);
            if (o != null && o.getClass().getSimpleName().equals("OptionInstance")) return o;
        }
        return null;
    }

    private static double readValue(AbstractWidget w) {
        try {
            for (Class<?> c = w.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                try {
                    Field f = c.getDeclaredField("value");
                    if (f.getType() == double.class) {
                        f.setAccessible(true);
                        return f.getDouble(w);
                    }
                } catch (NoSuchFieldException ignored) {
                    // look in the superclass
                }
            }
        } catch (Throwable ignored) {
            // fall through
        }
        return -1.0;
    }

    private AbstractWidget optionWidget(Object option) {
        if (option == null) return null;
        try {
            for (Method m : option.getClass().getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (m.getName().equals("createButton") && t.length == 4 && t[0].isInstance(minecraft.options)) {
                    Object w = m.invoke(option, minecraft.options, 0, 0, 150);
                    if (w instanceof AbstractWidget aw) return aw;
                }
            }
        } catch (Throwable t) {
            LOG.debug("createButton failed: {}", t.toString());
        }
        return null;
    }

    // ---------- row builders ----------

    private static Row mk(Kind k, String label, String desc, AbstractWidget w, BooleanSupplier s, DoubleSupplier v, int icon) {
        return new Row(k, label, desc, w, s, v, icon, null);
    }

    private Row slider(String label, String desc, Object option) {
        AbstractWidget w = optionWidget(option);
        if (w == null) return null;
        if (readValue(w) < 0) return mk(Kind.BUTTON, label, desc, w, null, null, 0);
        return mk(Kind.SLIDER, label, desc, w, null, () -> readValue(w), 0);
    }

    private Row cycle(String label, String desc, Object option) {
        AbstractWidget w = optionWidget(option);
        return w == null ? null : mk(Kind.BUTTON, label, desc, w, null, null, 0);
    }

    private Row toggleOpt(String label, String desc, Object option) {
        if (option == null) return null;
        BooleanSupplier state = () -> Boolean.TRUE.equals(call(option, "get"));
        Button b = Button.builder(Component.literal(""), btn -> call(option, "set", !state.getAsBoolean())).bounds(0, 0, 38, 18).build();
        return mk(Kind.TOGGLE, label, desc, b, state, null, 0);
    }

    private Row action(String label, String desc, String text, Runnable run, int icon) {
        Button b = Button.builder(Component.literal(text), btn -> run.run()).bounds(0, 0, 100, 20).build();
        return mk(Kind.BUTTON, label, desc, b, null, null, icon);
    }

    private Row info(String label, String desc, int icon) {
        return mk(Kind.INFO, label, desc, null, null, null, icon);
    }

    private static void add(List<Row> rows, Row r) {
        if (r != null) rows.add(r);
    }

    private static String text(AbstractWidget w) {
        return (String.valueOf(w.getMessage().getContents()) + " " + w.getMessage().getString()).toLowerCase();
    }

    private static String describe(String t) {
        if (t.contains("video")) return "More graphics settings";
        if (t.contains("sound") || t.contains("music")) return "More audio settings";
        if (t.contains("control")) return "Key binds";
        if (t.contains("language")) return "Change the language of the game";
        if (t.contains("skin")) return "Choose which parts of your skin are shown";
        if (t.contains("accessib")) return "Make Minecraft easier to use";
        if (t.contains("chat")) return "Chat visibility, colors and size";
        if (t.contains("difficulty")) return "How hard the game is";
        if (t.contains("online")) return "Online options";
        if (t.contains("telemetry")) return "Data sharing options";
        return "";
    }

    private static int tabOf(String t) {
        if (t.contains("accessib") || t.contains("chat")) return ACCESS;
        if (t.contains("control") || t.contains("keybind")) return CONTROLS;
        if (t.contains("video")) return VIDEO;
        if (t.contains("sound") || t.contains("music")) return AUDIO;
        if (t.contains("resourcepack") || t.contains("resource pack") || t.contains("fov") || t.contains("field of view")) return -1;
        return GENERAL;
    }

    private void borrowVanillaOptions() {
        borrowed.clear();
        BedrockUiClient.suppressFallback = true;
        try {
            OptionsScreen tmp = new OptionsScreen(this, minecraft.options, false);
            REAL_PARENT.put(tmp, parent);
            callInit(tmp, minecraft, width, height);
            for (Object o : tmp.children()) {
                if (o instanceof AbstractWidget w && !(w instanceof StringWidget) && w.getWidth() >= 50) {
                    String t = text(w);
                    if (t.contains("done") || tabOf(t) < 0) continue;
                    borrowed.add(mk(Kind.BUTTON, w.getMessage().getString(), describe(t), w, null, null, 0));
                }
            }
        } catch (Throwable t) {
            LOG.error("Could not borrow the vanilla option widgets", t);
        } finally {
            BedrockUiClient.suppressFallback = false;
        }
    }

    private static void callInit(Screen target, net.minecraft.client.Minecraft mc, int w, int h) throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(mc) && t[1] == int.class && t[2] == int.class) {
                m.invoke(target, mc, w, h);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(target, w, h);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    // ---------- rows per tab ----------

    private void addBorrowed(List<Row> list, int tab) {
        for (Row r : borrowed) if (tabOf(text(r.widget)) == tab) list.add(r);
    }

    private List<Row> rowsFor(int tab) {
        List<Row> list = new ArrayList<>();
        switch (tab) {
            case ACCESS -> {
                add(list, toggleOpt("Subtitles", "Show captions for sounds", opt("showSubtitles")));
                add(list, toggleOpt("High contrast", "Clearer menu and button outlines", opt("highContrast")));
                addBorrowed(list, ACCESS);
            }
            case CONTROLS -> {
                add(list, slider("Mouse sensitivity", "How fast the camera turns", opt("sensitivity", "mouseSensitivity")));
                add(list, toggleOpt("Invert mouse", "Invert the vertical camera movement", opt("invertMouse", "invertYMouse")));
                add(list, toggleOpt("Auto-jump", "Jump up blocks automatically", opt("autoJump")));
                add(list, toggleOpt("Toggle crouch", "Press once to crouch", opt("toggleCrouch")));
                add(list, toggleOpt("Toggle sprint", "Press once to sprint", opt("toggleSprint")));
                addBorrowed(list, CONTROLS);
            }
            case GENERAL -> addBorrowed(list, GENERAL);
            case VIDEO -> {
                add(list, slider("Render distance", "How far you can see", opt("renderDistance")));
                add(list, slider("Simulation distance", "How far the world is simulated", opt("simulationDistance")));
                add(list, slider("Max framerate", "Limit the frames per second", opt("framerateLimit")));
                add(list, slider("Brightness", "Make the game brighter or moodier", opt("gamma")));
                add(list, slider("Field of view", "How wide your view is", opt("fov")));
                add(list, slider("GUI scale", "Size of the menus and HUD", opt("guiScale")));
                add(list, cycle("Particles", "How many particles are shown", opt("particles")));
                add(list, cycle("Clouds", "Cloud quality", opt("cloudStatus")));
                add(list, toggleOpt("View bobbing", "Camera sway while walking", opt("bobView")));
                add(list, toggleOpt("VSync", "Sync the frame rate to your screen", opt("enableVsync")));
                add(list, toggleOpt("Entity shadows", "Shadows below creatures", opt("entityShadows")));
                addBorrowed(list, VIDEO); // also opens the video screen of installed video mods (e.g. Sodium)
            }
            case AUDIO -> {
                try {
                    Class<?> src = Class.forName("net.minecraft.sounds.SoundSource");
                    for (Object s : src.getEnumConstants()) {
                        String n = String.valueOf(call(s, "getName"));
                        String label = n.equals("master") ? "Master volume"
                                : Character.toUpperCase(n.charAt(0)) + n.substring(1) + " volume";
                        add(list, slider(label, "", call(minecraft.options, "getSoundSourceOptionInstance", s)));
                    }
                } catch (Throwable t) {
                    LOG.warn("Could not list the sound categories: {}", t.toString());
                }
                addBorrowed(list, AUDIO);
            }
            case PACKS -> packRows(list);
            case SHADER -> {
                if (iris) {
                    list.add(action("Shader packs", "Choose and configure shader packs", "Open", () -> {
                        Screen s = ScreenFactory.create("net.irisshaders.iris.gui.screen.ShaderPackScreen", this);
                        if (s != null) minecraft.setScreenAndShow(s);
                    }, 0));
                } else {
                    list.add(info("Please use Iris Shaders mod.", "Install Iris Shaders to use shader packs", 0));
                }
            }
            default -> modRows(list);
        }
        return list;
    }

    // ---------- mods (with their config screens) ----------

    private static Map<?, ?> modMenuFactories() {
        try {
            Class<?> c = Class.forName("com.terraformersmc.modmenu.ModMenu");
            Field f = c.getDeclaredField("CONFIG_SCREEN_FACTORIES");
            f.setAccessible(true);
            Object v = f.get(null);
            if (v instanceof Map<?, ?> m) return m;
        } catch (Throwable ignored) {
            // Mod Menu not installed or changed
        }
        return null;
    }

    private boolean hasConfig(String id) {
        if (id.equals("bedrockui")) return FabricLoader.getInstance().isModLoaded("cloth-config");
        Map<?, ?> f = modMenuFactories();
        return f != null && f.containsKey(id);
    }

    private void openConfig(String id) {
        try {
            Screen s;
            if (id.equals("bedrockui")) {
                s = BpClothScreen.create(this);
            } else {
                Map<?, ?> f = modMenuFactories();
                s = f == null ? null : (Screen) call(f.get(id), "create", this);
            }
            if (s != null) minecraft.setScreenAndShow(s);
        } catch (Throwable t) {
            LOG.warn("Could not open the config of {}: {}", id, t.toString());
        }
    }

    private void modRows(List<Row> list) {
        List<net.fabricmc.loader.api.ModContainer> mods = new ArrayList<>();
        for (var m : FabricLoader.getInstance().getAllMods()) {
            String id = m.getMetadata().getId();
            if (m.getContainingMod().isPresent() || id.equals("minecraft") || id.equals("java")) continue;
            mods.add(m);
        }
        mods.sort(Comparator.comparing(m -> m.getMetadata().getName().toLowerCase()));
        for (var m : mods) {
            final String id = m.getMetadata().getId();
            String name = m.getMetadata().getName();
            String ver = m.getMetadata().getVersion().getFriendlyString();
            if (hasConfig(id)) list.add(action(name, ver, "Configure", () -> openConfig(id), 0));
            else list.add(info(name, ver, 0));
        }
    }

    // ---------- resource packs ----------

    private static boolean isUserPack(Object p) {
        String id = String.valueOf(call(p, "getId"));
        Object t = call(p, "getTitle");
        String title = t instanceof Component c ? c.getString() : id;
        if (Boolean.TRUE.equals(call(p, "isRequired"))) return false;
        return !(id.equals("vanilla") || id.startsWith("mod/") || id.startsWith("fabric") || title.startsWith("Fabric Mod"));
    }

    private void packRows(List<Row> list) {
        try {
            Object repo = call(minecraft, "getResourcePackRepository");
            Collection<?> selectedPacks = (Collection<?>) call(repo, "getSelectedPacks");
            Collection<?> available = (Collection<?>) call(repo, "getAvailablePacks");
            List<String> ids = new ArrayList<>();
            for (Object p : selectedPacks) ids.add(String.valueOf(call(p, "getId")));

            List<Object> active = new ArrayList<>();
            for (Object p : selectedPacks) if (isUserPack(p)) active.add(p);
            List<Object> mine = new ArrayList<>();
            for (Object p : available) if (isUserPack(p) && !ids.contains(String.valueOf(call(p, "getId")))) mine.add(p);

            if (FabricLoader.getInstance().isModLoaded("respackopts")) {
                list.add(action("Pack options", "Change the settings of your resource packs", "Open", () -> openConfig("respackopts"), 0));
            }
            addGroup(list, "ACTIVE", active.size(), true);
            if (groupOpen.getOrDefault("ACTIVE", true)) {
                for (Object p : active) {
                    final String id = String.valueOf(call(p, "getId"));
                    list.add(action(packTitle(p), packDesc(p), "Remove", () -> setPack(repo, ids, id, false), packColor(id)));
                }
                if (active.isEmpty()) list.add(info("No active packs", "Activate a pack from My packs", 0));
            }
            addGroup(list, "MY PACKS", mine.size(), false);
            if (groupOpen.getOrDefault("MY PACKS", true)) {
                for (Object p : mine) {
                    final String id = String.valueOf(call(p, "getId"));
                    list.add(action(packTitle(p), packDesc(p), "Activate", () -> setPack(repo, ids, id, true), packColor(id)));
                }
                if (mine.isEmpty()) list.add(info("No packs found", "Put resource packs in your resourcepacks folder", 0));
            }
        } catch (Throwable t) {
            LOG.warn("Could not list the resource packs: {}", t.toString());
            list.add(info("Resource packs are unavailable.", t.toString(), 0));
        }
    }

    private void addGroup(List<Row> list, String name, int count, boolean defOpen) {
        Button b = Button.builder(Component.literal(""), btn -> {
            groupOpen.put(name, !groupOpen.getOrDefault(name, defOpen));
            buildPane();
        }).bounds(0, 0, 100, 28).build();
        list.add(new Row(Kind.GROUP, name, String.valueOf(count), b, () -> groupOpen.getOrDefault(name, defOpen), null, 0, name));
    }

    private static int packColor(String id) {
        int h = id.hashCode();
        int r = 90 + (h & 0x5F);
        int g = 90 + ((h >> 8) & 0x5F);
        int b = 90 + ((h >> 16) & 0x5F);
        return (r << 16) | (g << 8) | b;
    }

    private static String packTitle(Object pack) {
        Object t = call(pack, "getTitle");
        return t instanceof Component c ? c.getString() : String.valueOf(call(pack, "getId"));
    }

    private static String packDesc(Object pack) {
        Object d = call(pack, "getDescription");
        String s = d instanceof Component c ? c.getString().replace('\n', ' ') : "";
        return s.length() > 60 ? s.substring(0, 57) + "..." : s;
    }

    private void setPack(Object repo, List<String> ids, String id, boolean on) {
        List<String> next = new ArrayList<>(ids);
        if (on) next.add(id);
        else next.remove(id);
        call(repo, "setSelected", next);
        packsDirty = true;
        buildPane();
    }

    // ---------- layout ----------

    @Override
    protected void init() {
        side.clear();
        sideW = Math.max(120, (int) (width * 0.30f));
        borrowVanillaOptions();

        back = Button.builder(Component.literal(""), b -> onClose()).bounds(2, 2, 28, 20).build();
        addRenderableWidget(back);

        boolean headings = height >= 300;
        int avail = height - headerH - 12 - (headings ? 28 : 0);
        tabH = Math.max(18, Math.min(26, avail / TABS.length));
        int y = headerH + 8;
        for (int i = 0; i < TABS.length; i++) {
            if (headings && (i == CONTROLS || i == GENERAL)) y += 14;
            final int idx = i;
            Button b = Button.builder(Component.literal(""), btn -> {
                if (packsMode) return;
                selected = idx;
                packsMode = idx == PACKS;
                scroll = 0;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(0, y, sideW, tabH).build();
            side.add(b);
            addRenderableWidget(b);
            y += tabH + 2;
        }
        buildPane();
    }

    private void buildPane() {
        for (AbstractWidget w : pane) removeWidget(w);
        pane.clear();
        rows.clear();
        rows.addAll(rowsFor(selected));
        for (Button b : side) b.visible = !packsMode;

        paneTop = packsMode ? headerH + 10 : headerH + 8 + 30;
        paneLeft = packsMode ? Math.max(16, width / 10) : sideW + 12;
        paneW = packsMode ? width - 2 * paneLeft : width - paneLeft - 12;
        int ww = Math.min(150, Math.max(100, paneW / 3));
        totalH = 0;
        for (Row r : rows) {
            totalH += r.height();
            if (r.widget == null) continue;
            if (r.kind == Kind.SLIDER) r.widget.setWidth(paneW);
            else if (r.kind == Kind.GROUP) r.widget.setWidth(paneW);
            else if (r.kind == Kind.BUTTON) r.widget.setWidth(ww);
            addRenderableWidget(r.widget);
            pane.add(r.widget);
        }
        clampScroll();
    }

    private static float ease(long start, long ms) {
        if (!BpConfig.animations) return 1f;
        float p = Math.min(1f, (System.currentTimeMillis() - start) / (float) ms);
        float q = 1f - p;
        return 1f - q * q * q * q;
    }

    private static int argb(float alpha, int rgb) {
        return ((int) (255 * Math.max(0f, Math.min(1f, alpha))) << 24) | (rgb & 0xFFFFFF);
    }

    private boolean overWidget(int mx, int my) {
        for (Row r : rows) {
            AbstractWidget w = r.widget;
            if (w != null && w.visible && mx >= w.getX() && mx < w.getX() + w.getWidth() && my >= w.getY() && my < w.getY() + w.getHeight()) return true;
        }
        return false;
    }

    // ---------- rendering ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        float en = ease(enterStart, ENTER_MS);
        float pe = ease(paneStart, PANE_MS);
        int sideOff = packsMode ? -sideW : -(int) ((1f - en) * sideW);
        int slide = (int) ((1f - pe) * 18f);

        // drag scrolling: dragging on the labels (not on a control) scrolls the list
        boolean down = Boolean.TRUE.equals(call(minecraft.mouseHandler, "isLeftPressed"));
        if (down && !wasDown) {
            dragging = mx > (packsMode ? 0 : sideW) && my > paneTop && !overWidget(mx, my);
            lastMy = my;
        }
        if (down && dragging && lastMy >= 0) {
            scroll -= (my - lastMy);
            lastMy = my;
            clampScroll();
        }
        if (!down) dragging = false;
        wasDown = down;
        shownScroll += (scroll - shownScroll) * 0.35f;
        if (Math.abs(scroll - shownScroll) < 0.4f) shownScroll = scroll;

        g.fill(0, 0, width, height, PANE_BG);

        // rows: labels, descriptions, separators; widgets are positioned here and drawn by super
        int y = paneTop - Math.round(shownScroll);
        int px = paneLeft + slide;
        int right = paneLeft + paneW + slide;
        for (Row r : rows) {
            int h = r.height();
            r.y = y;
            boolean vis = y + h > paneTop && y < height;
            AbstractWidget w = r.widget;
            if (w != null) {
                w.visible = vis;
                if (r.kind == Kind.SLIDER) {
                    w.setX(px);
                    w.setY(y + 26);
                } else if (r.kind == Kind.GROUP) {
                    w.setX(px);
                    w.setY(y + 4);
                } else {
                    w.setX(right - w.getWidth() - (r.kind == Kind.TOGGLE || packsMode ? 0 : 0));
                    w.setY(y + (h - w.getHeight()) / 2);
                }
                w.setAlpha(pe);
            }
            if (vis && r.kind != Kind.GROUP) {
                if (r.kind == Kind.HEADING) {
                    g.text(font, Component.literal(r.label.toUpperCase()).withStyle(ChatFormatting.BOLD), px, y + 8, argb(pe, 0xB5B5B8), false);
                } else {
                    boolean hover = mx >= paneLeft - 8 && my >= y && my < y + h && my > paneTop;
                    if (hover && r.kind != Kind.SLIDER) g.fill(paneLeft - 8, y, width - 4, y + h - 1, argb(pe * 0.5f, 0x5A5A5E));
                    int tx = px + (r.icon != 0 ? 24 : 0);
                    boolean hasDesc = !r.desc.isEmpty();
                    g.text(font, Component.literal(r.label), tx, y + (hasDesc ? 6 : (h - 8) / 2), argb(pe, 0xFFFFFF), false);
                    if (hasDesc) g.text(font, Component.literal(r.desc), tx, y + 17, argb(pe, 0xB5B5B8), false);
                    if (r.icon != 0) drawPackIcon(g, px, y + (h - 18) / 2, r.icon);
                    g.fill(paneLeft - 8, y + h - 1, width - 4, y + h, argb(pe, 0x5E5E61));
                }
            }
            y += h;
        }
        if (rows.isEmpty()) {
            g.text(font, Component.literal("Nothing to show here."), px, paneTop + 8, argb(pe, 0xB5B5B8), false);
        }

        super.extractRenderState(g, mx, my, a);

        // Bedrock-style controls drawn over the vanilla widgets
        for (Row r : rows) {
            AbstractWidget w = r.widget;
            if (w == null || !w.visible) continue;
            switch (r.kind) {
                case BUTTON -> BedrockButtons.draw(g, font, w, mx, my, pe);
                case TOGGLE -> drawSwitch(g, r, w, r.state.getAsBoolean(), pe);
                case SLIDER -> drawSlider(g, w, Math.max(0.0, Math.min(1.0, r.value.getAsDouble())), mx, my, pe);
                case GROUP -> drawGroup(g, r, w, mx, my, pe);
                default -> { }
            }
            if (r.kind == Kind.SLIDER) {
                String m = w.getMessage().getString();
                int c = m.lastIndexOf(':');
                String v = c >= 0 ? m.substring(c + 1).trim() : m;
                g.text(font, Component.literal(v), right - font.width(v), w.getY() - 20, argb(pe, 0xFFFFFF), false);
            }
        }

        // header, category title and sidebar are drawn last so scrolled content never shows through them
        g.fill(0, 0, width, headerH, 0xFFE9EAEC);
        g.fill(0, headerH, width, headerH + 2, 0xFF8D8E91);
        Component title = Component.literal(packsMode ? "Global Resources" : "SETTINGS").withStyle(packsMode ? ChatFormatting.RESET : ChatFormatting.BOLD);
        g.text(font, title, (width - font.width(title)) / 2, (headerH - 8) / 2, 0xFF1E1E1F, false);
        // back arrow (the button underneath handles the click)
        int bx = 8;
        int by = headerH / 2;
        g.fill(bx + 3, by - 5, bx + 5, by - 3, 0xFF1E1E1F);
        g.fill(bx + 2, by - 3, bx + 4, by - 1, 0xFF1E1E1F);
        g.fill(bx + 1, by - 1, bx + 3, by + 1, 0xFF1E1E1F);
        g.fill(bx + 2, by + 1, bx + 4, by + 3, 0xFF1E1E1F);
        g.fill(bx + 3, by + 3, bx + 5, by + 5, 0xFF1E1E1F);
        if (packsMode) {
            g.text(font, Component.literal("Settings"), bx + 12, (headerH - 8) / 2, 0xFF1E1E1F, false);
            back.setWidth(width / 4);
        } else {
            back.setWidth(28);
        }

        if (!packsMode) {
            g.fill(0, headerH + 2, width, headerH + 2, 0);
            int ty = headerH + 10;
            Component ct = Component.literal(TABS[selected].toUpperCase()).withStyle(ChatFormatting.BOLD);
            g.fill(paneLeft - 8, headerH + 2, width, paneTop - 1, PANE_BG);
            g.text(font, ct, px, ty, argb(pe, 0xFFFFFF), false);
            g.text(font, Component.literal(SUB[selected]), px, ty + 11, argb(pe, 0xB5B5B8), false);
            g.fill(paneLeft - 8, headerH + 34, width - 4, headerH + 35, 0xFF5E5E61);

            g.fill(sideOff, headerH + 2, sideOff + sideW, height, 0xFF2D2D2F);
            for (Button b : side) b.setX(sideOff);
            for (int i = 0; i < side.size(); i++) {
                Button b = side.get(i);
                int tyb = b.getY();
                boolean gray = i == SHADER && !iris;
                boolean hover = mx >= 0 && mx < sideW && my >= tyb && my < tyb + tabH;
                g.fill(sideOff, tyb, sideOff + sideW, tyb + tabH, i == selected ? 0xFF454547 : hover ? 0xFF38383A : 0xFF2D2D2F);
                if (i == selected) g.fill(sideOff, tyb, sideOff + 3, tyb + tabH, 0xFF3C8527);
                int size = tabH - 6;
                drawIcon(g, i, 8 + sideOff, tyb + 3, size, gray);
                g.text(font, Component.literal(TABS[i]), 8 + sideOff + size + 8, tyb + (tabH - 8) / 2, gray ? 0xFF7C7C80 : 0xFFFFFFFF, false);
                if (height >= 300) {
                    if (i == CONTROLS) g.text(font, Component.literal("Controls"), 8 + sideOff, tyb - 12, 0xFFA0A0A4, false);
                    if (i == GENERAL) g.text(font, Component.literal("General"), 8 + sideOff, tyb - 12, 0xFFA0A0A4, false);
                }
            }
        }

        // scroll bar
        int viewH = height - paneTop - 6;
        if (totalH > viewH) {
            int barH = Math.max(18, viewH * viewH / totalH);
            int barY = paneTop + (int) ((viewH - barH) * (shownScroll / Math.max(1f, totalH - viewH)));
            g.fill(width - 4, paneTop, width - 2, paneTop + viewH, 0x55000000);
            g.fill(width - 4, barY, width - 2, barY + barH, 0xFFB5B5B8);
        }
    }

    // ---------- Bedrock-style controls ----------

    private static float easeBack(float t) {
        float k = Math.min(1f, Math.max(0f, t)) - 1f;
        float c = 1.9f;
        return 1f + (c + 1f) * k * k * k + c * k * k;
    }

    /** Bedrock switch: the knob slides (with a small bounce) over a green "I" or gray "O" track. */
    private void drawSwitch(GuiGraphicsExtractor g, Row r, AbstractWidget w, boolean on, float alpha) {
        long now = System.currentTimeMillis();
        long[] st = switchAnim.computeIfAbsent(r, k -> new long[] {on ? 1 : 0, 0});
        if ((st[0] == 1) != on) {
            st[0] = on ? 1 : 0;
            st[1] = now;
        }
        float pos = on ? 1f : 0f;
        if (st[1] != 0 && BpConfig.animations) {
            float e = easeBack((now - st[1]) / 340f);
            pos = on ? e : 1f - e;
        }
        int x = w.getX();
        int y = w.getY();
        int half = 19;
        int h = 18;
        int a = (int) (255 * alpha);
        g.fill(x - 1, y - 1, x + half * 2 + 1, y + h + 1, (a << 24) | 0x1E1E1F);
        g.fill(x, y, x + half * 2, y + h, (a << 24) | (on ? 0x3C8527 : 0x5E5E61));
        if (on) g.text(font, Component.literal("I"), x + 6, y + 5, (a << 24) | 0xFFFFFF, false);
        else g.text(font, Component.literal("O"), x + half + 7, y + 5, (a << 24) | 0xC0C0C4, false);
        int kx = x + Math.round(pos * half);
        kx = Math.max(x - 2, Math.min(x + half + 2, kx));
        g.fill(kx - 1, y - 1, kx + half + 1, y + h + 1, (a << 24) | 0x1E1E1F);
        g.fill(kx, y, kx + half, y + h, (a << 24) | 0xE2E2E4);
        g.fill(kx, y + h - 3, kx + half, y + h, (a << 24) | 0xA9A9AC);
    }

    /** Bedrock slider: gray track with a green filled part and a light square handle. */
    private void drawSlider(GuiGraphicsExtractor g, AbstractWidget w, double v, int mx, int my, float alpha) {
        int x = w.getX();
        int w2 = w.getWidth();
        int top = w.getY();
        int cy = top + 10;
        int a = (int) (255 * alpha);
        // cover the vanilla slider completely
        g.fill(x - 2, top - 2, x + w2 + 2, top + 22, PANE_BG);
        int hw = 12;
        int hx = x + (int) ((w2 - hw) * v);
        boolean hover = mx >= x && mx < x + w2 && my >= top && my < top + 20;
        g.fill(x, cy - 2, x + w2, cy + 2, (a << 24) | 0x8E8E91);
        g.fill(x, cy - 2, hx + hw / 2, cy + 2, (a << 24) | 0x3C8527);
        g.fill(hx - 1, cy - 9, hx + hw + 1, cy + 9, (a << 24) | 0x1E1E1F);
        g.fill(hx, cy - 8, hx + hw, cy + 8, (a << 24) | (hover ? 0xFFFFFF : 0xD6D6D8));
        g.fill(hx, cy + 5, hx + hw, cy + 8, (a << 24) | 0x9A9A9E);
    }

    private void drawGroup(GuiGraphicsExtractor g, Row r, AbstractWidget w, int mx, int my, float alpha) {
        int x = w.getX();
        int y = w.getY();
        int ww = w.getWidth();
        int h = 28;
        int a = (int) (255 * alpha);
        boolean hover = mx >= x && mx < x + ww && my >= y && my < y + h;
        g.fill(x - 1, y - 1, x + ww + 1, y + h + 1, (a << 24) | 0x1E1E1F);
        g.fill(x, y, x + ww, y + h, (a << 24) | (hover ? 0xD8D8DA : 0xC6C6C8));
        g.fill(x, y + h - 2, x + ww, y + h, (a << 24) | 0x9A9A9E);
        g.text(font, Component.literal(r.label).withStyle(ChatFormatting.BOLD), x + 8, y + 10, (a << 24) | 0x3A3A3C, false);
        String n = r.desc;
        g.text(font, Component.literal(n), x + ww - 46 - font.width(n), y + 10, (a << 24) | 0x3A3A3C, false);
        int px = x + ww - 20;
        int py = y + h / 2;
        g.fill(px - 5, py - 1, px + 5, py + 1, (a << 24) | 0x3A3A3C);
        if (!r.state.getAsBoolean()) g.fill(px - 1, py - 5, px + 1, py + 5, (a << 24) | 0x3A3A3C);
    }

    private void drawPackIcon(GuiGraphicsExtractor g, int x, int y, int rgb) {
        g.fill(x - 1, y - 1, x + 19, y + 19, 0xFF1E1E1F);
        g.fill(x, y, x + 18, y + 18, 0xFF000000 | rgb);
        g.fill(x + 4, y + 4, x + 14, y + 14, 0x55FFFFFF);
        g.fill(x + 4, y + 4, x + 14, y + 6, 0xAAFFFFFF);
        g.fill(x + 8, y + 7, x + 10, y + 14, 0xAAFFFFFF);
    }

    // ---------- tab icons (drawn in a 16x16 space) ----------

    private void drawIcon(GuiGraphicsExtractor g, int idx, int x, int y, int size, boolean gray) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        float s = size / 16f;
        g.pose().scale(s, s);
        g.fill(-1, -1, 17, 17, 0xFF1E1E1F);
        switch (idx) {
            case ACCESS -> {
                g.fill(0, 0, 16, 16, 0xFF2D6CF0);
                g.fill(6, 2, 10, 5, 0xFFFFFFFF);
                g.fill(3, 6, 13, 8, 0xFFFFFFFF);
                g.fill(7, 8, 9, 11, 0xFFFFFFFF);
                g.fill(5, 11, 7, 14, 0xFFFFFFFF);
                g.fill(9, 11, 11, 14, 0xFFFFFFFF);
            }
            case CONTROLS -> {
                g.fill(0, 0, 16, 16, 0xFF6B6B6D);
                g.fill(4, 2, 12, 14, 0xFFC9C9CB);
                g.fill(4, 7, 12, 8, 0xFF6B6B6D);
                g.fill(7, 2, 9, 7, 0xFF6B6B6D);
            }
            case GENERAL -> {
                g.fill(0, 0, 16, 16, 0xFF3A2A1A);
                g.fill(5, 3, 11, 13, 0xFFE08A2E);
                g.fill(3, 5, 13, 11, 0xFFE08A2E);
                g.fill(7, 7, 9, 9, 0xFF3A2A1A);
            }
            case VIDEO -> {
                g.fill(0, 0, 16, 16, 0xFF5AA6F0);
                g.fill(0, 10, 16, 16, 0xFF4C9A3A);
                g.fill(3, 3, 8, 5, 0xFFFFFFFF);
            }
            case AUDIO -> {
                g.fill(0, 0, 16, 16, 0xFF8A3B2A);
                g.fill(3, 6, 6, 10, 0xFFFFFFFF);
                g.fill(6, 4, 8, 12, 0xFFFFFFFF);
                g.fill(10, 6, 11, 10, 0xFFFFFFFF);
                g.fill(12, 4, 13, 12, 0xFFFFFFFF);
            }
            case PACKS -> {
                g.fill(0, 0, 16, 16, 0xFF5B3A1A);
                g.fill(2, 5, 14, 13, 0xFFC98B3A);
                g.fill(2, 5, 14, 8, 0xFFE0A84E);
                g.fill(7, 8, 9, 10, 0xFF3A2A1A);
            }
            case SHADER -> {
                g.fill(0, 0, 16, 16, 0xFF2A2A4A);
                g.fill(5, 5, 11, 11, 0xFFF2C21A);
                g.fill(7, 2, 9, 4, 0xFFF2C21A);
                g.fill(7, 12, 9, 14, 0xFFF2C21A);
                g.fill(2, 7, 4, 9, 0xFFF2C21A);
                g.fill(12, 7, 14, 9, 0xFFF2C21A);
            }
            default -> {
                g.fill(0, 0, 16, 16, 0xFF4A4A4C);
                g.fill(3, 4, 13, 13, 0xFF9AA0A8);
                g.fill(3, 4, 13, 7, 0xFFC8CDD2);
                g.fill(11, 2, 14, 5, 0xFF2BC4AE);
            }
        }
        if (gray) g.fill(-1, -1, 17, 17, 0xA0454547);
        g.pose().popMatrix();
    }
}
