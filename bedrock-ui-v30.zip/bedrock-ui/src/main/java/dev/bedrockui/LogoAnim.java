package dev.bedrockui;

/** Minecraft logo animation on the title screen: it just slides in from above. */
public final class LogoAnim {
    /** True only while BedrockTitleScreen is drawing the vanilla TitleScreen. */
    public static volatile boolean active;
    private static volatile long start = System.currentTimeMillis();

    private LogoAnim() {}

    public static void restart() {
        start = System.currentTimeMillis();
    }

    /** Vertical logo offset (GUI units). */
    public static float offsetY() {
        if (!BpConfig.animations) return 0f;
        float p = Math.min(1f, (System.currentTimeMillis() - start) / 450f);
        float q = 1f - p;
        return -(q * q * q) * 24f;
    }
}
