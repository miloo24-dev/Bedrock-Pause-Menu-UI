package dev.bedrockui;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;

/**
 * Bedrock-style settings screen: light header with a back arrow, a tab sidebar with icons on the left and the
 * options of the selected tab on the right (Bedrock-style sliders and switches). Only options that exist in
 * Java Edition are listed. Option widgets come from the game's own OptionInstances; extra vanilla buttons
 * (Language, Skin, Controls...) are borrowed from a hidden vanilla OptionsScreen.
 */
public class BedrockSettingsScreen extends Screen {
    private static final Logger LOG = BedrockUiClient.LOG;

    /** Hidden vanilla OptionsScreen -> the screen the settings were opened from. */
    static final Map<Screen, Screen> REAL_PARENT = new WeakHashMap<>();

    private enum Kind { BUTTON, TOGGLE, SLIDER, INFO, HEADING }

    private static final class Row {
        final Kind kind;
        final String label;
        final String desc;
        final AbstractWidget widget;
        final BooleanSupplier state;
        final DoubleSupplier value;

        Row(Kind kind, String label, String desc, AbstractWidget widget, BooleanSupplier state, DoubleSupplier value) {
            this.kind = kind;
            this.label = label;
            this.desc = desc;
            this.widget = widget;
            this.state = state;
            this.value = value;
        }

        int height() {
            return switch (kind) {
                case HEADING -> 22;
                case SLIDER -> 50;
                default -> 34;
            };
        }
    }

    private static final String[] TABS = {"Accessibility", "Keyboard & Mouse", "General", "Video", "Audio",
            "Resource Packs", "Shader", "Mods", "Bedrock UI"};
    private static final String[] SUB = {
            "Minecraft is for everyone, including you", "Key binds and mouse settings",
            "Language, skin and game options", "Graphics, render distance and performance",
            "Music, sound effects and voices", "Choose which packs are active", "Shader packs",
            "Installed mods", "Settings for this mod"};
    private static final int ACCESS = 0, CONTROLS = 1, GENERAL = 2, VIDEO = 3, AUDIO = 4, PACKS = 5, SHADER = 6,
            MODS = 7, BUI = 8;
    private static final long ENTER_MS = 320L;
    private static final long PANE_MS = 260L;

    private final Screen parent;
    private final List<Row> borrowed = new ArrayList<>();
    private final List<Row> pageRows = new ArrayList<>();
    private final List<AbstractWidget> pane = new ArrayList<>();
    private final List<Button> side = new ArrayList<>();
    private final boolean iris = FabricLoader.getInstance().isModLoaded("iris");
    private boolean packsDirty;
    private Button prev;
    private Button next;
    private int selected = GENERAL;
    private int page;
    private int pages = 1;
    private int headerH = 24;
    private int sideW;
    private int tabH = 24;
    private int paneTop;
    private long enterStart = System.currentTimeMillis();
    private long paneStart = System.currentTimeMillis();

    public BedrockSettingsScreen(Screen parent) {
        super(Component.literal("Settings"));
        this.parent = parent;
    }

    /** The screen a vanilla OptionsScreen was opened from. */
    static Screen parentOf(Screen options) {
        Screen p = REAL_PARENT.get(options);
        if (p != null) return p;
        try {
            for (Class<?> c = options.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (Screen.class.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true);
                        Object v = f.get(options);
                        if (v instanceof Screen s && s != options) return s;
                    }
                }
            }
        } catch (Throwable t) {
            LOG.warn("Could not find the parent of the options screen: {}", t.toString());
        }
        return null;
    }

    @Override
    public void onClose() {
        try {
            if (packsDirty) {
                Object repo = call(minecraft, "getResourcePackRepository");
                call(minecraft.options, "updateResourcePacks", repo);
                call(minecraft, "reloadResourcePacks");
            }
            call(minecraft.options, "save");
        } catch (Throwable t) {
            LOG.warn("Could not apply the settings: {}", t.toString());
        }
        minecraft.setScreenAndShow(parent == null && minecraft.level == null ? new TitleScreen() : parent);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float a) {
        // intentionally empty: everything is drawn in extractRenderState
    }

    // ---------- reflection helpers ----------

    private static Object call(Object target, String name, Object... args) {
        if (target == null) return null;
        try {
            for (Method m : target.getClass().getMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                try {
                    m.setAccessible(true);
                    return m.invoke(target, args);
                } catch (IllegalArgumentException ignored) {
                    // try the next overload
                }
            }
        } catch (Throwable t) {
            LOG.debug("call {} failed: {}", name, t.toString());
        }
        return null;
    }

    private Object opt(String... names) {
        for (String n : names) {
            Object o = call(minecraft.options, n);
            if (o != null && o.getClass().getSimpleName().equals("OptionInstance")) return o;
        }
        return null;
    }

    private static double readValue(AbstractWidget w) {
        try {
            for (Class<?> c = w.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                try {
                    Field f = c.getDeclaredField("value");
                    if (f.getType() == double.class) {
                        f.setAccessible(true);
                        return f.getDouble(w);
                    }
                } catch (NoSuchFieldException ignored) {
                    // look in the superclass
                }
            }
        } catch (Throwable ignored) {
            // fall through
        }
        return -1.0;
    }

    private AbstractWidget optionWidget(Object option) {
        if (option == null) return null;
        try {
            for (Method m : option.getClass().getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (m.getName().equals("createButton") && t.length == 4 && t[0].isInstance(minecraft.options)) {
                    Object w = m.invoke(option, minecraft.options, 0, 0, 150);
                    if (w instanceof AbstractWidget aw) return aw;
                }
            }
        } catch (Throwable t) {
            LOG.debug("createButton failed: {}", t.toString());
        }
        return null;
    }

    // ---------- row builders ----------

    private Row slider(String label, String desc, Object option) {
        AbstractWidget w = optionWidget(option);
        if (w == null) return null;
        if (readValue(w) < 0) return new Row(Kind.BUTTON, label, desc, w, null, null);
        return new Row(Kind.SLIDER, label, desc, w, null, () -> readValue(w));
    }

    private Row cycle(String label, String desc, Object option) {
        AbstractWidget w = optionWidget(option);
        return w == null ? null : new Row(Kind.BUTTON, label, desc, w, null, null);
    }

    private Row toggleOpt(String label, String desc, Object option) {
        if (option == null) return null;
        BooleanSupplier state = () -> Boolean.TRUE.equals(call(option, "get"));
        return toggle(label, desc, state, () -> call(option, "set", !state.getAsBoolean()));
    }

    private Row toggle(String label, String desc, BooleanSupplier state, Runnable action) {
        Button b = Button.builder(Component.literal(""), btn -> action.run()).bounds(0, 0, 38, 18).build();
        return new Row(Kind.TOGGLE, label, desc, b, state, null);
    }

    private Row action(String label, String desc, String text, Runnable run) {
        Button b = Button.builder(Component.literal(text), btn -> run.run()).bounds(0, 0, 100, 20).build();
        return new Row(Kind.BUTTON, label, desc, b, null, null);
    }

    private static void add(List<Row> rows, Row r) {
        if (r != null) rows.add(r);
    }

    private static String text(AbstractWidget w) {
        return (String.valueOf(w.getMessage().getContents()) + " " + w.getMessage().getString()).toLowerCase();
    }

    private static String describe(String t) {
        if (t.contains("video")) return "More graphics settings";
        if (t.contains("sound") || t.contains("music")) return "More audio settings";
        if (t.contains("control")) return "Key binds";
        if (t.contains("language")) return "Change the language of the game";
        if (t.contains("skin")) return "Choose which parts of your skin are shown";
        if (t.contains("accessib")) return "Make Minecraft easier to use";
        if (t.contains("chat")) return "Chat visibility, colors and size";
        if (t.contains("difficulty")) return "How hard the game is";
        if (t.contains("online")) return "Online options";
        if (t.contains("telemetry")) return "Data sharing options";
        return "";
    }

    private static int tabOf(String t) {
        if (t.contains("accessib") || t.contains("chat")) return ACCESS;
        if (t.contains("control") || t.contains("keybind")) return CONTROLS;
        if (t.contains("video")) return VIDEO;
        if (t.contains("sound") || t.contains("music")) return AUDIO;
        if (t.contains("resourcepack") || t.contains("resource pack") || t.contains("fov") || t.contains("field of view")) return -1;
        return GENERAL;
    }

    private void borrowVanillaOptions() {
        borrowed.clear();
        BedrockUiClient.suppressFallback = true;
        try {
            OptionsScreen tmp = new OptionsScreen(this, minecraft.options, false);
            REAL_PARENT.put(tmp, parent);
            callInit(tmp, minecraft, width, height);
            for (Object o : tmp.children()) {
                if (o instanceof AbstractWidget w && !(w instanceof StringWidget) && w.getWidth() >= 50) {
                    String t = text(w);
                    if (t.contains("done") || tabOf(t) < 0) continue;
                    borrowed.add(new Row(Kind.BUTTON, w.getMessage().getString(), describe(t), w, null, null));
                }
            }
        } catch (Throwable t) {
            LOG.error("Could not borrow the vanilla option widgets", t);
        } finally {
            BedrockUiClient.suppressFallback = false;
        }
    }

    private static void callInit(Screen target, net.minecraft.client.Minecraft mc, int w, int h) throws Exception {
        for (Method m : Screen.class.getMethods()) {
            if (!m.getName().equals("init")) continue;
            Class<?>[] t = m.getParameterTypes();
            if (t.length == 3 && t[0].isInstance(mc) && t[1] == int.class && t[2] == int.class) {
                m.invoke(target, mc, w, h);
                return;
            }
            if (t.length == 2 && t[0] == int.class && t[1] == int.class) {
                m.invoke(target, w, h);
                return;
            }
        }
        throw new NoSuchMethodException("Screen.init");
    }

    // ---------- rows per tab ----------

    private void addBorrowed(List<Row> rows, int tab) {
        for (Row r : borrowed) if (tabOf(text(r.widget)) == tab) rows.add(r);
    }

    private List<Row> rowsFor(int tab) {
        List<Row> rows = new ArrayList<>();
        switch (tab) {
            case ACCESS -> {
                add(rows, toggleOpt("Subtitles", "Show captions for sounds", opt("showSubtitles")));
                add(rows, toggleOpt("High contrast", "Clearer menu and button outlines", opt("highContrast")));
                addBorrowed(rows, ACCESS);
            }
            case CONTROLS -> {
                add(rows, slider("Mouse sensitivity", "How fast the camera turns", opt("sensitivity", "mouseSensitivity")));
                add(rows, toggleOpt("Invert mouse", "Invert the vertical camera movement", opt("invertMouse", "invertYMouse")));
                add(rows, toggleOpt("Auto-jump", "Jump up blocks automatically", opt("autoJump")));
                add(rows, toggleOpt("Toggle crouch", "Press once to crouch", opt("toggleCrouch")));
                add(rows, toggleOpt("Toggle sprint", "Press once to sprint", opt("toggleSprint")));
                addBorrowed(rows, CONTROLS);
            }
            case GENERAL -> addBorrowed(rows, GENERAL);
            case VIDEO -> {
                add(rows, slider("Render distance", "How far you can see", opt("renderDistance")));
                add(rows, slider("Simulation distance", "How far the world is simulated", opt("simulationDistance")));
                add(rows, slider("Max framerate", "Limit the frames per second", opt("framerateLimit")));
                add(rows, slider("Brightness", "Make the game brighter or moodier", opt("gamma")));
                add(rows, slider("Field of view", "How wide your view is", opt("fov")));
                add(rows, slider("GUI scale", "Size of the menus and HUD", opt("guiScale")));
                add(rows, cycle("Particles", "How many particles are shown", opt("particles")));
                add(rows, cycle("Clouds", "Cloud quality", opt("cloudStatus")));
                add(rows, toggleOpt("View bobbing", "Camera sway while walking", opt("bobView")));
                add(rows, toggleOpt("VSync", "Sync the frame rate to your screen", opt("enableVsync")));
                add(rows, toggleOpt("Entity shadows", "Shadows below creatures", opt("entityShadows")));
                addBorrowed(rows, VIDEO); // also opens the video screen of the installed video mods (e.g. Sodium)
            }
            case AUDIO -> {
                try {
                    Class<?> src = Class.forName("net.minecraft.sounds.SoundSource");
                    for (Object s : src.getEnumConstants()) {
                        String n = String.valueOf(call(s, "getName"));
                        String label = n.equals("master") ? "Master volume"
                                : Character.toUpperCase(n.charAt(0)) + n.substring(1) + " volume";
                        add(rows, slider(label, "", call(minecraft.options, "getSoundSourceOptionInstance", s)));
                    }
                } catch (Throwable t) {
                    LOG.warn("Could not list the sound categories: {}", t.toString());
                }
                addBorrowed(rows, AUDIO);
            }
            case PACKS -> packRows(rows);
            case SHADER -> {
                if (iris) {
                    rows.add(action("Shader packs", "Choose and configure shader packs", "Open", () -> {
                        Screen s = ScreenFactory.create("net.irisshaders.iris.gui.screen.ShaderPackScreen", this);
                        if (s != null) minecraft.setScreenAndShow(s);
                    }));
                } else {
                    rows.add(new Row(Kind.INFO, "Please use Iris Shaders mod.", "Install Iris Shaders to use shader packs", null, null, null));
                }
            }
            case MODS -> {
                List<net.fabricmc.loader.api.ModContainer> mods = new ArrayList<>();
                for (var m : FabricLoader.getInstance().getAllMods()) {
                    String id = m.getMetadata().getId();
                    if (m.getContainingMod().isPresent() || id.equals("minecraft") || id.equals("java")) continue;
                    mods.add(m);
                }
                mods.sort(Comparator.comparing(m -> m.getMetadata().getName().toLowerCase()));
                for (var m : mods) {
                    rows.add(new Row(Kind.INFO, m.getMetadata().getName(), m.getMetadata().getVersion().getFriendlyString(), null, null, null));
                }
            }
            default -> uiRows(rows);
        }
        return rows;
    }

    private void uiRows(List<Row> rows) {
        rows.add(toggle("Pause menu style", "Bedrock-style pause menu", () -> BpConfig.bedrockPauseMenu, () -> { BpConfig.bedrockPauseMenu = !BpConfig.bedrockPauseMenu; BpConfig.save(); }));
        rows.add(toggle("Title screen style", "Bedrock-style main menu", () -> BpConfig.bedrockTitleScreen, () -> { BpConfig.bedrockTitleScreen = !BpConfig.bedrockTitleScreen; BpConfig.save(); }));
        rows.add(toggle("Settings style", "This settings screen", () -> BpConfig.bedrockSettings, () -> { BpConfig.bedrockSettings = !BpConfig.bedrockSettings; BpConfig.save(); }));
        rows.add(toggle("Bedrock buttons", "Light buttons that turn green on hover", () -> BpConfig.bedrockButtons, () -> { BpConfig.bedrockButtons = !BpConfig.bedrockButtons; BpConfig.save(); }));
        rows.add(toggle("Startup screen", "Bedrock-style loading screen when the game starts", () -> BpConfig.bedrockStartupScreen, () -> { BpConfig.bedrockStartupScreen = !BpConfig.bedrockStartupScreen; BpConfig.save(); }));
        rows.add(toggle("Animations", "Slide and fade animations", () -> BpConfig.animations, () -> { BpConfig.animations = !BpConfig.animations; BpConfig.save(); }));
        rows.add(toggle("Player skin", "Skin model in the menus", () -> BpConfig.skinDisplay, () -> { BpConfig.skinDisplay = !BpConfig.skinDisplay; BpConfig.save(); }));
        rows.add(toggle("Coordinates", "Show your position on screen", () -> BpConfig.showCoordinates, () -> { BpConfig.showCoordinates = !BpConfig.showCoordinates; BpConfig.save(); }));
        rows.add(toggle("FPS", "Show the frame rate on screen", () -> BpConfig.showFps, () -> { BpConfig.showFps = !BpConfig.showFps; BpConfig.save(); }));
        rows.add(toggle("Days played", "Show the days played in this world", () -> BpConfig.showDaysPlayed, () -> { BpConfig.showDaysPlayed = !BpConfig.showDaysPlayed; BpConfig.save(); }));
        rows.add(toggle("Fade HUD when idle", "Hotbar and bars become translucent", () -> BpConfig.hudFade, () -> { BpConfig.hudFade = !BpConfig.hudFade; BpConfig.save(); }));
        rows.add(action("HUD fade delay", "Seconds without activity", BpConfig.hudFadeSeconds + " s", () -> {
            int[] v = {3, 5, 10, 15, 30};
            BpConfig.hudFadeSeconds = v[(indexOf(v, BpConfig.hudFadeSeconds) + 1) % v.length];
            BpConfig.save();
            refreshPane();
        }));
        rows.add(action("HUD faded opacity", "How visible the faded HUD is", BpConfig.hudOpacity + "%", () -> {
            int[] v = {25, 50, 75, 100};
            BpConfig.hudOpacity = v[(indexOf(v, BpConfig.hudOpacity) + 1) % v.length];
            BpConfig.save();
            refreshPane();
        }));
        rows.add(action("HUD height", "Raise the hotbar and bars", BpConfig.hudOffsetY + " px", () -> {
            int[] v = {0, 4, 8, 12, 16, 24, 32};
            BpConfig.hudOffsetY = v[(indexOf(v, BpConfig.hudOffsetY) + 1) % v.length];
            BpConfig.save();
            refreshPane();
        }));
    }

    private static int indexOf(int[] values, int cur) {
        int idx = 0;
        for (int i = 0; i < values.length; i++) if (values[i] <= cur) idx = i;
        return idx;
    }

    private void packRows(List<Row> rows) {
        try {
            Object repo = call(minecraft, "getResourcePackRepository");
            Collection<?> selectedPacks = (Collection<?>) call(repo, "getSelectedPacks");
            Collection<?> available = (Collection<?>) call(repo, "getAvailablePacks");
            List<String> ids = new ArrayList<>();
            for (Object p : selectedPacks) ids.add(String.valueOf(call(p, "getId")));

            rows.add(new Row(Kind.HEADING, "Active", "", null, null, null));
            for (Object p : selectedPacks) {
                final String id = String.valueOf(call(p, "getId"));
                boolean required = Boolean.TRUE.equals(call(p, "isRequired"));
                String title = packTitle(p);
                String desc = packDesc(p);
                if (required) {
                    rows.add(new Row(Kind.INFO, title, desc, null, null, null));
                } else {
                    rows.add(action(title, desc, "Remove", () -> setPack(repo, ids, id, false)));
                }
            }
            rows.add(new Row(Kind.HEADING, "Available", "", null, null, null));
            for (Object p : available) {
                final String id = String.valueOf(call(p, "getId"));
                if (ids.contains(id)) continue;
                rows.add(action(packTitle(p), packDesc(p), "Activate", () -> setPack(repo, ids, id, true)));
            }
        } catch (Throwable t) {
            LOG.warn("Could not list the resource packs: {}", t.toString());
            rows.add(new Row(Kind.INFO, "Resource packs are unavailable.", t.toString(), null, null, null));
        }
    }

    private static String packTitle(Object pack) {
        Object t = call(pack, "getTitle");
        return t instanceof Component c ? c.getString() : String.valueOf(call(pack, "getId"));
    }

    private static String packDesc(Object pack) {
        Object d = call(pack, "getDescription");
        String s = d instanceof Component c ? c.getString().replace('\n', ' ') : "";
        return s.length() > 60 ? s.substring(0, 57) + "..." : s;
    }

    private void setPack(Object repo, List<String> ids, String id, boolean on) {
        List<String> next = new ArrayList<>(ids);
        if (on) next.add(id);
        else next.remove(id);
        call(repo, "setSelected", next);
        packsDirty = true;
        refreshPane();
    }

    // ---------- layout ----------

    @Override
    protected void init() {
        pane.clear();
        side.clear();
        sideW = Math.max(120, (int) (width * 0.30f));
        borrowVanillaOptions();

        addRenderableWidget(Button.builder(Component.literal("<"), b -> onClose()).bounds(4, 2, 24, 20).build());

        boolean headings = height >= 300;
        int avail = height - headerH - 12 - (headings ? 28 : 0);
        tabH = Math.max(18, Math.min(26, avail / TABS.length));
        int y = headerH + 8;
        for (int i = 0; i < TABS.length; i++) {
            if (headings && (i == CONTROLS || i == GENERAL)) y += 14;
            final int idx = i;
            Button b = Button.builder(Component.literal(""), btn -> {
                selected = idx;
                page = 0;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(0, y, sideW, tabH).build();
            side.add(b);
            addRenderableWidget(b);
            y += tabH + 2;
        }
        buildPane();
    }

    private void refreshPane() {
        buildPane();
    }

    private void buildPane() {
        for (AbstractWidget w : pane) removeWidget(w);
        pane.clear();
        if (prev != null) removeWidget(prev);
        if (next != null) removeWidget(next);
        prev = null;
        next = null;

        List<Row> all = rowsFor(selected);
        paneTop = headerH + 8 + 30;
        int avail = height - paneTop - 26;

        // split into pages by height
        List<int[]> ranges = new ArrayList<>();
        int start = 0;
        int used = 0;
        for (int i = 0; i < all.size(); i++) {
            int h = all.get(i).height();
            if (used + h > avail && i > start) {
                ranges.add(new int[] {start, i});
                start = i;
                used = 0;
            }
            used += h;
        }
        ranges.add(new int[] {start, all.size()});
        pages = ranges.size();
        page = Math.min(page, pages - 1);

        pageRows.clear();
        int[] rg = ranges.get(page);
        int ww = Math.min(150, Math.max(100, (int) ((width - sideW) * 0.34f)));
        for (int i = rg[0]; i < rg[1]; i++) {
            Row r = all.get(i);
            pageRows.add(r);
            if (r.widget == null) continue;
            if (r.kind == Kind.SLIDER) r.widget.setWidth(width - sideW - 36);
            else if (r.kind == Kind.BUTTON) r.widget.setWidth(ww);
            addRenderableWidget(r.widget);
            pane.add(r.widget);
        }
        if (pages > 1) {
            prev = Button.builder(Component.literal("<"), b -> {
                page = (page + pages - 1) % pages;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(sideW + 12, height - 22, 24, 18).build();
            next = Button.builder(Component.literal(">"), b -> {
                page = (page + 1) % pages;
                paneStart = System.currentTimeMillis();
                buildPane();
            }).bounds(sideW + 40, height - 22, 24, 18).build();
            addRenderableWidget(prev);
            addRenderableWidget(next);
        }
    }

    private static float ease(long start, long ms) {
        if (!BpConfig.animations) return 1f;
        float p = Math.min(1f, (System.currentTimeMillis() - start) / (float) ms);
        float q = 1f - p;
        return 1f - q * q * q * q;
    }

    private static int argb(float alpha, int rgb) {
        return ((int) (255 * Math.max(0f, Math.min(1f, alpha))) << 24) | (rgb & 0xFFFFFF);
    }

    // ---------- rendering ----------

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float a) {
        float en = ease(enterStart, ENTER_MS);
        float pe = ease(paneStart, PANE_MS);
        int sideOff = -(int) ((1f - en) * sideW);
        int slide = (int) ((1f - pe) * 18f);

        g.fill(0, 0, width, height, 0xFF454547);
        g.fill(sideOff, headerH, sideOff + sideW, height, 0xFF2D2D2F);

        g.fill(0, 0, width, headerH, 0xFFE9EAEC);
        g.fill(0, headerH, width, headerH + 2, 0xFF8D8E91);
        Component title = Component.literal("SETTINGS").withStyle(ChatFormatting.BOLD);
        g.text(font, title, (width - font.width(title)) / 2, (headerH - 8) / 2, 0xFF1E1E1F, false);

        int px = sideW + 12 + slide;
        Component ct = Component.literal(TABS[selected].toUpperCase()).withStyle(ChatFormatting.BOLD);
        g.text(font, ct, px, headerH + 10, argb(pe, 0xFFFFFF), false);
        g.text(font, Component.literal(SUB[selected]), px, headerH + 21, argb(pe, 0xB5B5B8), false);
        g.fill(sideW + 4, headerH + 34, width - 4, headerH + 35, 0xFF5E5E61);

        // rows: labels, descriptions, separators; widgets are positioned here and drawn by super
        int y = paneTop;
        int right = width - 12 + slide;
        for (Row r : pageRows) {
            int h = r.height();
            boolean hover = mx >= sideW + 2 && my >= y && my < y + h;
            if (r.kind == Kind.HEADING) {
                g.text(font, Component.literal(r.label.toUpperCase()).withStyle(ChatFormatting.BOLD), px, y + 8, argb(pe, 0xB5B5B8), false);
                y += h;
                continue;
            }
            if (hover && r.kind != Kind.SLIDER) g.fill(sideW + 4, y, width - 4, y + h - 1, argb(pe * 0.5f, 0x5A5A5E));
            boolean hasDesc = !r.desc.isEmpty();
            g.text(font, Component.literal(r.label), px, y + (hasDesc ? 5 : 12), argb(pe, 0xFFFFFF), false);
            if (hasDesc) g.text(font, Component.literal(r.desc), px, y + 16, argb(pe, 0xB5B5B8), false);
            g.fill(sideW + 4, y + h - 1, width - 4, y + h, argb(pe, 0x5E5E61));
            AbstractWidget w = r.widget;
            if (w != null) {
                if (r.kind == Kind.SLIDER) {
                    w.setX(px);
                    w.setY(y + 26);
                } else {
                    w.setX(right - w.getWidth());
                    w.setY(y + (h - w.getHeight()) / 2);
                }
                w.setAlpha(pe);
            }
            y += h;
        }
        if (pageRows.isEmpty()) {
            g.text(font, Component.literal("Nothing to show here."), px, paneTop + 8, argb(pe, 0xB5B5B8), false);
        }
        if (pages > 1) {
            g.text(font, Component.literal((page + 1) + " / " + pages), sideW + 72, height - 17, 0xFFB5B5B8, false);
        }

        for (Button b : side) b.setX(sideOff);

        super.extractRenderState(g, mx, my, a);

        // Bedrock-style controls drawn over the vanilla widgets
        for (Row r : pageRows) {
            AbstractWidget w = r.widget;
            if (w == null) continue;
            switch (r.kind) {
                case BUTTON -> BedrockButtons.draw(g, font, w, mx, my, pe);
                case TOGGLE -> drawSwitch(g, w, r.state.getAsBoolean(), pe);
                case SLIDER -> drawSlider(g, w, Math.max(0.0, Math.min(1.0, r.value.getAsDouble())), pe);
                default -> { }
            }
            if (r.kind == Kind.SLIDER) {
                String m = w.getMessage().getString();
                int c = m.lastIndexOf(':');
                String v = c >= 0 ? m.substring(c + 1).trim() : m;
                g.text(font, Component.literal(v), width - 12 + slide - font.width(v), w.getY() - 20, argb(pe, 0xFFFFFF), false);
            }
        }

        // sidebar tabs drawn over their (invisible) buttons
        for (int i = 0; i < side.size(); i++) {
            Button b = side.get(i);
            int by = b.getY();
            boolean gray = i == SHADER && !iris;
            boolean hover = mx >= 0 && mx < sideW && my >= by && my < by + tabH;
            g.fill(sideOff, by, sideOff + sideW, by + tabH, i == selected ? 0xFF454547 : hover ? 0xFF38383A : 0xFF2D2D2F);
            if (i == selected) g.fill(sideOff, by, sideOff + 3, by + tabH, 0xFF3C8527);
            int size = tabH - 6;
            drawIcon(g, i, 8 + sideOff, by + 3, size, gray);
            int ty = by + (tabH - 8) / 2;
            g.text(font, Component.literal(TABS[i]), 8 + sideOff + size + 8, ty, gray ? 0xFF7C7C80 : 0xFFFFFFFF, false);
            if (height >= 300) {
                if (i == CONTROLS) g.text(font, Component.literal("Controls"), 8 + sideOff, by - 12, 0xFFA0A0A4, false);
                if (i == GENERAL) g.text(font, Component.literal("General"), 8 + sideOff, by - 12, 0xFFA0A0A4, false);
            }
        }
    }

    /** Bedrock switch: green "I" half + white knob when on, white knob + gray "O" half when off. */
    private void drawSwitch(GuiGraphicsExtractor g, AbstractWidget w, boolean on, float alpha) {
        int x = w.getX();
        int y = w.getY();
        int half = 19;
        int h = 18;
        int a = (int) (255 * alpha);
        int outline = (a << 24) | 0x1E1E1F;
        g.fill(x - 1, y - 1, x + half * 2 + 1, y + h + 1, outline);
        if (on) {
            g.fill(x, y, x + half, y + h, (a << 24) | 0x3C8527);
            g.fill(x + half, y, x + half * 2, y + h, (a << 24) | 0xDADADC);
            g.fill(x + half - 1, y + 3, x + half, y + h - 3, (a << 24) | 0xFFFFFF);
            g.text(font, Component.literal("I"), x + half / 2 - 1, y + 5, (a << 24) | 0xFFFFFF, false);
        } else {
            g.fill(x, y, x + half, y + h, (a << 24) | 0xDADADC);
            g.fill(x + half, y, x + half * 2, y + h, (a << 24) | 0x7A7A7D);
            g.text(font, Component.literal("O"), x + half + half / 2 - 2, y + 5, (a << 24) | 0x2A2A2C, false);
        }
    }

    /** Bedrock slider: gray track with a lighter filled part and a light square handle. */
    private void drawSlider(GuiGraphicsExtractor g, AbstractWidget w, double v, float alpha) {
        int x = w.getX();
        int w2 = w.getWidth();
        int cy = w.getY() + 10;
        int a = (int) (255 * alpha);
        int hw = 12;
        int hx = x + (int) ((w2 - hw) * v);
        g.fill(x, cy - 3, x + w2, cy + 3, (a << 24) | 0x8A8A8D);
        g.fill(x, cy - 3, hx + hw / 2, cy + 3, (a << 24) | 0xB8B8BB);
        g.fill(x, cy + 2, x + w2, cy + 3, (a << 24) | 0x6A6A6D);
        g.fill(hx - 1, cy - 10, hx + hw + 1, cy + 10, (a << 24) | 0x1E1E1F);
        g.fill(hx, cy - 9, hx + hw, cy + 9, (a << 24) | 0xE2E2E4);
        g.fill(hx, cy + 6, hx + hw, cy + 9, (a << 24) | 0xA9A9AC);
    }

    // ---------- tab icons (drawn in a 16x16 space) ----------

    private void drawIcon(GuiGraphicsExtractor g, int idx, int x, int y, int size, boolean gray) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        float s = size / 16f;
        g.pose().scale(s, s);
        g.fill(-1, -1, 17, 17, 0xFF1E1E1F);
        switch (idx) {
            case ACCESS -> {
                g.fill(0, 0, 16, 16, 0xFF2D6CF0);
                g.fill(6, 2, 10, 5, 0xFFFFFFFF);
                g.fill(3, 6, 13, 8, 0xFFFFFFFF);
                g.fill(7, 8, 9, 11, 0xFFFFFFFF);
                g.fill(5, 11, 7, 14, 0xFFFFFFFF);
                g.fill(9, 11, 11, 14, 0xFFFFFFFF);
            }
            case CONTROLS -> {
                g.fill(0, 0, 16, 16, 0xFF6B6B6D);
                g.fill(4, 2, 12, 14, 0xFFC9C9CB);
                g.fill(4, 7, 12, 8, 0xFF6B6B6D);
                g.fill(7, 2, 9, 7, 0xFF6B6B6D);
            }
            case GENERAL -> {
                g.fill(0, 0, 16, 16, 0xFF3A2A1A);
                g.fill(5, 3, 11, 13, 0xFFE08A2E);
                g.fill(3, 5, 13, 11, 0xFFE08A2E);
                g.fill(7, 7, 9, 9, 0xFF3A2A1A);
            }
            case VIDEO -> {
                g.fill(0, 0, 16, 16, 0xFF5AA6F0);
                g.fill(0, 10, 16, 16, 0xFF4C9A3A);
                g.fill(3, 3, 8, 5, 0xFFFFFFFF);
            }
            case AUDIO -> {
                g.fill(0, 0, 16, 16, 0xFF8A3B2A);
                g.fill(3, 6, 6, 10, 0xFFFFFFFF);
                g.fill(6, 4, 8, 12, 0xFFFFFFFF);
                g.fill(10, 6, 11, 10, 0xFFFFFFFF);
                g.fill(12, 4, 13, 12, 0xFFFFFFFF);
            }
            case PACKS -> {
                g.fill(0, 0, 16, 16, 0xFF5B3A1A);
                g.fill(2, 5, 14, 13, 0xFFC98B3A);
                g.fill(2, 5, 14, 8, 0xFFE0A84E);
                g.fill(7, 8, 9, 10, 0xFF3A2A1A);
            }
            case SHADER -> {
                g.fill(0, 0, 16, 16, 0xFF2A2A4A);
                g.fill(5, 5, 11, 11, 0xFFF2C21A);
                g.fill(7, 2, 9, 4, 0xFFF2C21A);
                g.fill(7, 12, 9, 14, 0xFFF2C21A);
                g.fill(2, 7, 4, 9, 0xFFF2C21A);
                g.fill(12, 7, 14, 9, 0xFFF2C21A);
            }
            case MODS -> {
                g.fill(0, 0, 16, 16, 0xFF4A4A4C);
                g.fill(3, 4, 13, 13, 0xFF9AA0A8);
                g.fill(3, 4, 13, 7, 0xFFC8CDD2);
                g.fill(11, 2, 14, 5, 0xFF2BC4AE);
            }
            default -> {
                g.fill(0, 0, 16, 16, 0xFF3C8527);
                g.fill(4, 3, 6, 13, 0xFFFFFFFF);
                g.fill(6, 3, 11, 5, 0xFFFFFFFF);
                g.fill(6, 7, 11, 9, 0xFFFFFFFF);
                g.fill(6, 11, 11, 13, 0xFFFFFFFF);
                g.fill(10, 5, 12, 7, 0xFFFFFFFF);
                g.fill(10, 9, 12, 11, 0xFFFFFFFF);
            }
        }
        if (gray) g.fill(-1, -1, 17, 17, 0xA0454547);
        g.pose().popMatrix();
    }
}
