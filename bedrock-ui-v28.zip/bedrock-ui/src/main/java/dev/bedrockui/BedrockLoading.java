package dev.bedrockui;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Bedrock-style loading screen drawn over the game's default menu background: floating logo, smoothly
 * filling progress bar with a moving shimmer, bouncing squares, and a rotating tip that cross-fades.
 */
public final class BedrockLoading {
    private static final LogoRenderer LOGO = new LogoRenderer(false);
    private static final String[] TIPS = {
            "Place a bed and sleep to skip the night.",
            "Sprinting makes you hungrier, so keep some food around.",
            "A crafting table unlocks many more recipes.",
            "Torches stop monsters from spawning around them.",
            "A bucket of water can break a long fall.",
            "Hold Shift while walking to avoid falling off edges.",
            "Pickaxes mine stone, axes chop wood and shovels dig dirt faster.",
            "Furnaces smelt ores and cook food.",
            "Eating restores your hunger bar and helps you heal.",
            "Wolves can be tamed with bones.",
            "Sleeping in a bed sets your spawn point.",
            "Diamonds are usually found deep underground.",
            "You can trade with villagers using emeralds.",
            "Chests keep your items safe while you explore."
    };
    private static final long TIP_MS = 6500L;
    private static final Random RANDOM = new Random();

    private static int tipIndex = -1;
    private static long tipTime;
    private static long appearStart;
    private static long lastRender;
    private static float shown;

    /** True while the startup screen draws the logo (the edition text is hidden then). */
    public static volatile boolean hideEdition;
    private static final long STARTUP_BEGIN = System.currentTimeMillis();

    private BedrockLoading() {}

    private static float readFloat(Object o, String name, float def) {
        try {
            java.lang.reflect.Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.getFloat(o);
        } catch (Throwable t) {
            return def;
        }
    }

    private static long readLong(Object o, String name, long def) {
        try {
            java.lang.reflect.Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.getLong(o);
        } catch (Throwable t) {
            return def;
        }
    }

    /** Bedrock startup screen: dark background, logo, spinner, progress bar and percentage. */
    public static void renderStartup(GuiGraphicsExtractor g, Object overlay) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.currentTimeMillis();
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        float progress = readFloat(overlay, "currentProgress", -1f);
        if (progress < 0f) progress = Math.min(0.95f, (now - STARTUP_BEGIN) / 12000f);
        progress = Math.max(0f, Math.min(1f, progress));
        long fadeOut = readLong(overlay, "fadeOutStart", -1L);
        float alpha = 1f;
        if (fadeOut > 0L) alpha = Math.max(0f, 1f - (now - fadeOut) / 1000f);
        int a = (int) (255 * alpha);
        if (a <= 2) return;

        g.fill(0, 0, w, h, (a << 24) | 0x1E1E1E);

        hideEdition = true;
        try {
            LOGO.extractRenderState(g, w, alpha, (int) (h * 0.22f));
        } finally {
            hideEdition = false;
        }

        // spinner: a bright head with a fading trail
        int cx = w / 2;
        int cy = (int) (h * 0.595f);
        int head = (int) ((now / 70L) % 12L);
        for (int i = 0; i < 12; i++) {
            double ang = Math.toRadians(i * 30.0);
            int px = cx + (int) Math.round(Math.cos(ang) * 8);
            int py = cy + (int) Math.round(Math.sin(ang) * 8);
            float trail = Math.max(0f, 1f - ((head - i + 12) % 12) / 7f);
            int ta = (int) (a * trail);
            if (ta > 4) g.fill(px - 1, py - 1, px + 2, py + 2, (ta << 24) | 0xFFFFFF);
        }

        // progress bar: white outline, black inside, white fill
        int bw = (int) (w * 0.55f);
        int bx = (w - bw) / 2;
        int bh = Math.max(8, (int) (h * 0.034f));
        int by = (int) (h * 0.72f);
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, (a << 24) | 0xFFFFFF);
        g.fill(bx + 1, by + 1, bx + bw - 1, by + bh - 1, (a << 24) | 0x000000);
        int fw = (int) ((bw - 4) * progress);
        if (fw > 0) g.fill(bx + 2, by + 2, bx + 2 + fw, by + bh - 2, (a << 24) | 0xFFFFFF);
        g.centeredText(mc.font, Component.literal(Math.round(progress * 100f) + "%"), w / 2, by + bh + 6, (a << 24) | 0xFFFFFF);
    }

    private static void text(GuiGraphicsExtractor g, Minecraft mc, Component c, int x, int y, int rgb, int alpha) {
        if (alpha < 8) return;
        g.centeredText(mc.font, c, x, y, (Math.min(alpha, 255) << 24) | rgb);
    }

    private static void rect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int rgb, int alpha) {
        if (alpha <= 0 || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, (Math.min(alpha, 255) << 24) | rgb);
    }

    /** progress: 0-100, or a negative value for an indeterminate bar. */
    public static void render(GuiGraphicsExtractor g, Screen self, int mx, int my, float partial,
                              Component title, Component subtitle, int progress) {
        render(g, self, mx, my, partial, title, subtitle, progress, false);
    }

    /** overlayOnly: the screen already drew its background and widgets (e.g. the connect screen). */
    public static void render(GuiGraphicsExtractor g, Screen self, int mx, int my, float partial,
                              Component title, Component subtitle, int progress, boolean overlayOnly) {
        Minecraft mc = Minecraft.getInstance();
        long now = System.currentTimeMillis();
        if (now - lastRender > 400L) { // a new loading screen just appeared
            appearStart = now;
            shown = Math.max(0, progress);
            tipIndex = -1;
        }
        float dt = Math.min(0.1f, (now - lastRender) / 1000f);
        lastRender = now;
        float t = (now - appearStart) / 1000f;

        // the game's own default background for this Minecraft version
        if (!overlayOnly) self.extractBackground(g, mx, my, partial);

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        float in = Math.min(1f, t / 0.45f);
        int alpha = (int) (255 * (1f - (1f - in) * (1f - in)));

        // logo floats gently
        int bob = Math.round((float) Math.sin(t * 1.6) * 2.5f);
        LOGO.extractRenderState(g, w, in, Math.max(8, h / 2 - 90) + bob);

        int cy = h / 2 - 6;
        if (title != null) text(g, mc, title, w / 2, cy, 0xFFFFFF, alpha);

        // smooth progress
        if (progress >= 0) shown += (progress - shown) * (1f - (float) Math.exp(-dt * 7f));
        int bw = Math.min(220, w - 40);
        int bx = (w - bw) / 2;
        int by = cy + 14;
        int bh = 8;
        rect(g, bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0x000000, alpha);
        rect(g, bx, by, bx + bw, by + bh, 0x3C3C3C, alpha);

        if (progress >= 0) {
            int fw = Math.round(bw * Math.min(100f, shown) / 100f);
            rect(g, bx, by, bx + fw, by + bh, 0x3FB83F, alpha);
            rect(g, bx, by + bh - 2, bx + fw, by + bh, 0x2A8A2A, alpha);
            float pulse = 0.65f + 0.35f * (float) Math.sin(t * 5f);
            rect(g, bx, by, bx + fw, by + 2, 0x7BE07B, (int) (alpha * pulse));
            // moving shimmer across the filled part
            if (fw > 6) {
                int sw = 14;
                int sx = bx + (int) (((t * 0.7f) % 1f) * (fw + sw)) - sw;
                int x1 = Math.max(bx, sx);
                int x2 = Math.min(bx + fw, sx + sw);
                rect(g, x1, by, x2, by + bh, 0xFFFFFF, (int) (alpha * 0.28f));
            }
        } else {
            int seg = bw / 4;
            float u = ((now - appearStart) % 1500L) / 1500f;
            int start = (int) (u * (bw + seg)) - seg;
            int x1 = Math.max(0, start);
            int x2 = Math.min(bw, start + seg);
            rect(g, bx + x1, by, bx + x2, by + bh, 0x3FB83F, alpha);
            rect(g, bx + x1, by, bx + x2, by + 2, 0x7BE07B, alpha);
        }

        Component sub = progress >= 0 ? Component.literal(Math.round(shown) + "%") : subtitle;
        if (sub != null) text(g, mc, sub, w / 2, by + bh + 6, 0xC8C8C8, alpha);

        // three bouncing squares
        for (int i = 0; i < 3 && !overlayOnly; i++) {
            float b = Math.abs((float) Math.sin(t * 4.2f - i * 0.55f));
            int sx = w / 2 - 12 + i * 10;
            int sy = by + bh + 22 - Math.round(b * 5f);
            rect(g, sx, sy, sx + 4, sy + 4, 0x7BE07B, (int) (alpha * (0.45f + 0.55f * b)));
        }

        // rotating tip with a cross-fade
        if (tipIndex < 0 || now - tipTime > TIP_MS) {
            tipIndex = RANDOM.nextInt(TIPS.length);
            tipTime = now;
        }
        long age = now - tipTime;
        float fade = Math.min(1f, age / 450f) * Math.min(1f, (TIP_MS - age) / 450f);
        text(g, mc, Component.literal("Tip: " + TIPS[tipIndex]), w / 2, h - 34, 0xC8C8C8,
                (int) (alpha * Math.max(0f, fade)));
    }
}
