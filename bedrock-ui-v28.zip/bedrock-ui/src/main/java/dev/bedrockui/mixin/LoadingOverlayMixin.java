package dev.bedrockui.mixin;

import dev.bedrockui.BedrockLoading;
import dev.bedrockui.BpConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.LoadingOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Bedrock-style startup loading screen, drawn over the vanilla overlay once it finished drawing. */
@Mixin(LoadingOverlay.class)
public abstract class LoadingOverlayMixin {
    @Inject(method = "extractRenderState", at = @At("RETURN"), require = 0)
    private void bedrockui$startup(GuiGraphicsExtractor g, int mx, int my, float a, CallbackInfo ci) {
        if (BpConfig.bedrockStartupScreen) {
            BedrockLoading.renderStartup(g, this);
        }
    }
}
